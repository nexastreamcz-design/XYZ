# -*- coding: utf-8 -*-
"""StreamCatalog Kodi add-on router."""

import sys
try:
    from urllib.parse import parse_qsl
except ImportError:
    from urlparse import parse_qsl

from resources.lib.app.router import dispatch


def router(params):
    """Backward-compatible alias kept for legacy entrypoints."""
    return dispatch(params)


if __name__ == '__main__':
    dispatch(dict(parse_qsl(sys.argv[2][1:])))