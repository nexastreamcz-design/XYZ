import urllib.request, urllib.parse, urllib.error, json, re
try:
    from urllib.parse import unquote_plus
except ImportError:
    from urllib import unquote_plus
import xbmcaddon, xbmc
import concurrent.futures
import unicodedata

from resources.lib.utils import get_ssl_context

addon = xbmcaddon.Addon()


def extract_download_url_from_html(html):
    """
    Vytáhne první použitelnou download.php URL z HTML/SPA (včetně JSON escapů v <script>).
    """
    if not html or not isinstance(html, str):
        return None
    flat = (
    html.replace('\\/', '/')
        .replace('\\u002f', '/')
        .replace('&#x2F;', '/')
        .replace('&#47;', '/')
    )
    # (regex, index skupiny s URL / 0 = celý match)
    # Pozn.: třída znaků NESMÍ vyřazovat '&' - FS běžně za ?id=XYZ lepí "&filename.avi"
    # jako součást download tokenu. Bez něj server často vrátí 0 bajtů.
    specs = [
        (r'(https://(?:data\d*|cdn\d*)\.fastshare\.[a-z]+/download\.php\?id=[^\s"\'<>]+)', 1),
        (r'(http://(?:data\d*|cdn\d*)\.fastshare\.[a-z]+/download\.php\?id=[^\s"\'<>]+)', 1),
        (r'href=["\']([^"\']*download\.php\?id=[^"\']+)["\']', 1),
        (r'(https://[^\s"\'<>]+fastshare\.[a-z]{2,}/download\.php\?id=\d+[^\s"\'<>]*)', 1),
    ]
    for pat, gidx in specs:
        m = re.search(pat, flat, flags=re.I)
        if not m:
            continue
        dl_url = m.group(gidx).strip()
        if not dl_url.startswith('http'):
            dl_url = (
                'https://fastshare.cloud' + dl_url
                if dl_url.startswith('/')
                else 'https://' + dl_url
            )
        if dl_url.lower().startswith('http://'):
            dl_url = 'https://' + dl_url[7:]
        if 'download.php' in dl_url and 'id=' in dl_url:
            return dl_url
    return None


def _fs_probe_mirror_url(dl_url, fs_hash):
    """
    Ověří, že konkrétní https://dataN.../download.php?id=… vrací binární stream (ne HTML přihlášku).
    Používá se, když SPA stránka fastshare.cloud/{id}/ neobsahuje statický odkaz (moderace [Q] má jen číslo).
    """
    if not dl_url or 'download.php' not in dl_url:
        return None
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Range': 'bytes=0-8191',
        'Accept': '*/*',
        'Referer': 'https://fastshare.cloud/',
    }
    if fs_hash:
        headers['Cookie'] = 'FASTSHARE=%s' % fs_hash
    try:
        req = urllib.request.Request(dl_url, headers=headers)
        with urllib.request.urlopen(req, timeout=7, context=get_ssl_context()) as r:
            ctype = (r.headers.get('Content-Type') or '').lower()
            final_u = r.geturl()
            data = r.read(1536) or b''
        if 'text/html' in ctype:
            return None
        head = data[:160].lstrip().lower()
        if head.startswith(b'<!doctype') or head.startswith(b'<html') or head.startswith(b'<?xml'):
            return None
        if not data:
            return None
        out = (final_u or dl_url).split('|')[0]
        if out.startswith('http'):
            return out
    except urllib.error.HTTPError as e:
        if e.code not in (404, 403, 410):
            xbmc.log('NEXASTREAM FS PROBE: HTTP %s %s' % (e.code, dl_url[:80]), xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log('NEXASTREAM FS PROBE: %s' % e, xbmc.LOGDEBUG)
    return None


def probe_fastshare_mirror_for_id(file_id, fs_hash=None):
    """
    Paralelně vyzkouší data1..data20 (download.php?id=) — shodné chování jako FS API search výsledky.
    """
    fid = str(file_id or '').strip()
    if not re.match(r'^\d{5,12}$', fid):
        return None
    h = fs_hash or get_hash()
    urls = ['https://data%s.fastshare.cloud/download.php?id=%s' % (n, fid) for n in range(1, 21)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=14) as pool:
        futs = [pool.submit(_fs_probe_mirror_url, u, h) for u in urls]
        try:
            for fut in concurrent.futures.as_completed(futs, timeout=28):
                try:
                    got = fut.result()
                    if got:
                        return got
                except Exception:
                    pass
        except concurrent.futures.TimeoutError:
            pass
    return None


def resolve_download_url(file_id, page_url=None, is_vip=False):
    """
    Zjistí správný dataX download URL pro dané FS ID.
    Otevře FS page URL a z HTML vyparsuje reálný download link (správný node).
    
    Podporované formáty page_url:
      - https://fastshare.cloud/{id}/{filename}   (page URL s filename - nejlepší)
      - https://fastshare.cloud/{id}/             (page URL jen s ID)
      - https://dataX.fastshare.cloud/download.php?id={id}&{filename}  (přímá DL URL - vrátí rovnou)
    
    Vrací: 'https://dataX.fastshare.cloud/download.php?id=ID&filename.mkv' nebo None
    """
    fs_hash = get_hash()
    
    # Pokud je page_url přímá download URL, vrátíme ji rovnou (bez HTTP requestu)
    if page_url and ('download.php' in page_url or re.search(r'data\d+\.fastshare', page_url)):
        dl_url = page_url.split('|')[0]
        if not dl_url.startswith('https://'):
            dl_url = 'https://' + dl_url.lstrip('http://')
        xbmc.log("NEXASTREAM FS RESOLVER: přímá DL URL předána", xbmc.LOGDEBUG)
        return dl_url
    
    # Normalizace page_url - doplnit https:// pokud chybí
    if page_url and not page_url.startswith('http'):
        page_url = 'https://' + page_url
    
    # Sestavíme page URL pokud nemáme
    if not page_url:
        page_url = f'https://fastshare.cloud/{file_id}/'

    xbmc.log("NEXASTREAM FS RESOLVER: otevírám stránku FS", xbmc.LOGDEBUG)
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'cs-CZ,cs;q=0.9,en;q=0.8',
            'Referer': 'https://fastshare.cloud/',
        }
        if fs_hash:
            headers['Cookie'] = f'FASTSHARE={fs_hash}'
        
        req = urllib.request.Request(page_url, headers=headers)
        with urllib.request.urlopen(req, timeout=10, context=get_ssl_context()) as r:
            html = r.read().decode('utf-8', errors='replace')
            dl_url = extract_download_url_from_html(html)
            if dl_url:
                xbmc.log("NEXASTREAM FS RESOLVER: nalezen download odkaz v HTML", xbmc.LOGDEBUG)
                return dl_url

            # Pokud nic nenajdeme, logujeme vyrez HTML pro debug.
            # Pri VIP zdroji logujeme jen delku - HTML stranka muze obsahovat odkaz
            # s filename, ktery by mohl prozradit nazev obsahu. Vycistime i pripadne
            # URL z vyrezu, aby se nahodne nedostaly do kodi.log.
            if is_vip:
                xbmc.log("NEXASTREAM FS RESOLVER: Žádný download link v HTML (délka=%d) [VIP]" % (len(html),), xbmc.LOGWARNING)
            else:
                _snippet = re.sub(r'https?://[^\s"\'<>]+', '[URL]', html[:200])
                xbmc.log("NEXASTREAM FS RESOLVER: Žádný download link v HTML (délka=%d). Prvních 200 znaků: %r" % (len(html), _snippet), xbmc.LOGWARNING)
            
    except urllib.error.HTTPError as e:
        xbmc.log("NEXASTREAM FS RESOLVER HTTP ERROR %s" % e.code, xbmc.LOGWARNING)
    except urllib.error.URLError as e:
        xbmc.log("NEXASTREAM FS RESOLVER URL ERROR: %s" % e.reason, xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"NEXASTREAM FS RESOLVER ERROR: {e}", xbmc.LOGWARNING)

    # fastshare.cloud/{id}/ často vrací jen SPA shell — [Q] v DB má jen číselné ID.
    # Zrcadla dataN + download.php odpovídají tomu, co vrací FS search (plné URL v ident).
    if re.match(r'^\d{5,12}$', str(file_id).strip()):
        alt = probe_fastshare_mirror_for_id(str(file_id).strip(), fs_hash)
        if alt:
            xbmc.log('NEXASTREAM FS RESOLVER: mirror download.php OK', xbmc.LOGINFO)
            return alt

    return None

def remove_accents(input_str):
    nfkd_form = unicodedata.normalize('NFKD', input_str)
    return "".join([c for c in nfkd_form if not unicodedata.combining(c)])

def get_hash():
    fs_hash = addon.getSetting('fs_hash')
    if not fs_hash:
        return login()
    return fs_hash

def login():
    user = addon.getSetting('fs_username')
    pwd = addon.getSetting('fs_password')
    if not user or not pwd: return None
    url = f"https://fastshare.cz/api/api_kodi.php?process=login&login={urllib.parse.quote_plus(user)}&password={urllib.parse.quote_plus(pwd)}"
    try:
        with urllib.request.urlopen(url, timeout=5, context=get_ssl_context()) as r:
            data = json.loads(r.read().decode('utf-8'))
            fs_hash = data.get('user', {}).get('hash')
            if fs_hash:
                addon.setSetting('fs_hash', fs_hash)
                return fs_hash
    except Exception as e:
        xbmc.log(f"NEXASTREAM FASTSHARE LOGIN ERROR: {str(e)}", xbmc.LOGERROR)
    return None

def search(query):
    fs_hash = get_hash()
    if not fs_hash: return []
    url = f"https://fastshare.cz/api/api_kodi.php?process=search&pagination=1000&term={urllib.parse.quote_plus(query)}&adult=false"
    results = []
    try:
        with urllib.request.urlopen(url, timeout=5, context=get_ssl_context()) as r:
            data = json.loads(r.read().decode('utf-8'))
            files = data.get('search', {}).get('file', [])
            if isinstance(files, dict): files = [files]
            
            import re
            for f in files:
                raw_ident = f.get('id') or f.get('ident') or ''
                raw_dl = f.get('download_url', '')
                name = unquote_plus(f.get('filename', ''))
                size = int(f.get('data', {}).get('value', 0))
                
                # Plne dekodovani a extrakce cisteho ID
                ident_dec = urllib.parse.unquote(raw_ident)
                dl_url = urllib.parse.unquote(raw_dl)
                
                ident = ''
                m = re.search(r'[?&]id=([0-9a-zA-Z]+)', ident_dec, re.I)
                if m:
                    ident = m.group(1)
                else:
                    m = re.search(r'/file/([0-9a-zA-Z]+)/', ident_dec, re.I)
                    if m:
                        ident = m.group(1)
                    elif re.match(r'^([0-9a-zA-Z]+)$', ident_dec):
                        ident = ident_dec
                    else:
                        # Případ: https://fastshare.cloud/33978149/soubor.mp4 (page URL)
                        m = re.search(r'/(\d{5,12})(?:/|$)', ident_dec, re.I)
                        if m: ident = m.group(1)
                
                if not ident and dl_url:
                    m = re.search(r'[?&]id=([0-9a-zA-Z]+)', dl_url, re.I)
                    if m: ident = m.group(1)
                    else:
                        m = re.search(r'/file/([0-9a-zA-Z]+)/', dl_url, re.I)
                        if m: ident = m.group(1)
                
                if dl_url and 'http' in dl_url:
                    link = dl_url.split('|')[0]
                elif ident:
                    link = ident
                else:
                    continue

                # Ochrana: přeskočit položky kde link vypadá jako filename (ne URL ani číslo)
                # Toto by nemělo nastat (API vždy vrací download_url), ale pro jistotu
                is_bad_link = (
                    link and
                    not link.startswith('http') and
                    not re.match(r'^\d{5,12}$', link) and
                    re.match(r'^[\w\-\.]+\.(mp4|mkv|avi|ts|mov)$', link, re.I)
                )
                if is_bad_link:
                    xbmc.log(f"NEXASTREAM FASTSHARE: Přeskakuji neplatný ident '{link}' pro soubor '{name}'", xbmc.LOGWARNING)
                    continue

                results.append({'ident': link, 'name': name, 'size': size, 'provider': 'fastshare'})
    except Exception as e:
        xbmc.log(f"NEXASTREAM FASTSHARE SEARCH ERROR: {str(e)}", xbmc.LOGERROR)
    return results

def smart_search(cz_title, orig_title=None, year=None):
    if not addon.getSetting('fs_username') or not addon.getSetting('fs_password'):
        return []

    queries = set()
    
    def add_variations(title):
        if not title: return
        queries.add(title)
        # Uploadeři na FS milují tečky (Tip.a.Tap), API to tak najde mnohem spolehlivěji
        if ' ' in title:
            queries.add(title.replace(' ', '.'))
        if year:
            pass

    # Přidání originálních názvů
    add_variations(cz_title)
    add_variations(orig_title)
    
    # Přidání názvů bez diakritiky (často používané uploaderem)
    if cz_title:
        add_variations(remove_accents(cz_title))
    if orig_title:
        add_variations(remove_accents(orig_title))

    results = []
    seen_idents = set()

    # Bezpečné paralelní zpracování s tvrdým timeoutem proti zamrzání Kodi
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        # Použijeme slovník pro logování, abychom věděli, který dotaz selhal
        future_to_query = {executor.submit(search, q): q for q in queries}
        
        # as_completed má celkový timeout 8 vteřin pro všechny dotazy
        try:
            for future in concurrent.futures.as_completed(future_to_query, timeout=8):
                try:
                    # Rychlé vyzvednutí výsledku
                    for f in future.result(timeout=2):
                        if f['ident'] not in seen_idents:
                            seen_idents.add(f['ident'])
                            results.append(f)
                except Exception as e:
                    # Ignorujeme chyby jednotlivých vláken (timeouty, pády spojení)
                    pass
        except concurrent.futures.TimeoutError:
            # Pokud vyprší celkových 8 vteřin, okamžitě ukončíme čekání a vrátíme co máme
            pass

    return results
