# -*- coding: utf-8 -*-
import json
import re
import threading
import xbmc

import csfd_scraper

from resources.lib.config import addon, CSFD_CACHE_FILE, TMDB_CACHE_FILE, TMDB_KEY
from resources.lib.utils import _notify

_csfd_mem_cache = None
_tmdb_mem_cache = None
_tmdb_lock = threading.Lock()


def _load_csfd():
    global _csfd_mem_cache
    if _csfd_mem_cache is not None:
        return _csfd_mem_cache
    import os
    try:
        if os.path.exists(CSFD_CACHE_FILE):
            with open(CSFD_CACHE_FILE, "r", encoding="utf-8") as f:
                _csfd_mem_cache = json.load(f)
        else:
            _csfd_mem_cache = {}
    except Exception:
        _csfd_mem_cache = {}
    return _csfd_mem_cache


def _save_csfd():
    if _csfd_mem_cache is not None:
        try:
            with open(CSFD_CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(_csfd_mem_cache, f)
        except Exception:
            pass


def _norm_title(s):
    if not s:
        return ""
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", str(s))).strip().lower()


def _score_csfd_row(row, title, year, orig_title):
    y = str(year or "").strip()
    ry = str(row.get("year") or "").strip()
    score = 0
    if y and ry == y:
        score += 15
    rt = _norm_title(row.get("title"))
    for t in (title, orig_title):
        tn = _norm_title(t)
        if not tn:
            continue
        if rt == tn:
            score += 14
        elif tn in rt or rt in tn:
            score += 8
        else:
            parts = tn.split()
            if parts and len(parts[0]) > 2 and rt.startswith(parts[0]):
                score += 4
    return score


def _parse_pct_rating(row):
    r = row.get("rating") or ""
    if isinstance(r, int):
        return r
    m = re.search(r"(\d+)\s*%", str(r))
    return int(m.group(1)) if m else 0


def _get_csfd_rating(tmdb_id, title, year, orig_title="", media_type="movie"):
    cache = _load_csfd()
    cache_key = "%s_%s" % (tmdb_id, title)
    if cache_key in cache and cache[cache_key] > 0:
        return cache[cache_key]

    mt = "tvshow" if str(media_type or "").lower() in ("tv", "tvshow") else "movie"
    queries = []
    if title and year:
        queries.append("%s %s" % (title, year))
    if orig_title and year and orig_title != title:
        queries.append("%s %s" % (orig_title, year))
    if title:
        queries.append(title)
    if orig_title and orig_title != title:
        queries.append(orig_title)

    best_rating = 0
    best_row = None
    best_score = -1
    for q in queries:
        q = (q or "").strip()
        if not q:
            continue
        try:
            rows = csfd_scraper.search(q, mt, limit=25) or []
        except Exception as e:
            xbmc.log("CSFD search error: %s" % e, xbmc.LOGWARNING)
            continue
        for row in rows:
            if not isinstance(row, dict):
                continue
            sc = _score_csfd_row(row, title, year, orig_title)
            if sc < 4:
                continue
            if sc > best_score or (sc == best_score and _parse_pct_rating(row) > best_rating):
                best_score = sc
                best_row = row
                best_rating = max(best_rating, _parse_pct_rating(row))

    rid = None
    if isinstance(best_row, dict):
        rid = str(best_row.get("id") or "").strip()
    if rid:
        try:
            det = csfd_scraper.get_movie_details(rid) or {}
            r = int(det.get("rating") or 0)
            if r > 0:
                best_rating = r
        except Exception as e:
            xbmc.log("CSFD details error: %s" % e, xbmc.LOGWARNING)

    if best_rating > 0:
        cache[cache_key] = best_rating
        _save_csfd()
    return best_rating


def clear_csfd_cache():
    import os
    try:
        if os.path.exists(CSFD_CACHE_FILE):
            os.remove(CSFD_CACHE_FILE)
        global _csfd_mem_cache
        _csfd_mem_cache = {}
        _notify("Mezipaměť metadat byla úspěšně vymazána.")
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        _notify("Chyba při mazání mezipaměti.")


def _load_tmdb():
    global _tmdb_mem_cache
    if _tmdb_mem_cache is not None:
        return _tmdb_mem_cache
    import os
    try:
        if os.path.exists(TMDB_CACHE_FILE):
            with open(TMDB_CACHE_FILE, "r", encoding="utf-8") as f:
                _tmdb_mem_cache = json.load(f)
        else:
            _tmdb_mem_cache = {}
    except Exception:
        _tmdb_mem_cache = {}
    return _tmdb_mem_cache


def _save_tmdb():
    if _tmdb_mem_cache is None:
        return
    try:
        with _tmdb_lock:
            with open(TMDB_CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(_tmdb_mem_cache, f)
    except Exception:
        pass


def get_tmdb_cached(tmdb_id, media_type, ttl_days=30):
    if not tmdb_id:
        return None
    import time
    mt = "tvshow" if media_type in ("tv", "tvshow") else "movie"
    cache = _load_tmdb()
    cache_key = "%s_%s" % (tmdb_id, mt)
    now = time.time()
    ttl = max(1, int(ttl_days)) * 86400

    entry = cache.get(cache_key)
    if isinstance(entry, dict) and entry.get("data") and (now - float(entry.get("ts", 0))) < ttl:
        return entry["data"]

    try:
        import tmdb_api
        if mt == "tvshow":
            data = tmdb_api.get_tvshow_details(TMDB_KEY, tmdb_id)
        else:
            data = tmdb_api.get_movie_details(TMDB_KEY, tmdb_id)
    except Exception as e:
        xbmc.log("TMDB cache fetch error: %s" % e, xbmc.LOGERROR)
        data = None

    if data:
        with _tmdb_lock:
            cache[cache_key] = {"data": data, "ts": now}
        _save_tmdb()
        return data

    if isinstance(entry, dict) and entry.get("data"):
        return entry["data"]
    return None


def clear_tmdb_cache():
    import os
    try:
        if os.path.exists(TMDB_CACHE_FILE):
            os.remove(TMDB_CACHE_FILE)
        global _tmdb_mem_cache
        _tmdb_mem_cache = {}
        _notify("Mezipaměť TMDB byla úspěšně vymazána.")
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        _notify("Chyba při mazání TMDB mezipaměti.")
