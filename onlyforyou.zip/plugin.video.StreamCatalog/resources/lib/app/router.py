# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

from resources.lib.api_client import clear_csfd_cache, clear_tmdb_cache
from resources.lib.auth import do_login, show_account_info
from resources.lib.config import addon
from resources.lib.downloads import delete_local_file, download_file, export_to_strm, show_downloads
from resources.lib.gui import (
    collections_root,
    font_test,
    kids_cz_movies,
    kids_discover,
    kids_vecernicky,
    kids_world_menu,
    main_menu,
    movies_menu,
    remove_series_from_watched,
    show_active_series,
    show_collection,
    show_country_list,
    show_country_movies,
    show_custom_folder,
    show_favorites,
    show_genre_list,
    show_genre_movies,
    show_in_progress_list,
    show_submenu_children,
    show_tmdb_feed,
    show_kids_in_progress,
    show_trending_movies,
    show_trending_shows,
    show_watched_list,
    shows_menu,
)
from resources.lib.local_db import (
    add_favorite,
    clear_search_history,
    clear_watched_history,
    delete_search_item,
    remove_favorite,
    watched_add,
    watched_remove,
)
from resources.lib.player import play_file, play_from_here
from resources.lib.speedtest import run_measurement_ui as _run_speedtest_ui
from resources.lib.presentation.kodi.catalog_views import render_person_credits
from resources.lib.search import _do_search_person, alphabet_root, alphabet_search, do_search, search_menu, search_more
from resources.lib.tvshows import show_episode_variants, show_episodes, show_series_list, toggle_autoplay_mode
from resources.lib.media_core import select_quality, show_quality_select
from resources.lib.utils import _fail


def _route_resume_watching(params):
    if params.get("type") == "tv":
        return show_active_series(params.get("is_kids", "false"))
    return show_in_progress_list()


def _show_placeholder(params):
    name = addon.getAddonInfo("name") or "Addon"
    xbmcgui.Dialog().ok(
        name,
        "Pracujeme na tom!\n\nSložka '%s' bude přidána v další aktualizaci." % params.get("msg", ""),
    )


def _open_settings():
    addon.openSettings()
    _fail()


def _kids_search(_params):
    search_menu(search_id="kids", is_kids="true")


def _build_routes():
    return {
        None: lambda _params: main_menu(),
        "movies_menu": lambda _params: movies_menu(),
        "shows_menu": lambda _params: shows_menu(),
        "kids_world_menu": lambda _params: kids_world_menu(),
        "kids_world": lambda _params: kids_world_menu(),
        "placeholder_msg": _show_placeholder,
        "show_favorites": lambda params: show_favorites(params.get("media_type", "movie")),
        "add_favorite": lambda params: add_favorite(
            params.get("tmdb_id", ""),
            params.get("title", ""),
            params.get("media_type", "movie"),
            params.get("poster", ""),
            params.get("backdrop", ""),
            params.get("year", ""),
            params.get("orig_title", ""),
            params.get("season", ""),
            params.get("episode", ""),
        ),
        "remove_favorite": lambda params: remove_favorite(params.get("item_key", ""), params.get("media_type", "movie")),
        "show_downloads": lambda params: show_downloads(params.get("media_type", "movie")),
        "download_file": lambda params: download_file(params.get("ident", ""), params.get("title", "")),
        "delete_local_file": lambda params: delete_local_file(params.get("filepath", "")),
        "export_strm": lambda params: export_to_strm(
            params.get("ident", ""),
            params.get("title", ""),
            params.get("media_type", "movie"),
            params.get("season", ""),
            params.get("episode", ""),
        ),
        "in_progress_list": lambda _params: show_in_progress_list(),
        "resume_watching": _route_resume_watching,
        "play": lambda params: play_file(
            params.get("ident", ""),
            params.get("title", ""),
            params.get("media_type", "movie"),
            params.get("size", ""),
            is_kids=params.get("is_kids", "false"),
            provider=params.get("provider", "webshare"),
            status=params.get("status", ""),
            season=params.get("season", ""),
            episode=params.get("episode", ""),
            tmdb_id=params.get("tmdb_id", ""),
            ns_chain=params.get("ns_chain", ""),
            stream_type=params.get("stream_type", ""),
        ),
        "add_watched": lambda params: watched_add(
            params.get("ident", ""),
            params.get("title", ""),
            params.get("size", ""),
            media_type=params.get("media_type", "movie"),
            tmdb_id=params.get("tmdb_id", ""),
        ),
        "remove_watched": lambda params: watched_remove(params.get("ident", "")),
        "search_menu": lambda params: search_menu(params.get("search_id", ""), params.get("is_kids", "false")),
        "do_search": lambda params: do_search(params.get("search_id", ""), params.get("query", "")),
        "do_search_person": lambda params: _do_search_person(params.get("query", ""), params.get("page", 1)),
        "person_credits": lambda params: render_person_credits(
            params.get("person_id", ""),
            params.get("person_name", ""),
            page=int(params.get("page", 1)),
        ),
        "delete_search_item": lambda params: delete_search_item(params.get("query", ""), params.get("search_id", "")),
        "clear_search_history": lambda params: clear_search_history(params.get("search_id", "")),
        "clear_watched_history": lambda _params: clear_watched_history(),
        "clear_csfd_cache": lambda _params: clear_csfd_cache(),
        "clear_tmdb_cache": lambda _params: clear_tmdb_cache(),
        "search_more": lambda params: search_more(
            params.get("keyword", ""),
            params.get("search_id", "movie"),
            int(params.get("page", 1)),
        ),
        "genre_list": lambda params: show_genre_list(params.get("media_type", "movie")),
        "genre_movies": lambda params: show_genre_movies(
            params.get("genre_id", ""),
            params.get("genre_name", ""),
            params.get("media_type", "movie"),
            int(params.get("page", 1)),
        ),
        "country_list": lambda params: show_country_list(params.get("media_type", "movie")),
        "country_movies": lambda params: show_country_movies(
            params.get("country_code", ""),
            params.get("country_name", ""),
            params.get("media_type", "movie"),
            int(params.get("page", 1)),
        ),
        "trending_movies": lambda params: show_trending_movies(int(params.get("page", 1))),
        "trending_shows": lambda params: show_trending_shows(int(params.get("page", 1))),
        "tmdb_feed": lambda params: show_tmdb_feed(
            media_type=params.get("media_type", "movie"),
            feed=params.get("feed", "popular"),
            page=int(params.get("page", 1)),
        ),
        "select_quality": lambda params: select_quality(
            params.get("title", ""),
            params.get("year", ""),
            params.get("orig_title", ""),
            params.get("tmdb_id", ""),
            params.get("media_type", "movie"),
            is_kids=params.get("is_kids", "false"),
        ),
        "quality_select": lambda params: show_quality_select(
            params.get("variants", "[]"),
            params.get("media_type", "movie"),
            params.get("poster", ""),
            params.get("backdrop", ""),
            params.get("orig_title", ""),
            params.get("year", ""),
            tmdb_id=params.get("tmdb_id", ""),
            is_kids=params.get("is_kids", "false"),
            tmdb_title=params.get("tmdb_title", ""),
        ),
        "series_list": lambda params: show_series_list(
            params.get("serial_title", ""),
            params.get("serial_year", ""),
            params.get("serial_original_name", ""),
            params.get("tmdb_id", ""),
            params.get("num_seasons", 0),
            is_kids=params.get("is_kids", "false"),
        ),
        "episodes": lambda params: show_episodes(
            params.get("serial_title", ""),
            params.get("season", 1),
            params.get("serial_year", ""),
            params.get("serial_original_name", ""),
            params.get("tmdb_id", ""),
            is_kids=params.get("is_kids", "false"),
            focus_episode=params.get("focus_episode", ""),
            resume_ident=params.get("resume_ident", ""),
            resume_time=params.get("resume_time", ""),
            resume_total=params.get("resume_total", ""),
        ),
        "play_from_here": lambda params: play_from_here(
            params.get("serial_title", ""),
            params.get("season", 1),
            params.get("start_ep", 1),
            params.get("serial_year", ""),
            params.get("serial_original_name", ""),
            params.get("tmdb_id", ""),
            is_kids=params.get("is_kids", "false"),
            resume_ident=params.get("resume_ident", ""),
            resume_time=params.get("resume_time", ""),
            resume_total=params.get("resume_total", ""),
        ),
        "episode_variants": lambda params: show_episode_variants(
            params.get("variants", "[]"),
            params.get("season", 1),
            params.get("ep_num", 1),
            params.get("ep_name", ""),
            params.get("ep_plot", ""),
            params.get("orig_title", ""),
            params.get("tmdb_id", ""),
            is_kids=params.get("is_kids", "false"),
            serial_title=params.get("serial_title", ""),
        ),
        "alphabet_root": lambda params: alphabet_root(params.get("prefix", ""), params.get("media_type", "movie")),
        "alphabet_search": lambda params: alphabet_search(params.get("prefix", "A"), params.get("media_type", "movie")),
        "watched_list": lambda params: show_watched_list(params.get("media_type", "movie")),
        "account_info": lambda _params: show_account_info(),
        "do_login": lambda _params: do_login(),
        "active_series": lambda params: show_active_series(params.get("is_kids", "false")),
        "remove_series_from_watched": lambda params: remove_series_from_watched(
            params.get("show_name", ""),
            params.get("is_kids", "false"),
        ),
        "measure_speed": lambda _params: _run_speedtest_ui(),
        "settings": lambda _params: _open_settings(),
        "toggle_autoplay_mode": lambda _params: toggle_autoplay_mode(),
        "collections_root": lambda _params: collections_root(),
        "show_collection": lambda params: show_collection(params.get("coll_id", "")),
        "kids_in_progress": lambda _params: show_kids_in_progress(),
        "kids_search": _kids_search,
        "kids_discover": lambda params: kids_discover(
            m_type=params.get("m_type", "movie"),
            page=int(params.get("page", 1)),
        ),
        "kids_vecernicky": lambda params: kids_vecernicky(page=params.get("page", 1)),
        "kids_cz_movies": lambda params: kids_cz_movies(page=params.get("page", 1)),
        "submenu_children": lambda params: show_submenu_children(
            params.get("menu_type", "movies"),
            int(params.get("parent_id", 0)),
            params.get("title", ""),
        ),
        "custom_folder": lambda params: show_custom_folder(
            params.get("items", params.get("tmdb_ids", "")),
            params.get("media_type", "movie"),
            int(params.get("page", 1)),
        ),
        "font_test": lambda _params: font_test(),
    }


def dispatch(params):
    try:
        _m = params.get("mode") or ""
        xbmc.log("%s plugin entry mode=%s" % (addon.getAddonInfo("id"), _m if _m else "home"), xbmc.LOGINFO)
    except Exception:
        pass
    mode = params.get("mode")
    routes = _build_routes()
    handler = routes.get(mode)
    if handler is None:
        return main_menu()
    return handler(params)
