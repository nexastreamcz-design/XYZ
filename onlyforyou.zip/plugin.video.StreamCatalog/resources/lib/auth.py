# -*- coding: utf-8 -*-
import os
import json
import xbmc
import xbmcgui
import webshare
from resources.lib.config import addon, TOKEN_FILE
from resources.lib.utils import _fail


def _load_token():
    try:
        if os.path.exists(TOKEN_FILE):
            data = json.load(open(TOKEN_FILE, 'r'))
            if 'username' not in data:
                return data.get('token')
            current_user = addon.getSetting('username')
            current_pass = addon.getSetting('password')
            if data.get('username') != current_user or data.get('password') != current_pass:
                os.remove(TOKEN_FILE)
                return None
            return data.get('token')
    except Exception:
        pass
    return None


def _save_token(token):
    try:
        current_user = addon.getSetting('username')
        current_pass = addon.getSetting('password')
        json.dump({'token': token, 'username': current_user, 'password': current_pass}, open(TOKEN_FILE, 'w'))
    except Exception:
        pass


def _get_token(force=False):
    if not force:
        t = _load_token()
        if t:
            return t
    username = addon.getSetting('username')
    password = addon.getSetting('password')
    if not username or not password:
        return None
    token = webshare.login(username, password)
    if token:
        _save_token(token)
    return token


def do_login():
    name = addon.getAddonInfo('name') or 'Addon'
    xbmcgui.Dialog().ok(
        name,
        'Zadejte přihlašovací údaje k WebShare a případně FastShare v nastavení doplňku.',
    )
    addon.openSettings()
    return _fail()


def show_account_info():
    token = _load_token()
    if not token:
        return _fail('Nejste přihlášeni k WebShare.')
    try:
        xml = webshare._post('user_data', {}, token=token)
        if xml and webshare._x(xml, 'status') == 'OK':
            username = webshare._x(xml, 'username')
            email = webshare._x(xml, 'email')
            vip = webshare._x(xml, 'vip') == '1'
            vip_days = webshare._x(xml, 'vip_days')
            vip_text = ('ANO (%s dní)' % vip_days) if (vip and vip_days) else ('ANO' if vip else 'NE (viz webshare.cz)')
            xbmcgui.Dialog().ok('WebShare účet', 'Uživatel: %s\nE-mail: %s\nVIP: %s' % (username, email, vip_text))
    except Exception as e:
        name = addon.getAddonInfo('name') or 'Addon'
        xbmcgui.Dialog().ok(name, 'Nelze načíst data účtu:\n%s' % str(e))
    _fail()


def _show_account_status():
    from resources.lib.utils import _add_dir, _url
    import os as _os
    addon_path = addon.getAddonInfo('path')
    if hasattr(addon_path, 'decode'):
        addon_path = addon_path.decode('utf-8')
    bg_ucet = _os.path.join(addon_path, 'fanart', 'bg_ucet.jpg')

    token = _load_token()
    if not token and addon.getSetting('username') and addon.getSetting('password'):
        token = _get_token()

    ws_badge = ' [COLOR gray][Nepřihlášeno][/COLOR]'
    ws_user = addon.getSetting('username') or '?'

    if token:
        # Máme token => uživatel je přihlášen minimálně lokálně.
        # Pokud selže user_data (dočasný výpadek/timeout), nezobrazuj falešně "Nepřihlášeno".
        ws_badge = ' [COLOR deepskyblue][Přihlášeno][/COLOR]'
        try:
            xml = webshare._post('user_data', {}, token=token)
            if not (xml and webshare._x(xml, 'status') == 'OK'):
                # Zkus jednorázový refresh tokenu z uložených přihlašovacích údajů.
                token = _get_token(force=True) or token
                xml = webshare._post('user_data', {}, token=token)
            if xml and webshare._x(xml, 'status') == 'OK':
                ws_user = webshare._x(xml, 'username') or ws_user
                vip_days = webshare._x(xml, 'vip_days')
                if webshare._x(xml, 'vip') == '1':
                    ws_badge = ' [COLOR lime][VIP | %s dní][/COLOR]' % vip_days if vip_days else ' [COLOR lime][VIP][/COLOR]'
                else:
                    ws_badge = ' [COLOR gray][Free][/COLOR]'
        except Exception:
            pass

    _add_dir(
        '[B]WebShare:[/B] %s%s' % (ws_user, ws_badge),
        _url(mode='account_info'),
        img='DefaultAddonService.png',
        fanart=bg_ucet,
        is_folder=False,
    )

    fs_user = addon.getSetting('fs_username')
    if fs_user:
        _add_dir('[B]FastShare:[/B] %s [COLOR deepskyblue][Aktivní][/COLOR]' % fs_user, _url(mode='settings'), img='DefaultAddonService.png', fanart=bg_ucet)
    else:
        _add_dir('[B]FastShare:[/B] [COLOR gray][Nepřihlášeno][/COLOR]', _url(mode='settings'), img='DefaultAddonService.png', fanart=bg_ucet)
