# -*- coding: utf-8 -*-
import os
import sys
import xbmcaddon
import xbmc

try:
    import xbmcvfs
    _translate_path = xbmcvfs.translatePath
except (ImportError, AttributeError):
    _translate_path = xbmc.translatePath

# Kodi add-on id (must match folder name and addon.xml id).
ADDON_ID = "plugin.video.streamcatalog"

addon        = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_url    = sys.argv[0]

profile_path = _translate_path(addon.getAddonInfo('profile'))
if not os.path.exists(profile_path):
    try: os.makedirs(profile_path)
    except: pass

WATCHED_FILE = os.path.join(profile_path, 'watched.json')
CSFD_CACHE_FILE = os.path.join(profile_path, 'csfd_cache.json')
TMDB_CACHE_FILE = os.path.join(profile_path, 'tmdb_cache.json')
TOKEN_FILE   = os.path.join(profile_path, 'ws_token.json')
SEARCH_FILE  = os.path.join(profile_path, 'search.json')
TMDB_KEY     = addon.getSetting('tmdb_api_key') or 'a9d851cb36fd8287fed226766d7f01ab'

STRM_PATH = os.path.join(profile_path, 'library')
STRM_MOVIES = os.path.join(STRM_PATH, 'movies')
STRM_TVSHOWS = os.path.join(STRM_PATH, 'tvshows')

for p in [STRM_MOVIES, STRM_TVSHOWS]:
    if not os.path.exists(p):
        try: os.makedirs(p)
        except: pass

COUNTRY_NAMES = {
    'US':'USA','GB':'Velká Británie','CZ':'Česká republika','SK':'Slovensko',
    'DE':'Německo','FR':'Francie','IT':'Itálie','ES':'Španělsko','PL':'Polsko',
    'RU':'Rusko','AU':'Austrálie','CA':'Kanada','JP':'Japonsko','KR':'Jižní Korea',
    'CN':'Čína','IN':'Indie','SE':'Švédsko','NO':'Norsko','DK':'Dánsko',
    'FI':'Finsko','NL':'Nizozemsko','BE':'Belgie','AT':'Rakousko','CH':'Švýcarsko',
    'HU':'Maďarsko','BR':'Brazílie','MX':'Mexiko','AR':'Argentina','ZA':'Jižní Afrika',
    'IE':'Irsko','PT':'Portugalsko','TR':'Turecko','IL':'Izrael','TH':'Thajsko',
}
FEATURED_COUNTRIES_MOVIE  = ['US','GB','CZ','SK','DE','FR','IT','ES','AU','CA','JP','KR','RU','PL','SE','DK','NO']
FEATURED_COUNTRIES_TVSHOW = ['US','GB','CZ','SK','DE','FR','KR','JP','SE','DK','NO','AU','CA','RU','PL']

QUALITY_PATTERN = (
    r'\b(720p|1080p|2160p|4K|UHD|BluRay|BRRip|WEBRip|HDTV|WEB-DL|DVDRip|'
    r'x264|x265|HEVC|H\.264|H\.265|AAC|AC3|DTS|'
    r'CZ|SK|EN|MULTI|DUAL|SUB|DUBBED|'
    r'KINORIP|CAMRIP|TELESYNC|TS|CAM|SCREENER|'
    r'REMUX|PROPER|REPACK|UNRATED|EXTENDED|'
    r'DD5\.1|TrueHD|ATMOS)\b'
)

FAVORITES_FILE = os.path.join(profile_path, 'favorites.json')
