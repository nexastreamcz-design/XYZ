# resources/lib/domain/__init__.py
