# -*- coding: utf-8 -*-
from resources.lib.infrastructure.api.tmdb_client import get_person_combined_credits


def list_person_credits(person_id):
    credits = get_person_combined_credits(person_id)
    seen = set()
    unique_credits = []
    for item in credits:
        tmdb_id = item.get("tmdb_id")
        if not tmdb_id or tmdb_id in seen:
            continue
        seen.add(tmdb_id)
        unique_credits.append(item)
    unique_credits.sort(key=lambda value: value.get("popularity", 0), reverse=True)
    return unique_credits
