# -*- coding: utf-8 -*-
import json

def list_custom_folder_items(raw_items, default_media_type="movie"):
    parsed_items = _parse_items(raw_items, default_media_type)
    if not parsed_items:
        return []
    vip_ids = _safe_vip_ids()
    ordered = []
    for index, item in enumerate(parsed_items):
        tmdb_id = item["tmdb_id"]
        media_type = item.get("media_type", default_media_type)
        ordered.append({"tmdb_id": tmdb_id, "media_type": media_type, "is_vip": str(tmdb_id) in vip_ids, "index": index})
    ordered.sort(key=lambda item: (0 if item["is_vip"] else 1, item["index"]))
    return ordered


def _parse_items(raw_items, default_media_type):
    if not raw_items:
        return []
    try:
        parsed = json.loads(raw_items)
        if isinstance(parsed, list):
            if parsed and isinstance(parsed[0], dict) and "tmdb_id" in parsed[0]:
                normalized = []
                for item in parsed:
                    try:
                        normalized.append({"tmdb_id": int(item["tmdb_id"]), "media_type": item.get("media_type", default_media_type)})
                    except Exception:
                        continue
                return normalized
            normalized = []
            for value in parsed:
                if isinstance(value, (int, str)) and str(value).isdigit():
                    normalized.append({"tmdb_id": int(value), "media_type": default_media_type})
            return normalized
    except Exception:
        pass
    try:
        values = [int(value.strip()) for value in raw_items.split(",") if value.strip().isdigit()]
        return [{"tmdb_id": value, "media_type": default_media_type} for value in values]
    except Exception:
        return []


def _safe_vip_ids():
    return set()
