# -*- coding: utf-8 -*-
import re

from resources.lib.infrastructure.api.tmdb_client import get_tv_season
from resources.lib.local_db import _load_watched, _save_watched
from resources.lib.utils import clean_title, format_size


def get_in_progress_items(is_kids=False):
    target_flag = "true" if is_kids else "false"
    items = []
    for ident, data in _load_watched().items():
        if data.get("resume_time", 0) <= 0:
            continue
        if data.get("playcount", 0) != 0:
            continue
        if data.get("media_type") != "movie":
            continue
        if data.get("is_kids", "false") != target_flag:
            continue
        items.append(_build_progress_item(ident, data))
    items.sort(key=lambda item: item["data"].get("time", 0), reverse=True)
    return items


def get_active_series_items(is_kids=False):
    watched = _load_watched()
    target_flag = "true" if is_kids else "false"
    active_shows = {}
    for _, data in watched.items():
        item_is_kids = data.get("is_kids", "false")
        if item_is_kids != target_flag:
            continue
        clean_value = clean_title(data.get("title", ""), remove_quality=True)
        show_name = _extract_show_name(data, clean_value)
        has_episode_pattern = bool(re.search(r"(?i)(.*?)\s+S\d{1,2}E\d{1,2}", clean_value))
        if not show_name or not (has_episode_pattern or data.get("media_type") == "episode"):
            continue
        current = active_shows.get(show_name)
        candidate = _build_active_show_entry(show_name, data, current)
        if candidate is not None:
            active_shows[show_name] = candidate

    result = []
    for show_name, show_data in active_shows.items():
        last_episode = _find_last_episode_for_show(watched, show_name, show_data.get("season", ""))
        if last_episode is None:
            continue
        metadata = _resolve_episode_metadata(show_data, last_episode)
        result.append({"show_name": show_name, "show_data": show_data, "last_episode": last_episode, "metadata": metadata})
    result.sort(key=lambda item: item["show_data"].get("time", 0), reverse=True)
    return result


def remove_series_from_history(show_name, is_kids=False):
    watched = _load_watched()
    target_flag = "true" if is_kids else "false"
    to_remove = []
    for ident, data in watched.items():
        if data.get("is_kids", "false") != target_flag:
            continue
        clean_value = clean_title(data.get("title", ""), remove_quality=True)
        item_show_name = _extract_show_name(data, clean_value)
        if item_show_name and item_show_name == show_name:
            to_remove.append(ident)
    for ident in to_remove:
        del watched[ident]
    _save_watched(watched)
    return len(to_remove)


def _build_progress_item(ident, data):
    raw_title = data.get("title", "")
    size_str = data.get("size", "")
    try:
        if size_str and str(size_str).strip().isdigit():
            size_str = format_size(int(str(size_str).strip()))
    except (TypeError, ValueError):
        pass
    provider = _normalize_provider(ident, data.get("provider"))
    clean_value = clean_title(raw_title, remove_quality=True) or "Neznámý titul"
    if not size_str:
        size_match = re.search(r"\[(\d+(?:\.\d+)?\s*(?:GB|MB))\]", raw_title, flags=re.I)
        if size_match:
            size_str = size_match.group(1)
    persisted = (data.get("stream_type") or "").strip().upper()
    if persisted in ("VIP", "APPROVED", "HELLSPY"):
        stream_type = persisted
    elif persisted == "STANDARD":
        stream_type = "STANDARD"
    else:
        stream_type = _resolve_stream_type(raw_title, provider)
    return {
        "ident": ident,
        "data": data,
        "raw_title": raw_title,
        "size_str": size_str,
        "provider": provider,
        "clean_title": clean_value,
        "stream_type": stream_type,
    }


def _extract_show_name(data, clean_title_value):
    show_name = data.get("series_title")
    if show_name:
        return show_name
    match = re.search(r"(?i)(.*?)\s+S\d{1,2}E\d{1,2}", clean_title_value)
    return match.group(1).strip() if match else clean_title_value


def _build_active_show_entry(show_name, data, current):
    timestamp = data.get("time", 0)
    tmdb_id = data.get("tmdb_id", "")
    season = data.get("season", "")
    should_update = False
    if current is None:
        should_update = True
    else:
        existing_has_id = bool(current.get("tmdb_id"))
        new_has_id = bool(tmdb_id)
        if new_has_id and not existing_has_id:
            should_update = True
        elif not existing_has_id and not new_has_id and timestamp > current.get("time", 0):
            should_update = True
        elif existing_has_id and new_has_id and timestamp > current.get("time", 0):
            should_update = True
    if not should_update:
        return None

    image = data.get("img", "")
    if (not image or image == "DefaultTVShows.png") and current and current.get("img") != "DefaultTVShows.png":
        image = current.get("img")
    if not image:
        image = "DefaultTVShows.png"
    return {
        "time": timestamp,
        "img": image,
        "tmdb_id": tmdb_id,
        "season": season,
        "orig_title": data.get("orig_title", show_name),
    }


def _find_last_episode_for_show(watched, show_name, season):
    last_episode = None
    for ident, data in watched.items():
        if data.get("media_type") != "episode":
            continue
        clean_value = clean_title(data.get("title", ""), remove_quality=True)
        item_show_name = _extract_show_name(data, clean_value)
        if item_show_name != show_name:
            continue
        if data.get("resume_time", 0) <= 0 or data.get("playcount", 0) != 0:
            continue
        ep_season = data.get("season", "")
        ep_num = data.get("episode", "")
        if not ep_season or not ep_num or str(ep_season) != str(season):
            continue
        if not last_episode or data.get("time", 0) > last_episode.get("time", 0):
            last_episode = {
                "season": ep_season,
                "episode": ep_num,
                "time": data.get("time", 0),
                "ident": ident,
                "resume_time": data.get("resume_time", 0),
                "total_time": data.get("total_time", 0),
                "provider": data.get("provider", ""),
                "size": data.get("size", ""),
                "raw_title": data.get("title", ""),
                "url": data.get("url", ""),
                "stream_type": data.get("stream_type", ""),
            }
    return last_episode


def _resolve_episode_metadata(show_data, last_episode):
    fallback_image = show_data.get("img", "DefaultTVShows.png")
    result = {"episode_name": "", "episode_plot": "", "episode_still": "", "season_poster": fallback_image}
    tmdb_id = show_data.get("tmdb_id", "")
    season = show_data.get("season", "")
    if not tmdb_id or not season or not last_episode:
        return result
    try:
        season_data = get_tv_season(tmdb_id, int(season))
        if not season_data:
            return result
        if season_data.get("poster_path"):
            result["season_poster"] = "https://image.tmdb.org/t/p/w500" + season_data["poster_path"]
        for episode in season_data.get("episodes", []):
            if episode.get("episode_number") != int(last_episode["episode"]):
                continue
            result["episode_name"] = episode.get("name", "")
            result["episode_plot"] = episode.get("overview", "")
            if episode.get("still_path"):
                result["episode_still"] = "https://image.tmdb.org/t/p/w500" + episode["still_path"]
            break
    except Exception:
        return result
    return result


def _normalize_provider(ident, provider):
    if not provider:
        return "fastshare" if "fastshare" in str(ident).lower() else "webshare"
    if provider == "FS":
        return "fastshare"
    if provider == "WS":
        return "webshare"
    return provider


def _resolve_stream_type(raw_title, provider):
    if "★" in raw_title or "TREZOR" in raw_title or "VIP" in raw_title:
        return "VIP"
    if "[Q]" in raw_title:
        return "APPROVED"
    if provider in ("HELLSPY", "HL"):
        return "HELLSPY"
    return "STANDARD"
