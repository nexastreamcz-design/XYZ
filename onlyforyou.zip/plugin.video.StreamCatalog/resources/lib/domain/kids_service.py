# -*- coding: utf-8 -*-
from resources.lib.infrastructure.api.tmdb_kids_client import fetch_kids_cz_movies, fetch_kids_discover, fetch_kids_vecernicky


def list_kids_vecernicky(page=1):
    results, total_pages = fetch_kids_vecernicky(page=page)
    vip_ids = _safe_vip_ids()
    results.sort(key=lambda item: (0 if str(item.get("id", "")) in vip_ids else 1, -_safe_vote(item)))
    for item in results:
        item["is_kids"] = True
    return results, total_pages


def list_kids_cz_movies(page=1):
    results, total_pages = fetch_kids_cz_movies(page=page)
    vip_ids = _safe_vip_ids()
    results.sort(key=lambda item: (0 if str(item.get("id", "")) in vip_ids else 1, -_safe_vote(item)))
    for item in results:
        item["is_kids"] = True
    return results, total_pages


def list_kids_discover(media_type="movie"):
    source_items = fetch_kids_discover(media_type=media_type)
    seen_ids = set()
    results = []
    for item in source_items:
        if item.get("original_language", "") in ["ja", "zh", "ko", "cn"]:
            continue
        tmdb_id = str(item.get("id", ""))
        if not tmdb_id or tmdb_id in seen_ids:
            continue
        seen_ids.add(tmdb_id)
        item["is_kids"] = True
        results.append(item)
    vip_ids = _safe_vip_ids()
    results.sort(key=lambda item: (0 if str(item.get("id", "")) in vip_ids else 1, -item.get("popularity", 0)))
    return results


def _safe_vip_ids():
    return set()


def _safe_vote(item):
    try:
        return float(item.get("vote_average") or 0.0)
    except Exception:
        return 0.0
