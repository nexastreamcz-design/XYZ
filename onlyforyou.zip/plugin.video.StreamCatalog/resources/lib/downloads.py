# -*- coding: utf-8 -*-
import os
import re
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import webshare
from resources.lib.config import addon, addon_handle, STRM_MOVIES, STRM_TVSHOWS
from resources.lib.utils import _notify, _url, _set_info, _end, _fail, get_ssl_context
from resources.lib.auth import _get_token


def _an():
    try:
        return addon.getAddonInfo('name') or 'StreamCatalog'
    except Exception:
        return 'StreamCatalog'


def export_to_strm(ident, title, media_type='movie', season='', episode=''):
    safe_title = re.sub(r'[\\/*?:"<>|]', "", title)
    if media_type == 'episode':
        folder_path = os.path.join(STRM_TVSHOWS, safe_title)
        if not os.path.exists(folder_path): os.makedirs(folder_path)
        file_path = os.path.join(folder_path, f"{safe_title} S{int(season):02d}E{int(episode):02d}.strm")
    else:
        folder_path = os.path.join(STRM_MOVIES, safe_title)
        if not os.path.exists(folder_path): os.makedirs(folder_path)
        file_path = os.path.join(folder_path, f"{safe_title}.strm")

    url = _url(mode='play', ident=ident, title=title, media_type=media_type)
    try:
        with open(file_path, 'w', encoding='utf-8') as f: f.write(url)
        _notify('Exportováno do knihovny Kodi!')
        xbmc.executebuiltin('UpdateLibrary(video)')
    except Exception as e:
        _notify(f'Chyba exportu: {e}', xbmcgui.NOTIFICATION_ERROR)

def show_downloads(media_type='movie'):
    try:
        xbmcplugin.setContent(addon_handle, 'movies' if media_type == 'movie' else 'tvshows')
        download_dir = addon.getSetting('download_dir')
        if not download_dir:
            xbmcgui.Dialog().ok('%s - Stažené' % _an(), 'Složka pro stahování není nastavena.\nBěžte prosím do nastavení doplňku (záložka Stahování) a složku vyberte.')
            return _fail()
        import xbmcvfs
        if not xbmcvfs.exists(download_dir):
            xbmcgui.Dialog().ok('%s - Stažené' % _an(), f'Nastavená složka neexistuje nebo k ní Kodi nemá přístup:\n{download_dir}')
            return _fail()
        prog = xbmcgui.DialogProgress()
        prog.create(_an(), 'Načítám lokální soubory...')
        has_files, valid_exts = False, ('.mkv', '.mp4', '.avi', '.ts')
        try:
            dirs, files = xbmcvfs.listdir(download_dir)
            for item in files:
                if item.lower().endswith(valid_exts):
                    has_files = True
                    title = item.rsplit('.', 1)[0]
                    item_path = download_dir.rstrip('\\/') + '/' + item
                    li = xbmcgui.ListItem(f"[COLOR lime]{title}[/COLOR]")
                    li.setProperty('IsPlayable', 'true')
                    li.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})
                    _set_info(li, {'title': title, 'mediatype': media_type})
                    li.addContextMenuItems([('Smazat soubor', f'RunPlugin({_url(mode="delete_local_file", filepath=item_path)})')])
                    xbmcplugin.addDirectoryItem(addon_handle, item_path, li, False)
        finally: prog.close()
        if not has_files: return _fail('Ve složce nejsou žádné stažené video soubory.')
        _end()
    except Exception as e: xbmcgui.Dialog().ok('Kritická chyba doplňku', f'Nastala neočekávaná chyba:\n{str(e)}'); return _fail()

def delete_local_file(filepath):
    try:
        filename = filepath.replace('\\', '/').rstrip('/').split('/')[-1]
        if xbmcgui.Dialog().yesno('Smazat soubor?', f'Opravdu chcete trvale smazat tento soubor?\n\n[B]{filename}[/B]', nolabel='Ne', yeslabel='Ano'):
            import xbmcvfs
            xbmcvfs.delete(filepath)
            _notify('Soubor byl úspěšně smazán.')
            xbmc.executebuiltin('Container.Refresh')
    except Exception as e: _notify(f'Chyba při mazání: {str(e)}', xbmcgui.NOTIFICATION_ERROR)

def download_file(ident, title):
    try:
        download_dir = addon.getSetting('download_dir')
        if not download_dir: xbmcgui.Dialog().ok(_an(), 'Nejprve vyberte složku pro stahování v nastavení doplňku.'); return
        import xbmcvfs
        if not xbmcvfs.exists(download_dir): xbmcgui.Dialog().ok(_an(), 'Nastavená složka pro stahování neexistuje.'); return
        if str(ident).startswith('http'): link = ident
        else:
            token = _get_token()
            if not token: return
            link = webshare.get_file_link(token, ident)
        if not link: _notify('Nepodařilo se získat odkaz ke stažení', xbmcgui.NOTIFICATION_ERROR); return
        safe_title = re.sub(r'\[/?[Cc][Oo][Ll][Oo][Rr][^\]]*\]', '', title, flags=re.I).strip()
        safe_title = re.sub(r'[\\/*?:"<>|]', "", safe_title)
        ext = '.mkv'
        if '.' in link.split('?')[0].split('/')[-1]: ext = '.' + link.split('?')[0].split('/')[-1].split('.')[-1]
        filepath = download_dir.rstrip('\\/') + '/' + safe_title + ext
        if xbmcvfs.exists(filepath):
            if not xbmcgui.Dialog().yesno(_an(), f'Soubor {safe_title}{ext} již existuje.\nChcete ho přepsat?'): return
            xbmcvfs.delete(filepath)
        prog = xbmcgui.DialogProgress()
        prog.create(_an(), f'Připojuji se k serveru...\n{safe_title}')
        try:
            # Ošetření SSL kontextu při stahování
            ctx = get_ssl_context()
            req = urllib.request.urlopen(link, timeout=10, context=ctx)
            
            total_size = int(req.headers.get('content-length', 0))
            chunk_size, downloaded = 1024 * 1024 * 2, 0
            f = xbmcvfs.File(filepath, 'w')
            while True:
                if prog.iscanceled(): f.close(); xbmcvfs.delete(filepath); _notify('Stahování zrušeno.'); return
                chunk = req.read(chunk_size)
                if not chunk: break
                f.write(bytearray(chunk)); downloaded += len(chunk)
                if total_size > 0: prog.update(int((downloaded / total_size) * 100), f'Stahuji: {safe_title}\nStaženo: {downloaded/1048576.0:.1f} MB z {total_size/1048576.0:.1f} MB')
                else: prog.update(0, f'Stahuji: {safe_title}\nStaženo: {downloaded/1048576.0:.1f} MB')
            f.close(); prog.close(); xbmcgui.Dialog().ok(_an(), 'Stahování úspěšně dokončeno!')
        except Exception as e: prog.close(); xbmcgui.Dialog().ok('Chyba stahování', f'Došlo k chybě:\n{str(e)}')
    except Exception as e: xbmcgui.Dialog().ok('Kritická chyba', f'Nastala neočekávaná chyba:\n{str(e)}')