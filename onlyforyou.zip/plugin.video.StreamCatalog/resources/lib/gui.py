# -*- coding: utf-8 -*-
import json
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import tmdb_api
from resources.lib.config import addon, addon_handle, TMDB_KEY, COUNTRY_NAMES, FEATURED_COUNTRIES_MOVIE, FEATURED_COUNTRIES_TVSHOW
from resources.lib.utils import _url, _add_dir, _set_info, _end, _fail, clean_title, get_ssl_context, perf_start, perf_mark_items, perf_end
from resources.lib.auth import _show_account_status
from resources.lib.local_db import _load_watched, _load_favorites
from resources.lib.media_core import _add_tmdb_item
from resources.lib.presentation.kodi.custom_folder_views import render_custom_folder
from resources.lib.presentation.kodi.kids_views import render_kids_cz_movies, render_kids_discover, render_kids_vecernicky
from resources.lib.presentation.kodi.progress_views import render_in_progress_list
from resources.lib.presentation.kodi.series_views import render_active_series, remove_series_and_refresh

def main_menu():
    perf_tag = 'gui.main_menu'
    perf_start(perf_tag)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.setContent(addon_handle, 'videos')
    if addon.getSetting('show_movies') != 'false':
        _add_dir('[B]Filmy[/B]', _url(mode='movies_menu'), img='DefaultMovies.png', plot='Prohlížení filmů podle žánrů, států, kolekcí nebo trendů.')
        perf_mark_items(perf_tag, 1)
    if addon.getSetting('show_shows') != 'false':
        _add_dir('[B]Seriály[/B]', _url(mode='shows_menu'), img='DefaultTVShows.png', plot='Seznam populárních seriálů, novinek a historie vašich rozkoukaných titulů.')
        perf_mark_items(perf_tag, 1)
    if addon.getSetting('show_kids') != 'false':
        _add_dir('[COLOR FF10B981][B]Dětský svět[/B][/COLOR]', _url(mode='kids_world_menu'), img='DefaultVideo.png', plot='Speciální sekce pro nejmenší: pohádky, animáky a české večerníčky bez dospělého obsahu.')
        perf_mark_items(perf_tag, 1)
    
    # Pevné položky (vždy zobrazené)
    _add_dir('[B]Hledání[/B]', _url(mode='search_menu'), img='DefaultAddonsSearch.png', plot='Vyhledávání filmů, seriálů, herců nebo režisérů napříč celou databází.')
    perf_mark_items(perf_tag, 1)
    _show_account_status()
    # Skrytý diagnostický mode='font_test' lze volat přes plugin URL (?mode=font_test).
    _add_dir('[COLOR gray][B]Nastavení doplňku[/B][/COLOR]', _url(mode='settings'), img='DefaultAddonSettings.png', plot='Konfigurace přihlašovacích údajů k WebShare, TMDB klíče a vzhledu doplňku.')
    perf_mark_items(perf_tag, 1)
    perf_end(perf_tag, extra='http=1')
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)


def font_test():
    xbmcplugin.setContent(addon_handle, 'files')
    tests = [
        ("U+25B6 BLACK RIGHT-POINTING TRIANGLE", "\u25B6"),
        ("U+25BA BLACK RIGHT-POINTING POINTER", "\u25BA"),
        ("U+25B8 BLACK RIGHT-POINTING SMALL TRIANGLE", "\u25B8"),
        ("U+2605 BLACK STAR", "\u2605"),
        ("U+2606 WHITE STAR", "\u2606"),
        ("U+2B50 WHITE MEDIUM STAR (emoji)", "\u2B50"),
        ("U+2665 BLACK HEART SUIT", "\u2665"),
        ("U+2764 HEAVY BLACK HEART", "\u2764"),
        ("U+2705 WHITE HEAVY CHECK MARK", "\u2705"),
        ("U+2713 CHECK MARK", "\u2713"),
        ("U+2714 HEAVY CHECK MARK", "\u2714"),
        ("U+274C CROSS MARK", "\u274C"),
        ("U+2717 BALLOT X", "\u2717"),
        ("U+2718 HEAVY BALLOT X", "\u2718"),
        ("U+23F3 HOURGLASS NOT DONE", "\u23F3"),
        ("U+231B HOURGLASS", "\u231B"),
        ("U+1F31F GLOWING STAR", "\U0001F31F"),
        ("U+1F525 FIRE", "\U0001F525"),
        ("U+1F3AC CLAPPER BOARD", "\U0001F3AC"),
        ("U+25A0 BLACK SQUARE (reference tofu)", "\u25A0"),
        ("U+00BB RIGHT DOUBLE ANGLE (fallback za triangle)", "\u00BB"),
        ("U+2022 BULLET", "\u2022"),
        ("U+2192 RIGHTWARDS ARROW", "\u2192"),
    ]
    for name, ch in tests:
        label = f"[B]{ch}[/B]  {ch}{ch}{ch}   {name}"
        li = xbmcgui.ListItem(label)
        li.setArt({'icon': 'DefaultAddonNone.png'})
        try:
            li.getVideoInfoTag().setPlot(f"Znak: {ch}\nOpakování: {ch*10}\nKódový bod: {name}")
        except Exception:
            li.setInfo('video', {'plot': f"Znak: {ch}\nOpakování: {ch*10}\nKódový bod: {name}"})
        xbmcplugin.addDirectoryItem(addon_handle, _url(mode='font_test'), li, False)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)


def movies_menu(): _render_dynamic_menu('movies')
def shows_menu(): _render_dynamic_menu('tv')
def kids_world_menu(): _render_dynamic_menu('kids')

def _render_dynamic_menu(menu_type):
    perf_tag = f'gui.render_menu.{menu_type}'
    perf_start(perf_tag)
    xbmcplugin.setContent(addon_handle, 'files')
    if menu_type == 'movies':
        _add_dir('Hledat film', _url(mode='do_search', search_id='movie'), img='DefaultAddonsSearch.png')
        _add_dir('Pokračovat ve sledování', _url(mode='in_progress_list'), img='DefaultFolder.png')
        _add_dir('[B]Populární filmy[/B]', _url(mode='tmdb_feed', media_type='movie', feed='popular'), img='DefaultMovies.png')
        _add_dir('[B]Nejlépe hodnocené filmy[/B]', _url(mode='tmdb_feed', media_type='movie', feed='top_rated'), img='DefaultMovies.png')
        _add_dir('[B]Trendy filmy (týden)[/B]', _url(mode='tmdb_feed', media_type='movie', feed='trending_week'), img='DefaultMovies.png')
        _add_dir('Právě v kinech', _url(mode='tmdb_feed', media_type='movie', feed='now_playing'), img='DefaultMovies.png')
        _add_dir('Nadcházející premiéry', _url(mode='tmdb_feed', media_type='movie', feed='upcoming'), img='DefaultMovies.png')
        _add_dir('Podle žánru', _url(mode='genre_list', media_type='movie'), img='DefaultGenre.png')
        _add_dir('Podle země', _url(mode='country_list', media_type='movie'), img='DefaultCountry.png')
        perf_mark_items(perf_tag, 9)
    elif menu_type == 'tv':
        _add_dir('Hledat seriál', _url(mode='do_search', search_id='tvshow'), img='DefaultAddonsSearch.png')
        _add_dir('Rozekoukané seriály', _url(mode='active_series', is_kids='false'), img='DefaultFolder.png')
        _add_dir('[B]Populární seriály[/B]', _url(mode='tmdb_feed', media_type='tvshow', feed='popular'), img='DefaultTVShows.png')
        _add_dir('[B]Nejlépe hodnocené seriály[/B]', _url(mode='tmdb_feed', media_type='tvshow', feed='top_rated'), img='DefaultTVShows.png')
        _add_dir('[B]Trendy seriály (týden)[/B]', _url(mode='tmdb_feed', media_type='tvshow', feed='trending_week'), img='DefaultTVShows.png')
        _add_dir('Právě vysílané', _url(mode='tmdb_feed', media_type='tvshow', feed='on_the_air'), img='DefaultTVShows.png')
        _add_dir('Dnes nové epizody', _url(mode='tmdb_feed', media_type='tvshow', feed='airing_today'), img='DefaultTVShows.png')
        _add_dir('Podle žánru', _url(mode='genre_list', media_type='tvshow'), img='DefaultGenre.png')
        _add_dir('Podle země', _url(mode='country_list', media_type='tvshow'), img='DefaultCountry.png')
        perf_mark_items(perf_tag, 9)
    elif menu_type == 'kids':
        _add_dir('[B]Dětské filmy (TMDB)[/B]', _url(mode='kids_discover', m_type='movie'), img='DefaultMovies.png')
        _add_dir('[B]Dětské seriály (TMDB)[/B]', _url(mode='kids_discover', m_type='tvshow'), img='DefaultTVShows.png')
        _add_dir('České pohádky', _url(mode='kids_cz_movies'), img='DefaultMovies.png')
        _add_dir('Večerníčky', _url(mode='kids_vecernicky'), img='DefaultTVShows.png')
        _add_dir('Rozkoukané pro děti', _url(mode='kids_in_progress'), img='DefaultFolder.png')
        perf_mark_items(perf_tag, 5)
    perf_end(perf_tag, extra='local')
    xbmcplugin.endOfDirectory(addon_handle)


def show_submenu_children(menu_type='movies', parent_id=0, title=''):
    return _fail('Toto podmenu již není k dispozici.')

def show_in_progress_list():
    render_in_progress_list(is_kids=False)

def show_watched_list(media_type):
    xbmcplugin.setContent(addon_handle, 'movies' if media_type == 'movie' else 'tvshows')
    valid_types = ['tvshow', 'episode'] if media_type == 'tvshow' else ['movie']
    history_items = [dict(data, ident=ident) for ident, data in _load_watched().items() if data.get('playcount', 0) > 0 and data.get('media_type', 'movie') in valid_types]
    if not history_items: return _fail(f'Zatím nemáte v historii žádné zhlédnuté {"filmy" if media_type == "movie" else "seriály"}.')
    history_items.sort(key=lambda x: x.get('time', 0), reverse=True)
    for data in history_items:
        tmdb_id = data.get('tmdb_id')
        if tmdb_id:
            try:
                tmdb_data = tmdb_api.get_movie_details(TMDB_KEY, tmdb_id) if media_type == 'movie' else tmdb_api.get_tvshow_details(TMDB_KEY, tmdb_id)
                if tmdb_data: _add_tmdb_item(tmdb_data, media_type); continue
            except: pass
        
        # Centralizované čištění
        clean_t = clean_title(data.get('title', 'Neznámý titul'), remove_quality=True)
        
        li = xbmcgui.ListItem(f"[COLOR gray][Zhlédnuto][/COLOR] {clean_t}")
        if data.get('img'): li.setArt({'thumb': data['img']})
        li.setProperty('IsPlayable', 'true')
        _set_info(li, {'title': clean_t, 'mediatype': data.get('media_type', 'movie')})
        ident = data.get('ident')
        li.addContextMenuItems([('Odebrat z historie', f'RunPlugin({_url(mode="remove_watched", ident=ident)})')])
        
        # Pro HELLSPY přidat URL parametr z historie
        provider = data.get('provider', 'webshare')
        play_params = {'mode': 'play', 'ident': ident, 'title': clean_t, 'media_type': data.get('media_type', 'movie'), 'size': data.get('size', ''), 'provider': provider, 'season': data.get('season', '')}
        if provider == 'HELLSPY' and data.get('url'):
            play_params['url'] = data.get('url')
        
        xbmcplugin.addDirectoryItem(addon_handle, _url(**play_params), li, False)
    _end()

def show_favorites(media_type):
    try:
        is_movie_cat = media_type in ['movie', 'kids_movie']
        xbmcplugin.setContent(addon_handle, 'movies' if is_movie_cat else 'tvshows')
        favs = _load_favorites()
        items = []
        if is_movie_cat:
            for k, v in favs.get(media_type, {}).items(): v['item_key'], v['m_type'] = k, 'movie'; items.append(v)
            if media_type == 'movie':
                for k, v in favs.get('collection', {}).items(): v['item_key'], v['m_type'] = k, 'collection'; items.append(v)
        else:
            for k, v in favs.get(media_type, {}).items(): v['item_key'], v['m_type'] = k, 'tvshow'; items.append(v)
            if media_type == 'tvshow':
                for k, v in favs.get('season', {}).items(): v['item_key'], v['m_type'] = k, 'season'; items.append(v)
                for k, v in favs.get('episode', {}).items(): v['item_key'], v['m_type'] = k, 'episode'; items.append(v)
        if not items: xbmcgui.Dialog().ok('Nexa Oblíbené', 'V této složce zatím nemáte žádné položky.\n\nKlikněte pravým tlačítkem na jakýkoliv film nebo seriál a vyberte "Přidat do Nexa Oblíbených".'); return _fail()
        items.sort(key=lambda x: x.get('time', 0), reverse=True)
        for data in items:
            m_type, tmdb_id, title, orig = data['m_type'], data.get('tmdb_id', ''), data.get('title', ''), data.get('orig_title', '')
            if m_type == 'episode':
                season, ep_num = data.get('season', 1), data.get('episode', 1)
                li = xbmcgui.ListItem(f"[COLOR pink]★ {title}[/COLOR]"); li.setArt({'icon': 'DefaultTVShows.png'})
                _set_info(li, {'title': title, 'mediatype': 'episode', 'season': season, 'episode': ep_num})
                li.addContextMenuItems([('Odebrat z Nexa Oblíbených', 'RunPlugin(%s)' % _url(mode='remove_favorite', item_key=data['item_key'], media_type='episode'))])
                xbmcplugin.addDirectoryItem(addon_handle, _url(mode='episodes', serial_title=orig or title, tmdb_id=tmdb_id, season=season, serial_original_name=orig), li, True)
            elif m_type == 'season':
                season = data.get('season', 1)
                label = f"[COLOR pink]★ {title} - Série {season}[/COLOR]"
                li = xbmcgui.ListItem(label); li.setArt({'icon': 'DefaultTVShows.png'})
                _set_info(li, {'title': label, 'mediatype': 'tvshow', 'season': season})
                li.addContextMenuItems([('Odebrat z Nexa Oblíbených', 'RunPlugin(%s)' % _url(mode='remove_favorite', item_key=data['item_key'], media_type='season'))])
                xbmcplugin.addDirectoryItem(addon_handle, _url(mode='episodes', serial_title=orig or title, tmdb_id=tmdb_id, season=season, serial_original_name=orig), li, True)
            elif m_type == 'collection':
                li = xbmcgui.ListItem(f"[COLOR pink]★ {title}[/COLOR]"); li.setArt({'thumb': data.get('poster', ''), 'poster': data.get('poster', ''), 'fanart': data.get('backdrop', ''), 'icon': data.get('poster', '')})
                _set_info(li, {'title': title, 'mediatype': 'movie'})
                li.addContextMenuItems([('Odebrat z Nexa Oblíbených', f'RunPlugin({_url(mode="remove_favorite", item_key=data["item_key"], media_type="collection")})')])
                xbmcplugin.addDirectoryItem(addon_handle, _url(mode='show_collection', coll_id=tmdb_id), li, True)
            else:
                _add_tmdb_item({'id': tmdb_id, 'tmdb_id': tmdb_id, 'title': title, 'orig_title': orig, 'year': data.get('year', ''), 'poster': data.get('poster', ''), 'backdrop': data.get('backdrop', ''), 'is_kids': True if media_type in ['kids_movie', 'kids_tvshow'] else False}, m_type)
        _end()
    except Exception as e: xbmcgui.Dialog().ok('Chyba', str(e)); return _fail()

def show_genre_list(media_type='movie'):
    xbmcplugin.setContent(addon_handle, 'videos')
    for gid, gname in sorted(tmdb_api.get_genres(TMDB_KEY, media_type=media_type), key=lambda g: g[1]): _add_dir('[B]%s[/B]' % gname, _url(mode='genre_movies', genre_id=gid, genre_name=gname, media_type=media_type))
    _end()

def show_genre_movies(genre_id, genre_name, media_type='movie', page=1):
    xbmcplugin.setContent(addon_handle, 'movies' if media_type == 'movie' else 'tvshows')
    page = int(page)
    try: results, total_pages = tmdb_api.discover_movies(TMDB_KEY, genre_id=genre_id, page=page) if media_type == 'movie' else tmdb_api.discover_tvshows(TMDB_KEY, genre_id=genre_id, page=page)
    except: results, total_pages = [], 1
    for item in results: _add_tmdb_item(item, media_type)
    if page < total_pages: _add_dir('[B]>> Dalsi strana (%d/%d)[/B]' % (page + 1, total_pages), _url(mode='genre_movies', genre_id=genre_id, genre_name=genre_name, media_type=media_type, page=page + 1))
    _end()

def show_country_list(media_type='movie'):
    xbmcplugin.setContent(addon_handle, 'videos')
    countries = FEATURED_COUNTRIES_MOVIE if media_type == 'movie' else FEATURED_COUNTRIES_TVSHOW
    def sort_key(code):
        name = COUNTRY_NAMES.get(code, code)
        if code == 'CZ': return (0, name)
        if code == 'SK': return (1, name)
        return (2, name)
    for code in sorted(countries, key=sort_key):
        name = COUNTRY_NAMES.get(code, code)
        _add_dir('[B]%s[/B]' % name, _url(mode='country_movies', country_code=code, country_name=name, media_type=media_type))
    _end()

def show_country_movies(country_code, country_name, media_type='movie', page=1):
    xbmcplugin.setContent(addon_handle, 'movies' if media_type == 'movie' else 'tvshows')
    page = int(page)
    try:
        ctx = get_ssl_context()
        m_type = 'movie' if media_type == 'movie' else 'tv'
        url = f"https://api.themoviedb.org/3/discover/{m_type}?api_key={TMDB_KEY}&language=cs-CZ&sort_by=popularity.desc&with_origin_country={country_code}&page={page}"
        with urllib.request.urlopen(url, context=ctx) as r:
            data = json.loads(r.read().decode('utf-8'))
            results, total_pages = data.get('results', []), data.get('total_pages', 1)
    except Exception as e: xbmc.log(f"NEXASTREAM COUNTRY ERROR: {str(e)}", xbmc.LOGERROR); results, total_pages = [], 1
    if not results: return _fail(f'Zatím nemáme nic pro stát: {country_name}')
    results.sort(key=lambda x: -float(x.get('popularity') or 0.0))
    for item in results:
        item['tmdb_id'] = str(item.get('id', ''))
        item['year'] = (item.get('release_date') or item.get('first_air_date') or '').split('-')[0]
        item['orig_title'] = item.get('original_title') or item.get('original_name') or ''
        if item.get('poster_path'): item['poster'] = 'https://image.tmdb.org/t/p/w500' + item['poster_path']
        if item.get('backdrop_path'): item['backdrop'] = 'https://image.tmdb.org/t/p/w1280' + item['backdrop_path']
        item['title'] = item.get('name', '') if media_type == 'tvshow' else item.get('title', '')
        _add_tmdb_item(item, media_type)
    if page < total_pages: _add_dir(f'[B]>> Další strana ({page + 1}/{total_pages})[/B]', _url(mode='country_movies', country_code=country_code, country_name=country_name, media_type=media_type, page=page + 1))
    _end()

def show_tmdb_feed(media_type='movie', feed='popular', page=1):
    media_type = 'tvshow' if media_type in ('tv', 'tvshow') else 'movie'
    xbmcplugin.setContent(addon_handle, 'tvshows' if media_type == 'tvshow' else 'movies')
    page = int(page)
    try:
        if feed in ('trending_day', 'trending_week'):
            tw = 'day' if feed == 'trending_day' else 'week'
            source_mt = 'tv' if media_type == 'tvshow' else 'movie'
            results = tmdb_api.get_trending(TMDB_KEY, media_type=source_mt, time_window=tw)
            total_pages = 1
        else:
            if media_type == 'tvshow':
                results, total_pages = tmdb_api.list_tvshows(TMDB_KEY, category=feed, page=page)
            else:
                results, total_pages = tmdb_api.list_movies(TMDB_KEY, category=feed, page=page)
        for item in results:
            _add_tmdb_item(item, media_type)
        if feed not in ('trending_day', 'trending_week') and page < total_pages:
            _add_dir(
                f'[B]>> Další strana ({page + 1}/{total_pages})[/B]',
                _url(mode='tmdb_feed', media_type=media_type, feed=feed, page=page + 1)
            )
    except Exception as e:
        xbmc.log(f"StreamCatalog TMDB FEED ERROR [{media_type}/{feed}]: {str(e)}", xbmc.LOGERROR)
        return _fail('Nepodařilo se načíst položky z TMDB.')
    _end()


def show_trending_movies(page=1):
    return show_tmdb_feed(media_type='movie', feed='popular', page=page)


def show_trending_shows(page=1):
    return show_tmdb_feed(media_type='tvshow', feed='popular', page=page)

def collections_root():
    xbmcplugin.setContent(addon_handle, 'movies')
    kolekce_ids = [1241, 119, 10, 86311, 295, 9485, 645, 2344, 328, 8091, 8353, 2150]
    prog = xbmcgui.DialogProgress()
    prog.create(addon.getAddonInfo('name') or 'Addon', 'Načítám Filmové Kolekce...')
    try:
        ctx = get_ssl_context()
        favs = _load_favorites().get('collection', {})
        for coll_id in kolekce_ids:
            if prog.iscanceled(): break
            url = f"https://api.themoviedb.org/3/collection/{coll_id}?api_key={TMDB_KEY}&language=cs-CZ"
            try:
                with urllib.request.urlopen(url, context=ctx) as r: data = json.loads(r.read().decode('utf-8'))
                title, plot = data.get('name', 'Neznámá kolekce'), data.get('overview', '')
                poster = 'https://image.tmdb.org/t/p/w500' + data['poster_path'] if data.get('poster_path') else 'DefaultMovies.png'
                backdrop = 'https://image.tmdb.org/t/p/w1280' + data['backdrop_path'] if data.get('backdrop_path') else ''
                li = xbmcgui.ListItem(f"[B]{title}[/B]")
                li.setArt({'thumb': poster, 'poster': poster, 'fanart': backdrop, 'icon': poster})
                _set_info(li, {'title': title, 'plot': plot, 'mediatype': 'movie'})
                item_key = str(coll_id)
                if item_key in favs: li.addContextMenuItems([('Odebrat z Nexa Oblíbených', f'RunPlugin({_url(mode="remove_favorite", item_key=item_key, media_type="collection")})')])
                else: li.addContextMenuItems([('Přidat do Nexa Oblíbených', f'RunPlugin({_url(mode="add_favorite", tmdb_id=coll_id, title=title, media_type="collection", poster=poster, backdrop=backdrop, orig_title=title)})')])
                xbmcplugin.addDirectoryItem(addon_handle, _url(mode='show_collection', coll_id=coll_id), li, True)
            except: pass
    finally: prog.close()
    _end()

def show_collection(coll_id):
    xbmcplugin.setContent(addon_handle, 'movies')
    prog = xbmcgui.DialogProgress()
    prog.create(addon.getAddonInfo('name') or 'Addon', 'Načítám kolekci...')
    try:
        ctx = get_ssl_context()
        url = "https://api.themoviedb.org/3/collection/%s?api_key=%s&language=cs-CZ" % (coll_id, TMDB_KEY)
        with urllib.request.urlopen(url, context=ctx) as r:
            parts = json.loads(r.read().decode('utf-8')).get('parts', [])
            parts.sort(key=lambda x: x.get('release_date', '9999'))
            for part in parts:
                _add_tmdb_item({
                    'title': part.get('title', ''), 'orig_title': part.get('original_title', ''),
                    'year': part.get('release_date', '')[:4] if part.get('release_date') else '',
                    'plot': part.get('overview', ''), 'poster': 'https://image.tmdb.org/t/p/w500' + part['poster_path'] if part.get('poster_path') else '',
                    'backdrop': 'https://image.tmdb.org/t/p/w1280' + part['backdrop_path'] if part.get('backdrop_path') else '',
                    'tmdb_id': part.get('id', '')
                }, 'movie')
    except: pass
    finally: prog.close()
    _end()

def show_active_series(is_kids='false'):
    render_active_series(is_kids=is_kids)

def remove_series_from_watched(show_name, is_kids='false'):
    remove_series_and_refresh(show_name=show_name, is_kids=is_kids)

def show_kids_in_progress():
    render_in_progress_list(is_kids=True)

def kids_vecernicky(page=1):
    render_kids_vecernicky(page=page)

def kids_cz_movies(page=1):
    render_kids_cz_movies(page=page)

def kids_discover(m_type='movie', page=1):
    render_kids_discover(media_type=m_type, page=page)

def show_custom_folder(tmdb_ids_str, media_type='movie', page=1):
    render_custom_folder(raw_items=tmdb_ids_str, media_type=media_type, page=page)


