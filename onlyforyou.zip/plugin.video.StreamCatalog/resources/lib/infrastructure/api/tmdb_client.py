# -*- coding: utf-8 -*-
import tmdb_api
from resources.lib.config import TMDB_KEY


def get_person_combined_credits(person_id):
    return tmdb_api.get_person_combined_credits(TMDB_KEY, person_id)


def get_tv_season(tmdb_id, season_number):
    return tmdb_api.get_tv_season(TMDB_KEY, tmdb_id, season_number)
