# -*- coding: utf-8 -*-
import json
import urllib.request

from resources.lib.config import TMDB_KEY
from resources.lib.utils import get_ssl_context


TMDB_BASE_URL = "https://api.themoviedb.org/3"


def fetch_kids_vecernicky(page=1):
    url = (
        TMDB_BASE_URL
        + "/discover/tv?api_key=%s&language=cs-CZ&sort_by=vote_average.desc&vote_count.gte=0&with_genres=16,10762&with_origin_country=CZ|SK&page=%s"
        % (TMDB_KEY, int(page))
    )
    with urllib.request.urlopen(url, context=get_ssl_context()) as response:
        data = json.loads(response.read().decode("utf-8"))
    return data.get("results", []), data.get("total_pages", 1)


def fetch_kids_cz_movies(page=1):
    url = (
        TMDB_BASE_URL
        + "/discover/movie?api_key=%s&language=cs-CZ&sort_by=vote_average.desc&vote_count.gte=15&with_genres=10751&with_original_language=cs|sk&page=%s"
        % (TMDB_KEY, int(page))
    )
    with urllib.request.urlopen(url, context=get_ssl_context()) as response:
        data = json.loads(response.read().decode("utf-8"))
    return data.get("results", []), data.get("total_pages", 1)


def fetch_kids_discover(media_type="movie"):
    genres = "16,10751" if media_type == "movie" else "16,10762"
    base = (
        TMDB_BASE_URL
        + "/discover/%s?api_key=%s&language=cs-CZ&sort_by=popularity.desc&with_genres=%s&page=1"
        % (media_type, TMDB_KEY, genres)
    )
    local = base + "&with_origin_country=CZ|SK"
    aggregated = []
    for url in [local, base]:
        try:
            with urllib.request.urlopen(url, context=get_ssl_context()) as response:
                data = json.loads(response.read().decode("utf-8"))
                aggregated.extend(data.get("results", []))
        except Exception:
            continue
    return aggregated
