# -*- coding: utf-8 -*-
import os
import json
import time as _time_mod
import xbmc
import xbmcgui
from resources.lib.config import WATCHED_FILE, SEARCH_FILE, FAVORITES_FILE, addon
from resources.lib.utils import _notify

_watched_mem_cache = None
_favorites_mem_cache = None

def _load_watched():
    global _watched_mem_cache
    if _watched_mem_cache is not None:
        return _watched_mem_cache
    try:
        if os.path.exists(WATCHED_FILE):
            _watched_mem_cache = json.load(open(WATCHED_FILE, 'r'))
        else:
            _watched_mem_cache = {}
    except: pass
    if _watched_mem_cache is None:
        _watched_mem_cache = {}
    return _watched_mem_cache

def _save_watched(data):
    global _watched_mem_cache
    try:
        json.dump(data, open(WATCHED_FILE, 'w'), indent=2)
        _watched_mem_cache = data
    except: pass

def clear_watched_history():
    global _watched_mem_cache
    try:
        if os.path.exists(WATCHED_FILE):
            os.remove(WATCHED_FILE)
        _watched_mem_cache = {}
        _notify('Historie zhlédnutých byla vymazána')
        xbmc.executebuiltin('Container.Refresh')
    except: pass

def _trim_watched(watched):
    max_w = int(addon.getSetting('max_watched') or '100')
    if len(watched) > max_w:
        for k, _ in sorted(watched.items(), key=lambda i: i[1]['time'], reverse=True)[max_w:]:
            del watched[k]
    return watched

def watched_add(ident, title, size='', img='', media_type='movie', is_kids='false', tmdb_id=''):
    from resources.lib.player import _auto_watched
    _auto_watched(ident, title, size, img, media_type, playcount=1, is_kids=is_kids, tmdb_id=tmdb_id)
    _notify('Přidáno do zhlédnutých')
    xbmc.executebuiltin('Container.Refresh')

def watched_remove(ident):
    watched = _load_watched()
    if ident in watched:
        del watched[ident]
        _save_watched(watched)
    _notify('Odebráno z historie')
    xbmc.executebuiltin('Container.Refresh')

def _load_searches(search_id=''):
    try:
        if os.path.exists(SEARCH_FILE):
            data = json.load(open(SEARCH_FILE, 'r'))
            if isinstance(data, dict):
                return data.get(search_id or 'all', [])
            return data if not search_id or search_id == 'all' else []
    except: pass
    return []

def _save_search(query, search_id=''):
    try:
        data = {}
        if os.path.exists(SEARCH_FILE):
            try: data = json.load(open(SEARCH_FILE, 'r'))
            except: pass
            if not isinstance(data, dict): data = {'all': data}
        
        sid = search_id or 'all'
        searches = data.get(sid, [])
        if query in searches: searches.remove(query)
        searches.insert(0, query)
        data[sid] = searches[:20]
        
        json.dump(data, open(SEARCH_FILE, 'w'))
    except: pass

def clear_search_history(search_id=''):
    try:
        if os.path.exists(SEARCH_FILE):
            data = json.load(open(SEARCH_FILE, 'r'))
            if isinstance(data, dict):
                sid = search_id or 'all'
                if sid in data:
                    data[sid] = []
                    json.dump(data, open(SEARCH_FILE, 'w'))
            else:
                os.remove(SEARCH_FILE)
    except: pass
    _notify('Historie hledání byla vymazána')
    xbmc.executebuiltin('Container.Refresh')

def delete_search_item(query, search_id=''):
    try:
        if os.path.exists(SEARCH_FILE):
            data = json.load(open(SEARCH_FILE, 'r'))
            if isinstance(data, dict):
                sid = search_id or 'all'
                if sid in data and query in data[sid]:
                    data[sid].remove(query)
                    json.dump(data, open(SEARCH_FILE, 'w'))
                    _notify('Smazáno z historie')
                    xbmc.executebuiltin('Container.Refresh')
    except: pass

def _load_favorites():
    global _favorites_mem_cache
    if _favorites_mem_cache is not None:
        return _favorites_mem_cache
    try:
        if os.path.exists(FAVORITES_FILE):
            with open(FAVORITES_FILE, 'r', encoding='utf-8') as f:
                _favorites_mem_cache = json.load(f)
        else:
            _favorites_mem_cache = {'movie': {}, 'tvshow': {}, 'season': {}, 'episode': {}, 'collection': {}, 'kids_movie': {}, 'kids_tvshow': {}}
    except: pass
    if _favorites_mem_cache is None:
        _favorites_mem_cache = {'movie': {}, 'tvshow': {}, 'season': {}, 'episode': {}, 'collection': {}, 'kids_movie': {}, 'kids_tvshow': {}}
    return _favorites_mem_cache

def _save_favorites(data):
    global _favorites_mem_cache
    try:
        with open(FAVORITES_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        _favorites_mem_cache = data
    except Exception as e:
        xbmcgui.Dialog().notification('Chyba', str(e), xbmcgui.NOTIFICATION_ERROR)

def add_favorite(tmdb_id, title, media_type, poster='', backdrop='', year='', orig_title='', season='', episode=''):
    try:
        if not tmdb_id: return
        favs = _load_favorites()
        if media_type not in favs: favs[media_type] = {}
        
        item_key = str(tmdb_id)
        if media_type == 'episode': item_key = f"{tmdb_id}_S{season}E{episode}"
        elif media_type == 'season': item_key = f"{tmdb_id}_S{season}"
        
        favs[media_type][item_key] = {
            'tmdb_id': str(tmdb_id), 'title': title, 'poster': poster,
            'backdrop': backdrop, 'year': year, 'orig_title': orig_title,
            'season': season, 'episode': episode, 'time': int(_time_mod.time())
        }
        
        _save_favorites(favs)
        xbmcgui.Dialog().notification(addon.getAddonInfo('name') or 'Addon', f'Přidáno do oblíbených:\n{title}')
        xbmc.executebuiltin('Container.Refresh')
    except: pass

def remove_favorite(item_key, media_type):
    try:
        favs = _load_favorites()
        if media_type in favs and str(item_key) in favs[media_type]:
            del favs[media_type][str(item_key)]
            _save_favorites(favs)
            xbmcgui.Dialog().notification(addon.getAddonInfo('name') or 'Addon', 'Odebráno z oblíbených.')
            xbmc.executebuiltin('Container.Refresh')
    except: pass
