# -*- coding: utf-8 -*-
import json
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import tmdb_api
import webshare
import fastshare
from resources.lib.config import addon, addon_handle, TMDB_KEY
from resources.lib.auth import _get_token
from resources.lib.utils import (
    _set_info,
    _url,
    _end,
    _fail,
    _notify,
    clean_title,
    format_size,
    parse_size_str,
    parse_video_info,
    is_safe_match,
    format_stream_label,
    nexa_sidebar_attach,
    stream_passes_lang_filter,
    movie_file_sort_tuple,
    stream_list_sort_tuple,
)
from resources.lib.api_client import _get_csfd_rating, get_tmdb_cached
from resources.lib.local_db import _load_watched, _load_favorites

# Tenká in-memory vrstva nad diskovou TMDB cache (get_tmdb_cached).
# Šetří opakovaný lookup v jedné běhu procesu (1 otevření složky = 1 Python proces).
_TMDB_CACHE = {}

def _add_tmdb_item(item, media_type):
    tmdb_id = str(item.get('tmdb_id') or item.get('id', ''))

    if tmdb_id:
        cache_key = f"{tmdb_id}_{media_type}"
        cached = _TMDB_CACHE.get(cache_key)
        if not cached or (not cached.get('director') and not cached.get('cast')):
            xbmc.log(f"NEXASTREAM TMDB FETCH: ID={tmdb_id}, Type={media_type}", xbmc.LOGINFO)
            details = get_tmdb_cached(tmdb_id, media_type)
            if details:
                _TMDB_CACHE[cache_key] = details
                cached = details

        if cached:
            for key, value in cached.items():
                if not item.get(key): item[key] = value

    title = item.get('title') or item.get('name') or item.get('original_title') or item.get('original_name') or "Neznámý název"
    if any(ord(c) >= 0x0E00 for c in title): return

    orig = item.get('orig_title') or item.get('original_title') or item.get('original_name') or title
    year = item.get('year') or (item.get('release_date') or item.get('first_air_date') or '').split('-')[0]
    plot = item.get('plot') or item.get('overview') or ''
    
    poster = item.get('poster') or ('https://image.tmdb.org/t/p/w500' + item['poster_path'] if item.get('poster_path') else '')
    backdrop = item.get('backdrop') or ('https://image.tmdb.org/t/p/w1280' + item['backdrop_path'] if item.get('backdrop_path') else '')
    genres = item.get('genres', [])

    year_str = f" ({year})" if year else ""
    rating_str = ""
    show_csfd = addon.getSetting('show_csfd') != 'false'
    show_tmdb = addon.getSetting('show_tmdb') != 'false'

    csfd_rating = 0
    if show_csfd and media_type in ['movie', 'tvshow', 'tv']:
        csfd_rating = _get_csfd_rating(tmdb_id, title, year, orig_title=orig, media_type=media_type)

    csfd_str = ""
    if csfd_rating > 0:
        if csfd_rating >= 70: csfd_str = f" [COLOR red][{csfd_rating}%][/COLOR]"
        elif csfd_rating >= 30: csfd_str = f" [COLOR blue][{csfd_rating}%][/COLOR]"
        else: csfd_str = f" [COLOR gray][{csfd_rating}%][/COLOR]"
    
    has_csfd = False
    if show_csfd and csfd_str:
        rating_str += csfd_str
        has_csfd = True
        
    if show_tmdb and not has_csfd:
        try:
            vote = float(item.get('vote_average', 0))
            if vote > 0: rating_str += f" [COLOR yellow][★ {vote:.1f}][/COLOR]"
        except: pass

    label = f"{title}{year_str}{rating_str}"

    li = xbmcgui.ListItem(label)
    li.setArt({'thumb': poster, 'poster': poster, 'fanart': backdrop, 'icon': poster})
    info = {
        'title': title, 'plot': plot, 'year': int(year) if year and str(year).isdigit() else 0,
        'genre': ', '.join(genres) if genres else '', 'mediatype': 'movie' if media_type == 'movie' else 'tvshow',
        'originaltitle': orig, 'director': item.get('director', ''), 'cast': item.get('cast', [])
    }
    try:
        if item.get('vote_average'): info['rating'] = float(item.get('vote_average'))
    except: pass
    _set_info(li, info)

    import sys
    current_params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    is_kids_mode = item.get('is_kids') or current_params.get('is_kids') == 'true'
    is_kids_str = 'true' if is_kids_mode else 'false'
    fav_m_type = media_type
    if is_kids_mode: fav_m_type = 'kids_movie' if media_type == 'movie' else 'kids_tvshow'

    favs = _load_favorites().get(fav_m_type, {})
    if str(tmdb_id) in favs:
        li.addContextMenuItems([('Odebrat z oblíbených', f'RunPlugin({_url(mode="remove_favorite", item_key=tmdb_id, media_type=fav_m_type)})')])
    else:
        li.addContextMenuItems([('Přidat do oblíbených', f'RunPlugin({_url(mode="add_favorite", tmdb_id=tmdb_id, title=title, media_type=fav_m_type, poster=poster, backdrop=backdrop, year=year, orig_title=orig)})')])
        
    if media_type == 'movie': url = _url(mode='select_quality', title=title, year=year, orig_title=orig, tmdb_id=tmdb_id, is_kids=is_kids_str)
    else: url = _url(mode='series_list', serial_title=title, serial_year=year, serial_original_name=orig, tmdb_id=tmdb_id, is_kids=is_kids_str)
    xbmcplugin.addDirectoryItem(addon_handle, url, li, True)

def _add_video_item(f, media_type, show_quality=False, poster='', backdrop='', orig_title='', year='', tmdb_id='', is_kids='false', tmdb_title=''):
    name  = f.get('name', f.get('title', ''))
    ident = f.get('ident', '')
    size_bytes = f.get('size', 0)
    size_str = str(f.get('size_str', '')).strip()

    # Normalizace velikosti
    if (not size_str or size_str.isdigit()) and size_bytes:
        size_str = format_size(size_bytes)
    if not size_str or size_str == '0 MB': size_str = f.get('file_size', '')

    # Normalizace providera
    provider = f.get('provider', '')
    if not provider:
        provider = 'fastshare' if 'fastshare' in str(ident).lower() else 'webshare'
    elif provider == 'FS': provider = 'fastshare'
    elif provider == 'WS': provider = 'webshare'

    # Detekce typu streamu (EARLY BRANCHING)
    stream_type = 'STANDARD'
    if f.get('stream_type') == 'VIP' or "★" in name:
        stream_type = 'VIP'
    elif f.get('is_approved'):
        stream_type = 'APPROVED'
    elif f.get('stream_type') == 'AUTO_CACHED' or f.get('auto_meta'):
        stream_type = 'AUTO_CACHED'
    elif f.get('is_free_hs') or f.get('provider') == 'HELLSPY':
        stream_type = 'HELLSPY'
    
    # Příprava dat pro univerzální formátovač
    stream_data = {
        'stream_type': stream_type,
        'name': name,
        'provider': provider,
        'size_str': size_str,
        'quality_label': f.get('q_label', ''),
        'real_title': f.get('real_title', ''),
        'orig_title': orig_title,
        'year': year,
        'plus': f.get('positive', 0),
        'minus': f.get('negative', 0),
        # VIP streamy - samostatné sloupce z API
        'quality': f.get('quality', ''),
        'audio': f.get('audio', ''),
        'lang': f.get('lang', ''),
        'subs': f.get('subs', ''),
        # AUTO_CACHED meta z nexa_stream_meta (admin auto-sken)
        'auto_meta': f.get('auto_meta') or {},
        # TMDB CZ title — primární zdroj názvu pro AUTO_CACHED label
        # (raw filename často obsahuje herce/popis/genre, což je pro label šum).
        'tmdb_title': tmdb_title,
    }

    # Varování o překročení uživatelského stropu velikosti (NIKDY u VIP).
    if f.get('over_limit') and stream_type != 'VIP':
        stream_data['warning'] = '[COLOR red][!][/COLOR]'
    
    # POUŽITÍ UNIVERZÁLNÍHO FORMÁTOVAČE
    formatted = format_stream_label(stream_data, context='movie' if media_type == 'movie' else 'episode')
    
    label = formatted['label']
    rich_plot = formatted['plot']
    clean_title_str = formatted['clean_title']

    _side = nexa_sidebar_attach(stream_data, rich_plot)
    rich_plot = _side['plot']
    _nexa_tag = _side.get('tagline') or ''
    _nexa_props = _side.get('properties') or {}

    # Vytvoření ListItem
    li = xbmcgui.ListItem(label)
    li.setProperty('IsPlayable', 'true')
    if poster: li.setArt({'thumb': poster, 'poster': poster, 'fanart': backdrop or poster})

    info = {'title': label, 'originaltitle': orig_title if orig_title else clean_title_str, 'year': year, 'plot': rich_plot, 'mediatype': 'movie' if media_type == 'movie' else 'episode'}
    if _nexa_tag:
        info['tagline'] = _nexa_tag
    
    if tmdb_id:
        cache_key = f"{tmdb_id}_{'movie' if media_type == 'movie' else 'tvshow'}"
        if cache_key in _TMDB_CACHE:
            info['director'] = _TMDB_CACHE[cache_key].get('director', '')
            info['cast'] = _TMDB_CACHE[cache_key].get('cast', [])

    try:
        w_data = _load_watched().get(ident, {})
        if w_data:
            if w_data.get('playcount', 0) >= 1: info['playcount'] = 1
            elif w_data.get('resume_time', 0) > 0:
                li.setProperty('ResumeTime', str(w_data['resume_time']))
                if w_data.get('total_time'): li.setProperty('TotalTime', str(w_data['total_time']))
    except: pass
    _set_info(li, info)
    for _pk, _pv in _nexa_props.items():
        if _pv:
            li.setProperty(_pk, str(_pv))
    
    if f.get('is_approved'): li.setLabel(f.get('q_label', label))

    ctx_items = [
        ('Stáhnout na disk', 'RunPlugin(%s)' % _url(mode='download_file', ident=ident, title=clean_title_str)),
        ('Označit jako Zhlédnuté', 'RunPlugin(%s)' % _url(mode='add_watched', ident=ident, title=clean_title_str, size=size_str, media_type=media_type, tmdb_id=tmdb_id)),
        ('Přidat do knihovny Kodi (STRM)', 'RunPlugin(%s)' % _url(mode='export_strm', ident=ident, title=clean_title_str, media_type=media_type))
    ]
    # --- PŘIDANÁ NAVIGACE O SLOŽKU VÝŠE ---
    if media_type == 'movie':
        # Pro filmy: Přejde na klasické vyhledávání všech dostupných streamů
        nav_url = _url(mode='select_quality', title=orig_title or clean_title_str, tmdb_id=tmdb_id, year=year, is_kids=is_kids)
        ctx_items.insert(0, ('Zobrazit všechny streamy filmu', 'Container.Update(%s)' % nav_url))
        
    elif media_type == 'episode':
        # Vytáhneme číslo série z dat souboru
        season = f.get('season', 0)
        
        if season:
            # Skočí přesně tam, kam potřebuješ: TMDB složka všech dílů dané série
            nav_url = _url(mode='episodes', serial_title=orig_title or clean_title_str, tmdb_id=tmdb_id, season=season, is_kids=is_kids)
            ctx_items.insert(0, ('Přejít na všechny díly série', 'Container.Update(%s)' % nav_url))
        else:
            # Fallback (pokud by série chyběla): Skočí na seznam sérií
            nav_url = _url(mode='series_list', serial_title=orig_title or clean_title_str, tmdb_id=tmdb_id, is_kids=is_kids)
            ctx_items.insert(0, ('Zobrazit celý seriál', 'Container.Update(%s)' % nav_url))
    # --------------------------------------

    li.addContextMenuItems(ctx_items)
    
    import sys
    current_params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    f_season = f.get('season') or current_params.get('season', '')
    
    play_params = {
        'mode': 'play',
        'ident': ident,
        'title': clean_title_str,
        'media_type': media_type,
        'size': size_str,
        'provider': provider,
        'is_kids': is_kids,
        'season': f_season,
        'stream_type': stream_type,
    }
    if f.get('url'):
        play_params['url'] = f['url']
    if tmdb_id:
        play_params['tmdb_id'] = str(tmdb_id)
    if media_type == 'episode' and f.get('episode') not in (None, '', 0):
        play_params['episode'] = str(f.get('episode'))

    # VIP: skryt realny ident/URL pred kodi.log. Kodi loguje plugin URL, kterou prehrava,
    # a tam by jinak byl cely VIP odkaz. Misto toho do vaultu ulozime payload a v URL
    # posleme pouze opaque token 'vip:<hex>'. play_file() si ho vybali.
    if stream_type == 'VIP' and ident:
        try:
            from resources.lib.vip_vault import put as _vip_put
            token = _vip_put({
                'ident': ident,
                'provider': provider,
                'url': f.get('url', '') or '',
            })
            if token:
                play_params['ident'] = token
                play_params.pop('url', None)  # skutecna URL uz je ve vaultu
        except Exception as _e:
            xbmc.log('NEXASTREAM vip_vault: tokenize _add_video_item failed: %s' % _e, xbmc.LOGWARNING)

    xbmcplugin.addDirectoryItem(addon_handle, _url(**play_params), li, False)

def _is_vip_file(f):
    """
    VIP / Trezor detekce - musí být robustní, protože na výsledku závisí,
    jestli limit velikosti daný stream OBEJDE (VIP) nebo ne.
    """
    try:
        if f.get('stream_type') == 'VIP':
            return True
        name = str(f.get('name', '') or '')
        if '\u2605' in name:  # ★
            return True
        if f.get('is_vip') is True:
            return True
    except Exception:
        return False
    return False


def apply_size_limit(files):
    """
    Aplikuje uživatelský strop velikosti souboru na seznam streamů.

    KRITICKÉ PRAVIDLO: VIP streamy (Trezor ★) projdou VŽDY beze změny,
    bez ohledu na mód i velikost. Viz _is_vip_file.

    Módy:
      - 'M\u011bkk\u00fd' (size_limit_mode=='0'): nad-limitní ne-VIP streamy jen
        označí f['over_limit']=True a posune je na konec seznamu.
      - 'Tvrd\u00fd' (size_limit_mode=='1'): nad-limitní ne-VIP streamy odstraní.

    Při max_size_mb <= 0 se nic neděje.
    """
    if not files:
        return files
    try:
        max_mb = int(addon.getSetting('max_size_mb') or 0)
    except (TypeError, ValueError):
        max_mb = 0
    if max_mb <= 0:
        return files

    max_bytes = max_mb * 1024 * 1024
    hard = addon.getSetting('size_limit_mode') == '1'

    def _size_bytes(f):
        try:
            sb = int(f.get('size') or 0)
        except (TypeError, ValueError):
            sb = 0
        if sb > 0:
            return sb
        # Fallback na textovou velikost (VIP, APPROVED, případně importy)
        txt = f.get('size_str') or f.get('file_size') or ''
        return parse_size_str(txt)

    result = []
    for f in files:
        if _is_vip_file(f):
            # Dvojitá pojistka – VIP jdeme bez dotazu
            result.append(f)
            continue
        if _size_bytes(f) > max_bytes:
            if hard:
                continue
            try:
                f['over_limit'] = True
            except Exception:
                pass
        result.append(f)

    # Stabilní seřazení: VIP na svých pozicích (prioritizovat),
    # nad-limitní na konec.
    result.sort(key=lambda f: (
        0 if _is_vip_file(f) else (2 if f.get('over_limit') else 1)
    ))
    return result


def enrich_streams_with_cached_meta(files):
    """Vzdálená cache metadat byla odebrána – funkce zůstává jako no-op kvůli kompatibilitě volajících."""
    return


def _show_file_items(files, media_type='movie', poster='', backdrop='', orig_title='', year='', tmdb_id='', is_kids='false', tmdb_title=''):
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    files = [f for f in files if stream_passes_lang_filter(f)]
    files = apply_size_limit(files)
    grouped = {}
    for f in files:
        base = clean_title(f['name'], remove_quality=True)
        grouped.setdefault(base, []).append(f)

    def _group_sort_key(item):
        _base, var_list = item
        if not var_list:
            return (0, 0, 0)
        return max((movie_file_sort_tuple(f) for f in var_list), default=(0, 0, 0))

    sorted_groups = sorted(grouped.items(), key=_group_sort_key, reverse=True)

    for base_title, variants in sorted_groups:
        if len(variants) == 1: _add_video_item(variants[0], media_type, False, poster, backdrop, orig_title, year, tmdb_id=tmdb_id, is_kids=is_kids, tmdb_title=tmdb_title)
        else:
            biggest_file = max(variants, key=movie_file_sort_tuple)
            biggest_size_str = biggest_file.get('size_str', '').strip()
            if not biggest_size_str and biggest_file.get('size', 0):
                biggest_size_str = format_size(biggest_file.get('size', 0))
            provs = set(v.get('provider', 'fastshare') if 'fastshare' in str(v.get('ident','')).lower() else v.get('provider', 'webshare') for v in variants)
            p_tags = []
            if 'webshare' in provs: p_tags.append('[COLOR lime][WS][/COLOR]')
            if 'fastshare' in provs: p_tags.append('[COLOR deepskyblue][FS][/COLOR]')
            p_str = ' '.join(p_tags) + ' ' if p_tags else ''
            label = f"{p_str}[COLOR gold][{biggest_size_str}][/COLOR] [B]{base_title}[/B]  [I]({len(variants)} verzí)[/I]" if biggest_size_str else f"{p_str}[B]{base_title}[/B]  [I]({len(variants)} verzí)[/I]"
            li = xbmcgui.ListItem(label)
            variants_for_json = sorted(variants, key=stream_list_sort_tuple, reverse=True)
            v_data = json.dumps(
                [
                    {
                        'name': v['name'],
                        'ident': v['ident'],
                        'size': v.get('size', 0),
                        'size_str': v.get('size_str', ''),
                        'provider': v.get('provider', 'webshare'),
                        'stream_type': v.get('stream_type', ''),
                        'over_limit': bool(v.get('over_limit')),
                        'auto_meta': v.get('auto_meta') or {},
                    }
                    for v in variants_for_json
                ]
            )
            xbmcplugin.addDirectoryItem(addon_handle, _url(mode='quality_select', variants=v_data, media_type=media_type, poster=poster, backdrop=backdrop, orig_title=orig_title, year=year, tmdb_id=tmdb_id, is_kids=is_kids, tmdb_title=tmdb_title), li, True)

def show_quality_select(variants_json, media_type='movie', poster='', backdrop='', orig_title='', year='', tmdb_id='', is_kids='false', tmdb_title=''):
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    try: variants = json.loads(variants_json)
    except: variants = []
    variants = [v for v in variants if isinstance(v, dict) and stream_passes_lang_filter(v)]
    variants.sort(key=stream_list_sort_tuple, reverse=True)
    variants = apply_size_limit(variants)
    for v in variants:
        if isinstance(v, dict): _add_video_item(v, media_type, show_quality=True, poster=poster, backdrop=backdrop, orig_title=orig_title, year=year, tmdb_id=tmdb_id, is_kids=is_kids, tmdb_title=tmdb_title)
    _end()

def select_quality(title, year='', orig_title='', tmdb_id='', media_type='movie', is_kids='false'):
    from resources.lib.auth import _get_token
    token = _get_token()
    xbmcplugin.setContent(addon_handle, 'movies')
    poster, backdrop = '', ''

    if tmdb_id and TMDB_KEY:
        try:
            det = tmdb_api.get_movie_details(TMDB_KEY, tmdb_id)
            poster, backdrop = det.get('poster', ''), det.get('backdrop', '')
        except Exception:
            pass

    hellspy_enabled = addon.getSetting('enable_hellspy') != 'false'
    show_ws, show_fs = addon.getSetting('show_ws') != 'false', addon.getSetting('show_fs') != 'false'
    admin_data = []
    moderated_dict = {}
    approved_already_listed = set()

    addon_name = addon.getAddonInfo('name') or 'Addon'
    prog = xbmcgui.DialogProgress()
    prog.create(addon_name, f'Hledám na Webshare: {title}')
    try: 
        files = []
        if token:
            files = webshare.search_for_title(token, title, year=year, original_title=orig_title) or webshare.search_for_title(token, title, year=year, original_title=orig_title)
            for f in files: f['provider'] = 'webshare'
        prog.update(50, f'Hledám na FastShare: {title}')
        short_cz, short_en = re.split(r'[:\-]', title)[0].strip() if title else title, re.split(r'[:\-]', orig_title)[0].strip() if orig_title else orig_title
        import difflib
        def fs_match(t, fn):
            if not t: return False
            short_t = re.split(r'[:\-]', t)[0].strip()
            nt, fn_norm = webshare._norm(short_t), webshare._norm(fn)
            def is_surrounding_safe(match_idx, match_len):
                prefix, suffix = fn_norm[:match_idx].strip(), fn_norm[match_idx + match_len:].strip()
                ignore_words = {'cz', 'sk', 'en', 'dabing', 'titulky', '1080p', '720p', '4k', 'uhd', 'rip', 'web', 'dl', 'brrip', 'bdrip', 'avi', 'mkv', 'mp4', 'film', 'hq', 'fhd', 'hd', 'sd', 'tv', 'kino', 'cztit', 'h264', 'h265', 'hevc', 'part', 'cd'}
                if len([w for w in prefix.split() if w not in ignore_words and not w.isdigit()]) >= 2: return False
                if len(nt.split()) <= 2 and suffix:
                    first_suffix = suffix.split()[0]
                    if first_suffix not in ignore_words and not first_suffix.isdigit(): return False
                return True
            idx = fn_norm.find(nt)
            if idx != -1: return is_surrounding_safe(idx, len(nt))
            t_words = [w for w in nt.split() if len(w) > 2]
            if not t_words: return False
            fn_words, matched_indices, hits, first_match_idx = fn_norm.split(), set(), 0, -1
            for tw in t_words:
                for i, fw in enumerate(fn_words):
                    if i not in matched_indices and fw and fw[0] == tw[0] and abs(len(fw) - len(tw)) <= 2:
                        if difflib.SequenceMatcher(None, tw, fw).ratio() >= 0.80:
                            hits += 1; matched_indices.add(i)
                            if first_match_idx == -1: first_match_idx = fn_norm.find(fw)
                            break
            if hits >= (len(t_words) if len(t_words) <= 3 else int(len(t_words) * 0.8)):
                return is_surrounding_safe(first_match_idx, len(nt)) if first_match_idx != -1 else True
            return False

        for f in fastshare.smart_search(short_cz, short_en, year):
            if (fs_match(title, f['name']) or fs_match(orig_title, f['name'])) and (not (year and f.get('year') and str(f['year']) != str(year))) and f.get('season') is None and f.get('episode') is None:
                f['provider'] = 'fastshare'
                info = webshare.parse_filename(f['name'])
                f.update(info)
                files.append(f)

        # 3. Hellspy Search (Free)
        if hellspy_enabled:
            from resources.lib.utils import search_hellspy_kodi
            hs_results = search_hellspy_kodi(title)
            if not hs_results and orig_title: hs_results = search_hellspy_kodi(orig_title)
            for f in hs_results:
                if fs_match(title, f['name']) or fs_match(orig_title, f['name']):
                    files.append(f)

        moderated_dict = {s['ident']: s for s in admin_data if isinstance(s, dict) and s.get('ident')}
        filtered_files = []
        for f in files:
            provider = f.get('provider', '').upper()
            if (provider == 'WEBSHARE' and not show_ws) or (provider == 'FASTSHARE' and not show_fs):
                continue
            ident_f = f.get('ident')
            if ident_f in approved_already_listed:
                continue

            mod = moderated_dict.get(ident_f)
            if mod:
                if mod.get('status') == 'BANNED': continue
                if mod.get('status') == 'APPROVED':
                    f['is_approved'] = True
                    p_short = 'WS' if provider == 'WEBSHARE' else ('FS' if provider == 'FASTSHARE' else 'HL')
                    p_color = 'lime' if p_short == 'WS' else ('deepskyblue' if p_short == 'FS' else 'gray')
                    f['q_label'] = f"[COLOR fuchsia][Q][/COLOR] [COLOR {p_color}][{p_short}][/COLOR] {mod.get('quality_label', 'HD')}"
            
            if provider == 'HELLSPY' and not f.get('is_approved'):
                f['is_free_hs'] = True
                s_bytes = f.get('size', 0)
                f_size_str = format_size(s_bytes)
    
                # Složení řádku pro Hellspy: [HL] [Velikost] [Jazyk] Název | Meta (Free zdroj)
                v_info = parse_video_info(f['name'], f_size_str, return_dict=True)
                l_tag = v_info.get('lang_tag', '')
                meta = v_info.get('meta', '')
                
                # Bezpečné nahrazení názvu
                final_title = f['name']
                if orig_title and is_safe_match(f['name'], orig_title):
                    final_title = f"{orig_title} ({year})" if year else orig_title

                parts = ["[COLOR gray][HL][/COLOR]"]
                if f_size_str: parts.append(f"[COLOR gold][{f_size_str}][/COLOR]")
                if l_tag: parts.append(l_tag)
                parts.append(final_title)
                
                f['q_label'] = " ".join(parts)
                if meta: f['q_label'] += f" | {meta}"
                f['q_label'] += " (Free zdroj)"

            filtered_files.append(f)

        filtered_files = [f for f in filtered_files if stream_passes_lang_filter(f)]
        filtered_files.sort(key=movie_file_sort_tuple, reverse=True)
        files = filtered_files
    except Exception as e: xbmc.log(f"NEXASTREAM SEARCH ERROR: {str(e)}", xbmc.LOGERROR)
    finally: prog.close()

    if files:
        _show_file_items(files, media_type='movie', poster=poster, backdrop=backdrop, orig_title=orig_title, year=year, tmdb_id=tmdb_id, is_kids=is_kids, tmdb_title=title)
    else:
        xbmcplugin.addDirectoryItem(addon_handle, '', xbmcgui.ListItem(f'[COLOR red]Není k dispozici: {title}[/COLOR]'), False)
    _end()
