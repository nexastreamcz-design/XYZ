# -*- coding: utf-8 -*-
import re
import xbmc
import xbmcgui
import xbmcplugin
import time as _time_mod
import fastshare
import webshare
from resources.lib.config import addon, addon_handle, TMDB_KEY
from resources.lib.utils import _notify, _url, _norm, format_size, get_ssl_context, vip_safe, stream_language_rank_for_addon
from resources.lib.local_db import _load_watched, _save_watched, _trim_watched
from resources.lib.auth import _load_token, _get_token


def _addon_title():
    try:
        return addon.getAddonInfo('name') or 'StreamCatalog'
    except Exception:
        return 'StreamCatalog'


_nexa_locale_monitor = None


class _NexaLocalePlaybackMonitor(xbmc.Player):
    """Drží referenci pro Kodi callbacky – přednastavení zvuku/titulků u každého spuštěného videa (včetně autoplay fronty)."""

    def onAVStarted(self):
        try:
            from resources.lib.utils import apply_preferred_audio_stream, apply_preferred_subtitle_stream

            apply_preferred_audio_stream(self)
            apply_preferred_subtitle_stream(self)
        except Exception as e:
            xbmc.log('NEXASTREAM locale monitor onAVStarted: %s' % e, xbmc.LOGWARNING)


def _ensure_locale_monitor():
    global _nexa_locale_monitor
    if _nexa_locale_monitor is None:
        _nexa_locale_monitor = _NexaLocalePlaybackMonitor()
    return _nexa_locale_monitor


def _fs_preflight(url, fs_hash=None):
    """
    Ověří, že FastShare download URL skutečně vrací video obsah.
    FS při nedostupném souboru / špatném mirroru vrací 0 bajtů nebo HTML,
    což u FFmpeg vyvolá "error probing input format" a autoplay ztratí
    navazující díl. Preflight GET s Range bere jen pár bajtů.
    Návrat: True = OK, False = prázdná/HTML odpověď (URL je nepoužitelná).
    Při síťové chybě se vrací True, aby dočasné potíže nerozbíjely přehrávání.
    """
    try:
        import urllib.request
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Range': 'bytes=0-2047',
            'Accept': '*/*',
        }
        if fs_hash:
            headers['Cookie'] = f'FASTSHARE={fs_hash}'
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=6, context=get_ssl_context()) as r:
            ctype = (r.headers.get('Content-Type') or '').lower()
            clen_raw = r.headers.get('Content-Length') or r.headers.get('content-length')
            try:
                clen_i = int(clen_raw) if clen_raw else -1
            except (TypeError, ValueError):
                clen_i = -1
            if clen_i == 0:
                xbmc.log("NEXASTREAM FS PREFLIGHT: Content-Length=0 (prázdný obsah)", xbmc.LOGWARNING)
                return False
            if 'text/html' in ctype or 'text/plain' in ctype:
                xbmc.log("NEXASTREAM FS PREFLIGHT: Content-Type=%s (HTML místo videa)" % ctype, xbmc.LOGWARNING)
                return False
            data = r.read(512) or b''
            if not data:
                xbmc.log("NEXASTREAM FS PREFLIGHT: nulový body (EOF hned na začátku)", xbmc.LOGWARNING)
                return False
            head = data[:64].lstrip().lower()
            if head.startswith(b'<html') or head.startswith(b'<!doctype') or head.startswith(b'<?xml'):
                xbmc.log("NEXASTREAM FS PREFLIGHT: HTML body v odpovědi (ne video)", xbmc.LOGWARNING)
                return False
            return True
    except Exception as e:
        xbmc.log(f"NEXASTREAM FS PREFLIGHT: síťová chyba ({e}) – URL nebudu blokovat", xbmc.LOGWARNING)
        return True


class SCCPlayer(xbmc.Player):
    def __init__(self, ident, title, media_type='movie', size='', is_kids='false', provider='', season='', episode='', tmdb_id='', url='', stream_type=''):
        xbmc.Player.__init__(self)
        self.ident = ident
        self.title = title
        self.media_type = media_type
        self.size = size
        self.is_kids = is_kids
        self.provider = provider
        self.season = season
        self.episode = episode
        self.tmdb_id = tmdb_id
        self.url = url
        self.stream_type = stream_type
        self.last_time = 0
        self.last_total = 0
        self._done = False
        self.playing_file = ''

    def onPlayBackStopped(self):
        if self._done:
            return
        self._done = True
        try:
            time = self.last_time
            total = self.last_total

            wp_setting = addon.getSetting('watched_percent')
            if wp_setting == '1': threshold = 0.80
            elif wp_setting == '2': threshold = 0.70
            elif wp_setting == '3': threshold = 0.95
            else: threshold = 0.90
            
            if total > 0 and (time / total) > threshold:
                _auto_watched(self.ident, self.title, size=self.size, playcount=1, resume_time=0, total_time=total, media_type=self.media_type, is_kids=self.is_kids, provider=self.provider, season=self.season, episode=self.episode, tmdb_id=self.tmdb_id, url=self.url, stream_type=self.stream_type)
            elif time > 15:
                _auto_watched(self.ident, self.title, size=self.size, playcount=0, resume_time=time, total_time=total, media_type=self.media_type, is_kids=self.is_kids, provider=self.provider, season=self.season, episode=self.episode, tmdb_id=self.tmdb_id, url=self.url, stream_type=self.stream_type)
        except Exception as e:
            xbmc.log(f"NEXASTREAM watched save error (onPlayBackStopped): {e}", xbmc.LOGERROR)

    def onPlayBackEnded(self):
        if self._done:
            return
        self._done = True
        try:
            _auto_watched(self.ident, self.title, size=self.size, playcount=1, resume_time=0, media_type=self.media_type, is_kids=self.is_kids, provider=self.provider, season=self.season, episode=self.episode, tmdb_id=self.tmdb_id, url=self.url, stream_type=self.stream_type)
        except Exception as e:
            xbmc.log(f"NEXASTREAM watched save error (onPlayBackEnded): {e}", xbmc.LOGERROR)

def _auto_watched(ident, title, size='', img='', media_type='movie', playcount=0, resume_time=0, total_time=0, is_kids='false', tmdb_id='', provider='', season='', episode='', url='', stream_type=''):
    import re
    watched = _load_watched()
    ex = watched.get(ident, {})
    
    # Parsování season/episode z názvu pokud nejsou předány
    series_title = ''
    if media_type == 'episode':
        if not (season and episode):
            match = re.search(r'S(\d{1,2})E(\d{1,2})', title, re.IGNORECASE)
            if match:
                season = int(match.group(1))
                episode = int(match.group(2))
                # Extrahovat název seriálu (vše před S01E05)
                series_title = re.sub(r'\s*S\d{1,2}E\d{1,2}.*', '', title, flags=re.IGNORECASE).strip()
                # Odstranit kvalitativní značky
                series_title = re.sub(r'\[/?(?:COLOR|B|I)[^\]]*\]', '', series_title, flags=re.IGNORECASE)
                series_title = re.sub(r'\[.*?\]', '', series_title).strip()
            else:
                series_title = title
        else:
            # Pokud máme season/episode, extrahujeme název
            series_title = re.sub(r'\s*S\d{1,2}E\d{1,2}.*', '', title, flags=re.IGNORECASE).strip()
            series_title = re.sub(r'\[/?(?:COLOR|B|I)[^\]]*\]', '', series_title, flags=re.IGNORECASE)
            series_title = re.sub(r'\[.*?\]', '', series_title).strip()
        
        # Fallback na existující data
        if not series_title:
            series_title = ex.get('series_title', '')
    
    if playcount and playcount >= 1:
        final_playcount = playcount
        final_resume_time = 0
    elif resume_time and resume_time > 0:
        # Replay: reset playcount na 0, aby se díl znovu objevil v rozkoukaných
        final_playcount = 0
        final_resume_time = resume_time
    else:
        final_playcount = ex.get('playcount', 0)
        final_resume_time = resume_time

    watched[ident] = {
        'title': title,
        'size': size or ex.get('size', ''),
        'img': img or ex.get('img', ''),
        'time': int(_time_mod.time()),
        'media_type': media_type,
        'playcount': final_playcount,
        'resume_time': final_resume_time,
        'total_time': total_time or ex.get('total_time', 0),
        'is_kids': is_kids or ex.get('is_kids', 'false'),
        'tmdb_id': tmdb_id or ex.get('tmdb_id', ''),
        'provider': provider or ex.get('provider', ''),
        'season': season or ex.get('season', ''),
        'episode': episode or ex.get('episode', ''),
        'series_title': series_title if media_type == 'episode' else '',
        'url': url or ex.get('url', ''),  # Uložení URL pro HELLSPY streamy
        'stream_type': stream_type or ex.get('stream_type', ''),
    }
    _save_watched(_trim_watched(watched))
_COUNTDOWN_SEC_CHOICES = (3, 5, 8, 10, 15)
_COUNTDOWN_CANCEL_OPTIONS = [
    'Zastavit celou frontu',
    'Přehrát hned',
    'Vypnout odpočet (do restartu Kodi)',
]


def _next_countdown_seconds():
    try:
        idx = int(addon.getSetting('next_ep_countdown_sec') or '1')
    except (TypeError, ValueError):
        idx = 1
    idx = max(0, min(idx, len(_COUNTDOWN_SEC_CHOICES) - 1))
    return _COUNTDOWN_SEC_CHOICES[idx]


def _should_show_next_countdown(media_type, ns_chain):
    if addon.getSetting('next_ep_countdown_enabled') != 'true':
        return False
    if str(ns_chain or '').strip().lower() not in ('1', 'true', 'yes'):
        return False
    if addon.getSetting('next_ep_countdown_episodes_only') == 'true' and str(media_type or '').lower() != 'episode':
        return False
    try:
        if xbmcgui.Window(10000).getProperty('streamcatalog_countdown_session_off') == '1':
            return False
    except Exception:
        pass
    return True


def _next_episode_countdown_dialog(line1_title):
    """Odpočet před spuštěním dalšího dílu; návrat 'play' | 'stop_queue'."""
    seconds = _next_countdown_seconds()
    if seconds <= 0:
        return 'play'

    monitor = xbmc.Monitor()
    dp = xbmcgui.DialogProgress()
    heading = 'Další díl'
    dp.create(heading, '%s\nAutomatický start…' % line1_title)
    cancelled = False
    for remaining in range(seconds, 0, -1):
        if monitor.abortRequested():
            cancelled = True
            break
        pct = int((seconds - remaining) / float(seconds) * 100)
        dp.update(
            pct,
            '%s\nAutomatický start za %d s  (Zrušit = menu)' % (line1_title, remaining),
        )
        if dp.iscanceled():
            cancelled = True
            break
        if remaining > 1:
            if monitor.waitForAbort(1.0):
                cancelled = True
                break
    try:
        dp.close()
    except Exception:
        pass

    if not cancelled:
        return 'play'

    sel = xbmcgui.Dialog().select('Autoplay', _COUNTDOWN_CANCEL_OPTIONS)
    if sel == 0:
        return 'stop_queue'
    if sel == 1:
        return 'play'
    if sel == 2:
        try:
            xbmcgui.Window(10000).setProperty('streamcatalog_countdown_session_off', '1')
        except Exception:
            pass
        return 'play'
    # Zavření dialogu (Zpět) = zastavit frontu
    return 'stop_queue'


def _abort_play_and_clear_queue():
    try:
        xbmc.Player().stop()
    except Exception:
        pass
    try:
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except Exception as e:
        xbmc.log('NEXASTREAM countdown: clear playlist: %s' % e, xbmc.LOGWARNING)


def _playback_stream_type(stream_type='', status='', is_vip=False, provider=''):
    st = (stream_type or '').strip().upper()
    if st in ('VIP', 'APPROVED', 'HELLSPY', 'STANDARD'):
        return st
    if (status or '').strip().upper() == 'APPROVED':
        return 'APPROVED'
    if is_vip:
        return 'VIP'
    if (provider or '').strip().upper() in ('HELLSPY', 'HL'):
        return 'HELLSPY'
    return 'STANDARD'


def play_file(ident, title='', media_type='movie', size='', is_kids='false', provider='webshare', status='', season='', episode='', tmdb_id='', ns_chain='', stream_type=''):
    try:
        from urllib.parse import unquote_plus, quote
    except ImportError:
        from urllib import unquote_plus, quote
    
    try:
        ident = unquote_plus(str(ident))
        title = unquote_plus(str(title))
    except: pass
    
    # Parsovat season/episode z názvu pokud nejsou předány
    if media_type == 'episode' and not (season and episode):
        match = re.search(r'S(\d{1,2})E(\d{1,2})', title, re.IGNORECASE)
        if match:
            season = int(match.group(1))
            episode = int(match.group(2))

    # VIP unwrap: pokud nam prisel opaque token 'vip:<hex>', vytahneme realny ident
    # z in-memory vaultu a nastavime priznak is_vip, aby nasledny kod utlumil logy.
    # Tady take osetrujeme scenar, kdy vault zmizel (restart Kodi behem autoplay).
    is_vip = False
    vip_url_override = ''
    try:
        from resources.lib.vip_vault import is_token as _vip_is_token, pop as _vip_pop
    except Exception:
        _vip_is_token = lambda v: False
        _vip_pop = lambda t: None
    if _vip_is_token(ident):
        payload = _vip_pop(ident)
        if not payload:
            xbmc.log('NEXASTREAM VIP vault miss - token expirovan (Kodi restart?)', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(
                _addon_title(),
                'VIP relace vyprsela, zkuste znovu',
                xbmcgui.NOTIFICATION_WARNING,
                5000,
            )
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return
        is_vip = True
        ident = str(payload.get('ident') or '')
        _prov = str(payload.get('provider') or '') or provider
        if _prov:
            provider = _prov
        vip_url_override = str(payload.get('url') or '')

    playback_stream_type = _playback_stream_type(stream_type, status, is_vip, provider)

    if _should_show_next_countdown(media_type, ns_chain):
        act = _next_episode_countdown_dialog(title or 'Další díl')
        if act == 'stop_queue':
            _abort_play_and_clear_queue()
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

    link = None
    
    if provider == 'HELLSPY' or provider == 'HL':
        from resources.lib.utils import resolve_hellspy
        import urllib.parse
    
        # Při fúzi dat jsme předali 'url' parametr, nebo si jej sestavíme z identu
        hs_url = ""
        if is_vip and vip_url_override:
            # VIP: URL prisla pres in-memory vault, ne pres sys.argv
            hs_url = vip_url_override
        else:
            import sys
            current_params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
            if current_params.get('url'):
                hs_url = urllib.parse.unquote_plus(current_params['url'])
            else:
                # Fallback pokud nemáme kompletní URL z API (ve starých DB záznamech)
                # Upozornění: toto je nyní deprecované, nebot stream z Hellspy.to vyžaduje fileHash
                hs_url = f"hellspy_stream:{ident}:UNKNOWN"

        xbmc.log("HELLSPY RESOLVE: %r" % (vip_safe(hs_url, is_vip),), xbmc.LOGDEBUG)
        link = resolve_hellspy(hs_url, is_vip=is_vip)
    
        if not link:
            xbmc.log("HELLSPY stream failed for %s, trying next in playlist" % (vip_safe(ident, is_vip),), xbmc.LOGWARNING)
            # Kodi automaticky zkusí další stream v playlistu, takže nezobraujeme chybovou notifikaci
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return
        
    elif provider in ['fastshare', 'FS'] or 'fastshare' in str(ident).lower():
        fs_hash = fastshare.get_hash()
        fs_user = addon.getSetting('fs_username')
        fs_pass = addon.getSetting('fs_password')
        safe_ua = quote("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36")
    
        xbmc.log(
            "NEXASTREAM FASTSHARE play_file: provider=%r" % (provider,),
            xbmc.LOGDEBUG,
        )

        # ============================================================
        # NORMALIZACE IDENTU: doplnit https:// pokud chybí protokol
        # ============================================================
        ident_norm = str(ident).strip()
        if ident_norm and not ident_norm.startswith('http') and ('fastshare' in ident_norm.lower()):
            ident_norm = 'https://' + ident_norm
            xbmc.log("NEXASTREAM FASTSHARE: doplněn protokol k URL", xbmc.LOGDEBUG)

        # Detekce: ident je jen filename (např. data-backup-n2-74401-part0308.mp4)
        # To nastane když DB obsahuje špatně uložený záznam (bez URL/ID)
        is_filename_only = (
            bool(re.match(r'^[\w\-\.]+\.(mp4|mkv|avi|ts|mov)$', ident_norm, re.I))
            and not ident_norm.startswith('http')
            and not re.match(r'^\d{5,12}$', ident_norm)
        )
    
        # Zachovat původní page URL (s filename) pro resolver - KLÍČOVÉ!
        # Pokud ident je https://fastshare.cloud/33978201/soubor.mkv, chceme tuto URL použít přímo
        fs_page_url = None  # Celá page URL pro resolver (s filename)
    
        clean_id = ident_norm
        if 'id=' in ident_norm:
            # Případ: download.php?id=33978149 nebo URL s parametrem id=
            m = re.search(r'id=([0-9]+)', ident_norm)
            if m: clean_id = m.group(1)
        elif '/' in ident_norm and 'fastshare' in ident_norm.lower():
            # Detekce přímé download URL (dataX.fastshare.cloud/download.php)
            is_dl = 'download.php' in ident_norm or bool(re.search(r'data\d+\.fastshare', ident_norm))
            if not is_dl:
                # Page URL: https://fastshare.cloud/33978149/soubor.mp4
                raw_page = ident_norm.split('|')[0]
                if re.search(r'fastshare\.[a-z]+/\d{5,12}/', raw_page):
                    fs_page_url = raw_page  # Celá page URL s filename
            # Hledáme číselný segment v URL (ID je vždy číslo)
            m = re.search(r'/(\d{5,12})(?:/|$|\?|\|)', ident_norm)
            if m:
                clean_id = m.group(1)
            else:
                seg = ident_norm.split('/')[-1].split('|')[0].split('?')[0]
                clean_id = seg.split('.')[0] if '.' in seg else seg
        elif is_filename_only:
            clean_id = ''
        elif re.match(r'^\d{5,12}$', ident_norm):
            clean_id = ident_norm  # Čisté numerické ID
        else:
            clean_id = ident_norm.split('|')[0]

        xbmc.log(
            "NEXASTREAM FASTSHARE: clean_id=%r, is_filename_only=%s"
            % (clean_id, is_filename_only),
            xbmc.LOGDEBUG,
        )

        # ============================================================
        # BEZPEČNOSTNÍ BLOKACE: filename-only ident NIKDY nepřehrávat!
        # VIP linky musí mít vždy URL nebo numerické ID - žádný smart_search!
        # ============================================================
        if is_filename_only:
            xbmc.log("NEXASTREAM FS SAFETY BLOCK: filename-only ident '%s' blocked - DB záznam neobsahuje platnou URL/ID!" % (vip_safe(ident_norm, is_vip),), xbmc.LOGERROR)
            xbmcgui.Dialog().notification(_addon_title(), 'Neplatný FS odkaz (chybí ID/URL). Kontaktujte správce.', xbmcgui.NOTIFICATION_ERROR, 6000)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        final_url = None
        t0 = _time_mod.time()
    
        # Detekce přímé download URL: musí obsahovat dataX.fastshare (node) nebo download.php
        # POZOR: page URL https://fastshare.cloud/ID/data-backup-...mp4 také obsahuje 'data'!
        # Proto kontrolujeme přítomnost 'download.php' nebo 'data\d.fastshare' (node s číslem)
        is_direct_download_url = (
            ident_norm.startswith('http') and (
                'download.php' in ident_norm or
                bool(re.search(r'data\d+\.fastshare', ident_norm))
            )
        )
    
        if is_direct_download_url:
            # Přímá download URL – bez platného FASTSHARE často vrátí HTML (FFmpeg: error probing input format).
            # Nemá‑li uživatel hash, nejdřív zkusíme resolver / get_link s file_id.
            final_url = ident_norm.split('|')[0]
            if fs_hash:
                xbmc.log("NEXASTREAM FASTSHARE: přímá download URL (s FASTSHARE)", xbmc.LOGDEBUG)
            else:
                xbmc.log(
                    "NEXASTREAM FASTSHARE: přímá download URL bez FASTSHARE – zkusím resolver/get_link",
                    xbmc.LOGINFO,
                )
                final_url = None
        if not final_url:
            # Potřebujeme resolver - zobrazíme loading notifikaci pro delší odezvu
            xbmcgui.Dialog().notification(_addon_title(), '» Načítám FastShare stream...', xbmcgui.NOTIFICATION_INFO, 4000)
        
            if re.match(r'^\d{5,12}$', str(clean_id)):
                # Resolver: otevřeme FS page a z HTML dostaneme správný dataX node
                # Pokud máme celou page URL (s filename), použijeme ji - JINAK jen ID (méně spolehlivé)
                t_resolve = _time_mod.time()
                page_url = fs_page_url if fs_page_url else f'https://fastshare.cloud/{clean_id}/'
                resolved = fastshare.resolve_download_url(clean_id, page_url, is_vip=is_vip)
                if resolved:
                    final_url = resolved
                    xbmc.log(
                        "NEXASTREAM FASTSHARE: resolver OK [%.3fs]" % (_time_mod.time() - t_resolve,),
                        xbmc.LOGDEBUG,
                    )
                else:
                    xbmc.log(
                        "NEXASTREAM FASTSHARE: resolver selhal [%.3fs]" % (_time_mod.time() - t_resolve,),
                        xbmc.LOGWARNING,
                    )
                    # Fallback: zkusit bez filename (jen ID)
                    if fs_page_url and fs_page_url != f'https://fastshare.cloud/{clean_id}/':
                        xbmc.log("NEXASTREAM FASTSHARE: zkouším fallback s ID-only URL", xbmc.LOGDEBUG)
                        resolved2 = fastshare.resolve_download_url(clean_id, f'https://fastshare.cloud/{clean_id}/', is_vip=is_vip)
                        if resolved2:
                            final_url = resolved2
                            xbmc.log("NEXASTREAM FASTSHARE: fallback resolver OK", xbmc.LOGDEBUG)

            # Pre-flight: ověří, že resolver URL skutečně nabízí video (ne 0 bajtů / HTML).
            # Když preflight selže, zrušíme final_url a pustíme se na get_link API níže.
            if final_url and not _fs_preflight(final_url, fs_hash):
                xbmc.log(
                    "NEXASTREAM FASTSHARE: resolver URL neprošla preflightem – zkusím get_link API",
                    xbmc.LOGINFO,
                )
                final_url = None

            # get_link API: záloha když HTML stránka neobsahuje download.php (SPA), nebo u ne-číselného identu,
            # nebo když resolver sice URL vrátil, ale server na ní servíruje prázdno (preflight selhal).
            if not final_url and fs_user and fs_pass:
                try:
                    import urllib.request, json
                    t_api = _time_mod.time()
                    fs_api = f"https://fastshare.cz/api/api_kodi.php?process=get_link&login={quote(fs_user)}&password={quote(fs_pass)}&file_id={clean_id}"
                    with urllib.request.urlopen(fs_api, timeout=5, context=get_ssl_context()) as r:
                        raw = r.read().decode('utf-8', errors='replace').strip()
                        data = None
                        if raw:
                            try:
                                data = json.loads(raw)
                            except json.JSONDecodeError:
                                data = None

                        if data and data.get('link'):
                            final_url = data['link']
                            xbmc.log(
                                "NEXASTREAM FASTSHARE: get_link API OK [%.3fs]"
                                % (_time_mod.time() - t_api,),
                                xbmc.LOGDEBUG,
                            )
                        elif raw and not final_url:
                            recovered = fastshare.extract_download_url_from_html(raw)
                            if recovered:
                                final_url = recovered
                                xbmc.log(
                                    "NEXASTREAM FASTSHARE: get_link záloha z těla (HTML/SPA) [%.3fs]"
                                    % (_time_mod.time() - t_api,),
                                    xbmc.LOGINFO,
                                )
                            elif data is not None:
                                xbmc.log(
                                    f"NEXASTREAM FASTSHARE: get_link JSON bez platného linku "
                                    f"[{_time_mod.time()-t_api:.3f}s]",
                                    xbmc.LOGWARNING,
                                )
                            else:
                                xbmc.log(
                                    "NEXASTREAM FASTSHARE: get_link není JSON a v těle není odkaz "
                                    f"(prvních 120 znaků: {raw[:120]!r})",
                                    xbmc.LOGWARNING,
                                )
                        elif not raw:
                            xbmc.log(
                                f"NEXASTREAM FASTSHARE: get_link prázdné tělo odpovědi "
                                f"[{_time_mod.time()-t_api:.3f}s]",
                                xbmc.LOGWARNING,
                            )
                except Exception as e:
                    xbmc.log(f"NEXASTREAM FASTSHARE: get_link API chyba: {e}", xbmc.LOGWARNING)

        # Pro VIP linky NEPOUŽÍVÁME smart_search - buď máme URL/ID nebo fail
        # smart_search je pouze pro live search (play_from_here), ne pro DB záznamy

        # Poslední safety-net: jestli jsme nějakou URL získali (z resolveru i get_link),
        # ale obsah je pořád 0 bajtů nebo HTML, ušetříme FFmpegu "error probing input format".
        if final_url and str(final_url).startswith('http') and not _fs_preflight(final_url, fs_hash):
            xbmc.log(
                "NEXASTREAM FASTSHARE: finální URL neprošla preflightem – soubor na FS nedostupný",
                xbmc.LOGERROR,
            )
            final_url = None

        xbmc.log(
            "NEXASTREAM FASTSHARE: stream připraven [celkem %.3fs]" % (_time_mod.time() - t0,),
            xbmc.LOGDEBUG,
        )

        if final_url and str(final_url).startswith('http'):
            if fs_hash:
                link = final_url + f"|Cookie=FASTSHARE={fs_hash}&User-Agent={safe_ua}"
            else:
                link = final_url + f"|User-Agent={safe_ua}"
        else:
            xbmc.log("NEXASTREAM FASTSHARE: Nepodařilo se získat stream URL pro ident=%r" % (vip_safe(ident_norm, is_vip),), xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                _addon_title(),
                'FastShare: soubor není dostupný. Zkuste WebShare variantu nebo kontaktujte správce.',
                xbmcgui.NOTIFICATION_ERROR,
                6000,
            )
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return
        
    else:
        if str(ident).startswith('http'):
            link = ident 
        else:
            token = _load_token()
            if not token: token = addon.getSetting('token') 
            if not token: return
        
            ws_id = ident.split('|')[0]
            link = webshare.get_file_link(token, ws_id, is_vip=is_vip)
        
    if not link:
        xbmcgui.Dialog().notification(_addon_title(), 'Nelze získat odkaz na stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return

    _ensure_locale_monitor()

    # Předat URL do playeru pro uložení do historie
    current_url = ""
    if provider in ['HELLSPY', 'HL']:
        if is_vip and vip_url_override:
            current_url = vip_url_override
        else:
            import sys
            import urllib.parse
            current_params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
            current_url = current_params.get('url', '')

    player = SCCPlayer(
        ident,
        title,
        media_type=media_type,
        size=size,
        is_kids=is_kids,
        provider=provider,
        season=season,
        episode=episode,
        tmdb_id=tmdb_id,
        url=current_url,
        stream_type=playback_stream_type,
    )

    li = xbmcgui.ListItem(title, path=link)
    li.setInfo('video', {'title': title})
    li.setProperty('IsPlayable', 'true')
    li.setMimeType('video/mp4')
    if hasattr(li, 'setContentLookup'):
        li.setContentLookup(False)

    xbmcplugin.setResolvedUrl(addon_handle, True, li)
    monitor = xbmc.Monitor()
    
    timeout = 60
    while timeout > 0 and not player.isPlaying() and not monitor.abortRequested():
        xbmc.sleep(500)
        timeout -= 1
    
    if player.isPlaying():
        try:
            player.last_time = player.getTime()
            player.last_total = player.getTotalTime()
            player.playing_file = xbmc.Player().getPlayingFile() or ''
        except Exception as e:
            xbmc.log(f"NEXASTREAM player initial tick error: {e}", xbmc.LOGWARNING)
        while not monitor.abortRequested() and player.isPlaying() and not player._done:
            try:
                player.last_time = player.getTime()
                player.last_total = player.getTotalTime()
                current_file = xbmc.Player().getPlayingFile() or ''
                if player.playing_file and current_file and current_file != player.playing_file:
                    _prev = vip_safe(player.playing_file, is_vip, placeholder='[VIP_STREAM]')
                    _curr = vip_safe(current_file, is_vip, placeholder='[VIP_STREAM]')
                    xbmc.log("NEXASTREAM player: soubor se změnil (%r -> %r), ukončuji monitoring" % (_prev, _curr), xbmc.LOGINFO)
                    player._done = True
                    break
            except Exception as e:
                xbmc.log(f"NEXASTREAM player tick error: {e}", xbmc.LOGWARNING)
            xbmc.sleep(1000)

def play_from_here(serial_title, season, start_ep, serial_year='', serial_original_name='', tmdb_id='', is_kids='false', resume_ident='', resume_time='', resume_total=''):
    from resources.lib.tvshows import (
        _filter_season,
        _group_by_episode,
        _extract_keyword,
        _effective_series_match_titles,
        _remap_orphans_by_tmdb_episode_titles,
    )
    season, start_ep = int(season), int(start_ep)
    token = _get_token()

    try:
        resume_time_val = int(resume_time) if resume_time not in (None, '', 0) else 0
    except (TypeError, ValueError):
        resume_time_val = 0
    try:
        resume_total_val = int(resume_total) if resume_total not in (None, '', 0) else 0
    except (TypeError, ValueError):
        resume_total_val = 0
    resume_ident_norm = str(resume_ident).split('|')[0].strip() if resume_ident else ''

    # --- 1. OKAMŽITÉ UVOLNĚNÍ KODI ---
    # Přesunuto úplně nahoru! Televize (Android) nesmí čekat, jinak zkolabuje grafika.
    if addon_handle >= 0:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        xbmc.sleep(200) # Výdech pro procesor

    fs_ok = bool(addon.getSetting('fs_username') and addon.getSetting('fs_password'))
    if not token and not fs_ok:
        from resources.lib.utils import _fail
        return _fail('Pro autoplay zadejte WebShare nebo FastShare v nastavení.')

    orig_name, cz_name = serial_original_name or serial_title, serial_title
    items, existing = [], set()

    vip_episodes = {}

    def _merge(new_items):
        for ni in new_items:
            if ni['ident'] not in existing: items.append(ni); existing.add(ni['ident'])

    def _merge_ws(ws_list):
        for _f in ws_list or []:
            _f['provider'] = 'webshare'
            _f.update(webshare.parse_filename(_f['name']))
        _merge(ws_list)

    # --- 2. BEZPEČNĚJŠÍ NAČÍTÁNÍ PRO TELEVIZE ---
    # Nahradili jsme DialogProgress za nativní systémové kolečko Kodi
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        if token:
            _merge_ws(webshare._raw_search(token, '%s S%02d' % (orig_name, season), limit=50))
            xbmc.sleep(50) # Mikro pauza - dáme TV čas zpracovat procesy
            
            if cz_name and _norm(cz_name) != _norm(orig_name): 
                _merge_ws(webshare._raw_search(token, '%s S%02d' % (cz_name, season), limit=50))
                xbmc.sleep(50)
                
            kw_en = _extract_keyword(orig_name)
            if kw_en and len(kw_en) > 4: 
                _merge_ws(webshare._raw_search(token, '%s S%02d' % (kw_en, season), limit=30))
                xbmc.sleep(50)
                
            kw_cz = _extract_keyword(cz_name) if cz_name else ''
            if kw_cz and len(kw_cz) > 4 and _norm(kw_cz) != _norm(kw_en): 
                _merge_ws(webshare._raw_search(token, '%s S%02d' % (kw_cz, season), limit=30))
                xbmc.sleep(50)
        
        # Načtení FastShare streamů (pokud je povoleno a má účet)
        if addon.getSetting('show_fs') != 'false':
            fs_user = addon.getSetting('fs_username')
            fs_pass = addon.getSetting('fs_password')
            if fs_user and fs_pass:  # Pouze pokud má aktivní FS účet
                fs_results = fastshare.smart_search(f"{cz_name} S{season:02d}", f"{orig_name} S{season:02d}" if orig_name else None)
                for f in fs_results:
                    f.update(webshare.parse_filename(f['name']))
                    f['size_str'] = format_size(f.get('size', 0))
                    f['provider'] = 'fastshare'
                _merge(fs_results)
                xbmc.sleep(50)
        
        # Načtení Hellspy streamů (vždy dostupné - free zdroj)
        try:
            from resources.lib.utils import search_hellspy_kodi
            hs_results = search_hellspy_kodi('%s S%02d' % (orig_name, season))
            if cz_name and _norm(cz_name) != _norm(orig_name):
                hs_results.extend(search_hellspy_kodi('%s S%02d' % (cz_name, season)))
            for _h in hs_results:
                _h.update(webshare.parse_filename(_h.get('name', '')))
            _merge(hs_results)
        except: pass
    except: pass
    finally: 
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    title_candidates = [x for x in (cz_name, orig_name) if x and str(x).strip()]
    if tmdb_id and TMDB_KEY:
        try:
            import tmdb_api as _tmdb_api
            det = _tmdb_api.get_tvshow_details(TMDB_KEY, str(tmdb_id))
            if det:
                for key in ('title', 'orig_title'):
                    v = det.get(key)
                    if v and str(v).strip():
                        title_candidates.append(str(v).strip())
                for at in det.get('alt_titles') or []:
                    s = str(at).strip()
                    if s:
                        title_candidates.append(s)
        except Exception:
            pass
    match_titles = _effective_series_match_titles(*title_candidates)
    if not match_titles:
        match_titles = [cz_name or orig_name or '']
    ep_names_remap = {}
    season_ep_nums_pb = frozenset()
    if tmdb_id and TMDB_KEY:
        try:
            import tmdb_api as _tmdb_api
            _sd = _tmdb_api.get_tv_season(TMDB_KEY, str(tmdb_id), season)
            if _sd:
                for _ep in _sd.get('episodes') or []:
                    _n = _ep.get('episode_number')
                    if _n is not None:
                        ep_names_remap[_n] = _ep.get('name', '') or ''
                season_ep_nums_pb = frozenset(ep_names_remap.keys())
        except Exception:
            pass
    filtered = _filter_season(items, season, match_titles, season_ep_nums_pb, ep_names_remap)
    groups = _group_by_episode(filtered)
    groups = _remap_orphans_by_tmdb_episode_titles(groups, ep_names_remap)

    for vip_ep_num in vip_episodes.keys():
        if vip_ep_num not in groups: groups[vip_ep_num] = []

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    added = 0
    first_playlist_entry = True
    queued_stream_keys = set()
    all_ep_keys = sorted(groups.keys())
    if resume_ident_norm and start_ep not in groups:
        # Pokud máme resume_ident, chceme zajistit, že první díl bude zařazen i když groups nic nenašlo
        groups[start_ep] = []
        all_ep_keys = sorted(groups.keys())

    for ep_num in all_ep_keys:
        if ep_num < start_ep: continue

        ident, size_str, provider, best_v = None, '', 'webshare', None
        history_stream_type = ''
        title_label = f"{cz_name or orig_name} S{season:02d}E{ep_num:02d}"

        # --- RESUME PRO PRVNÍ DÍL: pokus o původní stream z watched.json ---
        resume_hit = False
        if ep_num == start_ep and resume_ident_norm:
            for v in groups.get(ep_num, []):
                v_ident_norm = str(v.get('ident', '')).split('|')[0].strip()
                if v_ident_norm and v_ident_norm == resume_ident_norm:
                    best_v = v
                    ident = v.get('ident', '')
                    provider = v.get('provider', 'webshare')
                    size_str = format_size(v.get('size', 0)) or v.get('size_str', '')
                    resume_hit = True
                    # Pri resume nevime, zda puvodni stream byl VIP. Pro jistotu maskujeme
                    # ident, aby se VIP link nahodou nelogoval pri obnove prehravani.
                    _ri_mask = '★' in str(v.get('name', '')) or v.get('stream_type') == 'VIP'
                    xbmc.log("NEXASTREAM autoplay resume: S%02dE%02d using original ident %r" % (season, ep_num, vip_safe(resume_ident_norm, _ri_mask)), xbmc.LOGINFO)
                    break
            if not resume_hit:
                # Fallback - pokud jsme vyhledali, ale stream už neexistuje, pokračujeme scoring výběrem níže.
                # Pokud není žádná varianta, níže použijeme resume_ident přímo (ať to zkusí resolver v play_file).
                xbmc.log("NEXASTREAM autoplay resume: ident %r nenalezen ve skupině %s, použijeme fallback" % (vip_safe(resume_ident_norm, True), ep_num), xbmc.LOGINFO)

        # Příznak: použít VIP nebo fallback na search výsledky
        use_vip = False
        if not resume_hit and ep_num in vip_episodes:
            vip_item = vip_episodes[ep_num]
            vip_prov_raw = str(vip_item.get('provider', 'WS')).upper()
            if vip_prov_raw in ('WEBSHARE', 'WS'):
                vip_prov = 'WS'
            elif vip_prov_raw in ('FASTSHARE', 'FS'):
                vip_prov = 'FS'
            else:
                vip_prov = vip_prov_raw if vip_prov_raw in ('FS', 'WS') else 'WS'

            fs_user_ep = addon.getSetting('fs_username') or ''
            fs_pass_ep = addon.getSetting('fs_password') or ''
            skip_trezor_wrong_host = False
            if vip_prov == 'FS' and (
                addon.getSetting('show_fs') == 'false' or not fs_user_ep or not fs_pass_ep
            ):
                skip_trezor_wrong_host = True
                xbmc.log(
                    "NEXASTREAM autoplay: Trezor FS přeskakuji (FS vypnuto nebo chybí účet) S%02dE%02d"
                    % (season, ep_num),
                    xbmc.LOGINFO,
                )
            elif vip_prov == 'WS' and (addon.getSetting('show_ws') == 'false' or not token):
                skip_trezor_wrong_host = True
                xbmc.log(
                    "NEXASTREAM autoplay: Trezor WS přeskakuji (WebShare vypnuto nebo bez tokenu) S%02dE%02d"
                    % (season, ep_num),
                    xbmc.LOGINFO,
                )

            if skip_trezor_wrong_host:
                use_vip = False
            elif vip_prov == 'FS':
                raw_vip_ident = vip_item.get('ident', '')
                _is_fn_only = bool(re.match(r'^[\w\-\.]+\.(mp4|mkv|avi|ts|mov)$', str(raw_vip_ident), re.I)) and not str(raw_vip_ident).startswith('http')
                _is_numeric_only = bool(re.match(r'^\d{5,12}$', str(raw_vip_ident).strip()))
                if _is_fn_only:
                    # VIP polozka - nelogujeme skutecny ident
                    xbmc.log("NEXASTREAM VIP FS: filename-only ident %r pro S%02dE%02d - fallback na search" % (vip_safe(raw_vip_ident, True), season, ep_num), xbmc.LOGWARNING)
                    use_vip = False  # Přejdeme na search výsledky níže
                elif _is_numeric_only and groups.get(ep_num):
                    # Holé FS ID z Trezoru + HTML bez download.php → Kodi přeskakuje položky ve frontě; raději WebShare z vyhledávání
                    xbmc.log(
                        "NEXASTREAM VIP FS: numerické ID bez page URL pro S%02dE%02d - použiji výsledky vyhledávání (méně přeskakování ve frontě)" % (season, ep_num),
                        xbmc.LOGINFO,
                    )
                    use_vip = False
                else:
                    ident = raw_vip_ident
                    provider = 'FS'
                    size_str = str(vip_item.get('size', ''))
                    use_vip = True
            else:
                raw_link = vip_item.get('link', '')
                raw_ident = vip_item.get('ident', '')
                if raw_ident and not raw_ident.startswith('http'):
                    ident = raw_ident
                else:
                    parts = raw_link.strip('/').split('/')
                    ident = parts[-1] if parts[-1] else (parts[-2] if len(parts) >= 2 else raw_link)
                provider = 'webshare'
                size_str = str(vip_item.get('size', ''))
                use_vip = True

        if not resume_hit and not use_vip and groups.get(ep_num):
            def get_selection_score(v):
                score = 0
                name = v.get('name', '')
                name_upper = name.upper()
                provider = v.get('provider', 'webshare')
                
                # ============================================================
                # PRIORITA #1: VIP/Trezor linky (ABSOLUTNÍ PRIORITA)
                # ============================================================
                if '★' in name or 'TREZOR' in name_upper or 'VIP' in name_upper:
                    return 1000000  # Okamžitý návrat
                
                # ============================================================
                # PRIORITA #2: FastShare a Webshare (STEJNÁ ÚROVEŇ)
                # ============================================================
                if provider in ['fastshare', 'webshare']:
                    # Využijeme existující parse_video_info pro detekci kvality
                    from resources.lib.utils import parse_video_info
                    v_info = parse_video_info(name, return_dict=True)
                    
                    # Bonus za shodu názvu seriálu
                    clean_name_norm = _norm(name_upper)
                    match_found = False
                    for t in [serial_original_name, serial_title]:
                        if not t: continue
                        nt = _norm(t)
                        if nt in clean_name_norm:
                            score += 10000  # Vysoký bonus za správný seriál
                            match_found = True
                            break
                    
                    if not match_found:
                        score -= 50000  # Velká penalizace za nesprávný název
                    
                    # Bonus za rozlišení
                    res = v_info.get('res', '')
                    if res == '4K': score += 500
                    elif res == '1080p': score += 400
                    elif res == '720p': score += 300
                    
                    # Bonus za český/slovenský dabing
                    langs = v_info.get('langs', [])
                    if 'CZ' in langs or 'SK' in langs:
                        score += 2000
                    
                    # Bonus za kvalitní kodek
                    codecs = v_info.get('codecs', [])
                    if 'HEVC' in codecs: score += 100
                    if 'HDR' in codecs: score += 150
                    
                    # Bonus za zdroj
                    source = v_info.get('source', [])
                    if 'Remux' in source: score += 200
                    elif 'BluRay' in source: score += 150
                    elif 'WEB-DL' in source: score += 100
                    
                    # Bonus za velikost (větší = lepší kvalita)
                    score += int(v.get('size', 0)) / 1073741824.0  # GB jako body

                    # Preferovat WebShare před FastShare s pouhým číselným ID — stránka fastshare.cloud často bez download.php (SPA)
                    rid = str(v.get('ident', '')).split('|')[0].strip()
                    if provider in ('fastshare', 'FS') and re.match(r'^\d{5,12}$', rid):
                        score -= 2500
                    
                    return score
                
                # ============================================================
                # PRIORITA #3: Hellspy (FREE ZDROJ - nejnižší priorita)
                # ============================================================
                elif provider in ['HELLSPY', 'HL']:
                    # Nízké základní skóre pro free zdroj
                    score = 100
                    
                    # Alespoň kontrola shody názvu
                    clean_name_norm = _norm(name_upper)
                    for t in [serial_original_name, serial_title]:
                        if not t: continue
                        nt = _norm(t)
                        if nt in clean_name_norm:
                            score += 50
                            break
                    
                    return score
                
                # Fallback
                return 0

            best_v = max(
                groups[ep_num],
                key=lambda v: (stream_language_rank_for_addon(v), get_selection_score(v)),
            )
            raw_ident = best_v.get('ident', '')
            provider = best_v.get('provider', 'webshare')
            size_str = format_size(best_v.get('size', 0))
            
            # Pro FS streamy ze search výsledků: sestavit page URL (s filename) pro resolver
            # Kodi playlist URL má omezení - celá download URL (s &filename) se ořeže při předávání
            # Proto sestavíme page URL: https://fastshare.cloud/{ID}/{filename}
            # Resolver pak otevře tuto URL a z HTML získá správný dataX download link
            if provider in ['fastshare', 'FS']:
                import re as _re
                fs_name = best_v.get('name', '')  # Originální filename ze search výsledků
                if raw_ident and 'fastshare' in str(raw_ident):
                    # Extrahovat ID z download URL: https://dataX.fastshare.cloud/download.php?id=12345&soubor.mp4
                    _m = _re.search(r'[?&]id=(\d{5,12})', str(raw_ident))
                    if _m:
                        fs_id = _m.group(1)
                        if fs_name:
                            # Sestavit page URL s filename - resolver ji potřebuje pro HTML s download linky
                            from urllib.parse import quote as _quote
                            raw_ident = f'https://fastshare.cloud/{fs_id}/{_quote(fs_name, safe=".-_")}'
                        else:
                            raw_ident = fs_id  # Fallback: jen ID
                    else:
                        # Extrahovat ID z page URL: https://fastshare.cloud/12345/soubor.mp4 (necháme jak je)
                        _m = _re.search(r'/(\d{5,12})(?:/|$)', str(raw_ident))
                        if _m and not fs_name:
                            raw_ident = _m.group(1)  # Jen ID pokud nemáme filename
                        # Pokud máme page URL s filename, necháme ji (je to ideální formát)
                elif raw_ident and _re.match(r'^\d{5,12}$', str(raw_ident)):
                    # Čisté ID - pokud máme filename, sestavíme page URL
                    if fs_name:
                        from urllib.parse import quote as _quote
                        raw_ident = f'https://fastshare.cloud/{raw_ident}/{_quote(fs_name, safe=".-_")}'
            ident = raw_ident
            
            # VALIDACE: Přeskočit Hellspy streamy bez platného fileHash
            if provider in ['HELLSPY', 'HL']:
                hs_url = best_v.get('url', '')
                if not hs_url or 'UNKNOWN' in hs_url:
                    _is_vip_pick_hs = bool(use_vip) or ('★' in str((best_v or {}).get('name', '')))
                    xbmc.log("SKIPPING HELLSPY stream without valid fileHash for S%02dE%02d: %s" % (season, ep_num, vip_safe(ident, _is_vip_pick_hs)), xbmc.LOGWARNING)
                    continue  # Přeskočit tuto epizodu

        # Poslední záchrana pro první díl: pokud nic z výše uvedeného nenastavilo ident a máme resume_ident, použijeme ho přímo.
        # play_file si pak poradí s resolverem - a pokud selže, Kodi přeskočí na další díl v playlistu.
        if ep_num == start_ep and resume_ident_norm and not ident:
            _watched_rec = _load_watched().get(resume_ident, {}) or _load_watched().get(resume_ident_norm, {})
            ident = resume_ident
            provider = _watched_rec.get('provider', '') or 'webshare'
            size_str = _watched_rec.get('size', '') or ''
            best_v = {'name': _watched_rec.get('title', ''), 'url': _watched_rec.get('url', '')}
            history_stream_type = (_watched_rec.get('stream_type') or '').strip().upper()
            # Schvalne nelogujeme resume_ident - muze jit o VIP link.
            xbmc.log("NEXASTREAM autoplay resume: používám uložený resume_ident přímo pro S%02dE%02d" % (season, ep_num), xbmc.LOGINFO)

        if ident:
            norm_id = str(ident).split('|')[0].strip()
            dedup_key = (str(provider).lower(), norm_id)
            if dedup_key in queued_stream_keys:
                _is_vip_dd = bool(use_vip) or ('★' in str((best_v or {}).get('name', '')))
                _log_key = ('[VIP]',) if _is_vip_dd else dedup_key
                xbmc.log(
                    "NEXASTREAM autoplay: přeskakuji duplicitní položku ve frontě S%02dE%02d %r" % (season, ep_num, _log_key),
                    xbmc.LOGINFO,
                )
                continue
            queued_stream_keys.add(dedup_key)

            # Přidat URL parametr pro Hellspy streamy
            url_params = {
                'mode': 'play',
                'ident': ident,
                'title': title_label,
                'media_type': 'episode',
                'size': size_str,
                'is_kids': is_kids,
                'provider': provider,
            }
            _is_vip_pick = bool(use_vip) or ('★' in str((best_v or {}).get('name', '')))
            if history_stream_type in ('VIP', 'APPROVED', 'HELLSPY'):
                url_params['stream_type'] = history_stream_type
            else:
                url_params['stream_type'] = 'VIP' if _is_vip_pick else ('HELLSPY' if str(provider).upper() in ('HELLSPY', 'HL') else 'STANDARD')
            if not first_playlist_entry:
                url_params['ns_chain'] = '1'
            
            # Pro Hellspy přidat kompletní URL s fileHash
            if provider in ['HELLSPY', 'HL'] and best_v.get('url'):
                url_params['url'] = best_v.get('url')

            # VIP: skryt realny ident/URL pred kodi.log. Kodi loguje kazdou polozku playlistu
            # na INFO. VIP identy z trezoru nahradime opaque tokenem; play_file si je vybali
            # z in-memory vaultu (Window(10000)).
            if _is_vip_pick and ident:
                try:
                    from resources.lib.vip_vault import put as _vip_put
                    _token = _vip_put({
                        'ident': ident,
                        'provider': provider,
                        'url': url_params.get('url', '') or '',
                    })
                    if _token:
                        url_params['ident'] = _token
                        url_params.pop('url', None)
                except Exception as _e:
                    xbmc.log('NEXASTREAM vip_vault: tokenize play_from_here failed: %s' % _e, xbmc.LOGWARNING)

            url = _url(**url_params)
            li = xbmcgui.ListItem(title_label)
            li.setInfo('video', {'title': title_label, 'tvshowtitle': cz_name or orig_name, 'season': season, 'episode': ep_num, 'mediatype': 'episode'})
            if ep_num == start_ep and resume_time_val > 0:
                li.setProperty('ResumeTime', str(resume_time_val))
                if resume_total_val > 0:
                    li.setProperty('TotalTime', str(resume_total_val))
            playlist.add(url, li)
            added += 1
            first_playlist_entry = False

    if added > 0:
        _ensure_locale_monitor()
        xbmc.Player().play(playlist)
        _notify(f'Autoplay: přidáno {added} epizod do fronty.')
    else:
        _notify('Nenalezeny epizody k přehrání.')