# -*- coding: utf-8 -*-
import xbmcplugin

from resources.lib.config import addon_handle
from resources.lib.domain.catalog_service import list_person_credits
from resources.lib.presentation.kodi.common_views import render_tmdb_list_paginated


def _person_media_type(item):
    value = item.get("type") or item.get("media_type") or "movie"
    if value in ("tv", "tvshow"):
        return "tvshow"
    return value


def render_person_credits(person_id, person_name, page=1):
    credits = list_person_credits(person_id) or []
    render_tmdb_list_paginated(
        items=credits,
        media_type_resolver=_person_media_type,
        mode="person_credits",
        base_params={"person_id": person_id, "person_name": person_name},
        page=page,
        empty_message="Nebyla nalezena žádná tvorba pro: " + person_name,
    )
