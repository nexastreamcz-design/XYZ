# -*- coding: utf-8 -*-
"""Sdílená utilita pro vykreslení stránkovaných seznamů TMDB položek.

Hlavní funkce ``render_tmdb_list_paginated`` dělá tři věci:
1. Odřízne ``page_size`` položek pro aktuální stránku.
2. Paralelně (ThreadPool 16 workerů) nahřeje TMDB disk cache pro celou
   stránku, takže následné volání ``_add_tmdb_item`` čte jen z cache.
3. Přidá tlačítko "Další strana" s přenesenými parametry.
"""
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcplugin

from resources.lib.config import addon_handle
from resources.lib.media_core import _add_tmdb_item
from resources.lib.utils import _add_dir, _end, _fail, _url

DEFAULT_PAGE_SIZE = 50
PREFETCH_WORKERS = 16


def _resolve_media_type(resolver, item, default="movie"):
    """Podpora buď stringu (stejný typ pro celou stránku), nebo callable."""
    if callable(resolver):
        try:
            value = resolver(item)
        except Exception:
            value = None
    else:
        value = resolver
    if not value:
        value = item.get("media_type") or item.get("type") or default
    if value in ("tv", "tvshow"):
        return "tvshow"
    return value or default


def _prefetch_tmdb(chunk, media_type_resolver):
    """Paralelně zahřeje TMDB disk cache pro aktuální stránku.

    Selhání prefetche nesmí shodit render – vytiskne jen warning.
    """
    if not chunk:
        return
    try:
        from resources.lib.api_client import get_tmdb_cached
    except Exception as err:
        xbmc.log("NEXASTREAM TMDB PREFETCH IMPORT ERROR: %s" % err, xbmc.LOGWARNING)
        return

    def _warm(it):
        try:
            tmdb_id = str(it.get("tmdb_id") or it.get("id") or "")
            if not tmdb_id:
                return
            mt = _resolve_media_type(media_type_resolver, it)
            get_tmdb_cached(tmdb_id, mt)
        except Exception as err:
            xbmc.log("NEXASTREAM TMDB PREFETCH ITEM ERROR: %s" % err, xbmc.LOGWARNING)

    try:
        workers = min(PREFETCH_WORKERS, max(1, len(chunk)))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(_warm, chunk))
    except Exception as err:
        xbmc.log("NEXASTREAM TMDB PREFETCH POOL ERROR: %s" % err, xbmc.LOGWARNING)


def render_tmdb_list_paginated(
    items,
    media_type_resolver,
    mode,
    base_params,
    page=1,
    page_size=DEFAULT_PAGE_SIZE,
    content_type="videos",
    empty_message="Tato složka neobsahuje žádné položky.",
):
    """Vykreslí stránku TMDB položek s paralelním prefetchem a „Další stranou".

    :param items: Seznam dict (každý má ``tmdb_id``/``id`` a volitelně
        ``media_type``/``type``). Plný seznam, ne již oříznutý.
    :param media_type_resolver: Buď string (stejný typ pro všechny položky),
        nebo callable ``(item) -> str``.
    :param mode: Router mode pro URL "Další strany" (např. ``"custom_folder"``).
    :param base_params: Dict dalších URL parametrů, které se přenesou na
        "Další stranu" (bez ``page``).
    :param page: 1-indexované číslo stránky.
    :param page_size: Počet položek na stránku (default 50).
    :param content_type: Kodi content type (``"videos"``/``"movies"``/``"tvshows"``).
    :param empty_message: Hláška, když je seznam prázdný.
    """
    xbmcplugin.setContent(addon_handle, content_type)

    if not items:
        return _fail(empty_message)

    try:
        page = max(1, int(page))
    except (TypeError, ValueError):
        page = 1

    total = len(items)
    total_pages = (total + page_size - 1) // page_size
    start = (page - 1) * page_size
    chunk = items[start:start + page_size]

    _prefetch_tmdb(chunk, media_type_resolver)

    for it in chunk:
        mt = _resolve_media_type(media_type_resolver, it)
        _add_tmdb_item(it, mt)

    if page < total_pages:
        next_params = dict(base_params)
        next_params["page"] = page + 1
        _add_dir(
            "[B]>> Další strana (%d/%d)[/B]" % (page + 1, total_pages),
            _url(mode=mode, **next_params),
        )

    _end()
