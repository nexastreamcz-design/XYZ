# -*- coding: utf-8 -*-
from resources.lib.domain.custom_folder_service import list_custom_folder_items
from resources.lib.presentation.kodi.common_views import render_tmdb_list_paginated


def render_custom_folder(raw_items, media_type="movie", page=1):
    items = list_custom_folder_items(raw_items, default_media_type=media_type)
    # Každá položka má vlastní "media_type" (mix filmů/seriálů ve složce).
    render_tmdb_list_paginated(
        items=items,
        media_type_resolver=lambda it: it.get("media_type", media_type),
        mode="custom_folder",
        base_params={"items": raw_items, "media_type": media_type},
        page=page,
        empty_message="Tato složka neobsahuje žádné položky.",
    )
