# -*- coding: utf-8 -*-
import xbmc
import xbmcplugin

from resources.lib.config import addon_handle
from resources.lib.domain.kids_service import list_kids_cz_movies, list_kids_discover, list_kids_vecernicky
from resources.lib.media_core import _add_tmdb_item
from resources.lib.presentation.kodi.common_views import render_tmdb_list_paginated
from resources.lib.utils import _add_dir, _end, _fail, _url


def render_kids_vecernicky(page=1):
    try:
        page = int(page)
        results, total_pages = list_kids_vecernicky(page=page)
        for item in results:
            _add_tmdb_item(item, "tvshow")
        if page < total_pages:
            _add_dir("[B]>> Další strana (%s/%s)[/B]" % (page + 1, total_pages), _url(mode="kids_vecernicky", page=page + 1))
        _end()
    except Exception as error:
        xbmc.log("NEXASTREAM VECERNICKY ERROR: %s" % str(error), xbmc.LOGERROR)
        _fail()


def render_kids_cz_movies(page=1):
    try:
        page = int(page)
        results, total_pages = list_kids_cz_movies(page=page)
        for item in results:
            _add_tmdb_item(item, "movie")
        if page < total_pages:
            _add_dir("[B]>> Další strana (%s/%s)[/B]" % (page + 1, total_pages), _url(mode="kids_cz_movies", page=page + 1))
        _end()
    except Exception as error:
        xbmc.log("NEXASTREAM CZ POHADKY ERROR: %s" % str(error), xbmc.LOGERROR)
        _fail()


def render_kids_discover(media_type="movie", page=1):
    try:
        results = list_kids_discover(media_type=media_type) or []
        resolved_mt = "movie" if media_type == "movie" else "tvshow"
        render_tmdb_list_paginated(
            items=results,
            media_type_resolver=resolved_mt,
            mode="kids_discover",
            base_params={"m_type": media_type},
            page=page,
            content_type="movies" if media_type == "movie" else "tvshows",
            empty_message="Nebyly nalezeny žádné dětské tituly.",
        )
    except Exception as error:
        xbmc.log("NEXASTREAM KIDS ERROR: %s" % str(error), xbmc.LOGERROR)
        _fail()
