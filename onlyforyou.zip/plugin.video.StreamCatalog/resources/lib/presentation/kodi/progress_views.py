# -*- coding: utf-8 -*-
import xbmcgui
import xbmcplugin

from resources.lib.config import addon_handle
from resources.lib.domain.history_service import get_in_progress_items
from resources.lib.utils import _end, _fail, _set_info, _url, format_stream_label


def render_in_progress_list(is_kids=False):
    xbmcplugin.setContent(addon_handle, "videos")
    items = get_in_progress_items(is_kids=is_kids)
    if not items:
        if is_kids:
            return _fail("Zatím nemáte v Dětském světě nic rozkoukáno.")
        return _fail("Zatím nemáte v kategorii Filmů nic rozkoukáno.")

    for item in items:
        ident = item["ident"]
        data = item["data"]
        provider = item["provider"]
        size_str = item["size_str"]
        clean_title = item["clean_title"]
        stream_data = {
            "stream_type": item["stream_type"],
            "name": item["raw_title"],
            "provider": provider,
            "size_str": size_str,
            "real_title": clean_title,
            "orig_title": clean_title,
            "year": data.get("year", ""),
            "plus": 0,
            "minus": 0,
        }
        formatted = format_stream_label(stream_data, context="movie")
        li = xbmcgui.ListItem(formatted["label"])
        li.setProperty("IsPlayable", "true")

        if data.get("img"):
            li.setArt(
                {
                    "thumb": data["img"],
                    "poster": data["img"],
                    "fanart": data.get("fanart", data["img"]),
                    "icon": data["img"],
                }
            )

        li.setProperty("ResumeTime", str(data["resume_time"]))
        if data.get("total_time"):
            li.setProperty("TotalTime", str(data["total_time"]))

        _set_info(
            li,
            {
                "title": formatted["clean_title"],
                "mediatype": data.get("media_type", "movie"),
                "plot": formatted["plot"],
            },
        )
        li.addContextMenuItems([("Odebrat z historie", "RunPlugin(%s)" % _url(mode="remove_watched", ident=ident))])

        play_params = {
            "mode": "play",
            "ident": ident,
            "title": formatted["clean_title"],
            "media_type": data.get("media_type", "movie"),
            "size": size_str,
            "provider": provider,
            "season": data.get("season", ""),
            "stream_type": item["stream_type"],
        }
        tid = (data.get("tmdb_id") or "").strip()
        if tid:
            play_params["tmdb_id"] = tid
        epn = data.get("episode", "")
        if epn not in (None, "", 0):
            play_params["episode"] = str(epn)
        if is_kids:
            play_params["is_kids"] = "true"
        if provider == "HELLSPY" and data.get("url"):
            play_params["url"] = data.get("url")

        xbmcplugin.addDirectoryItem(addon_handle, _url(**play_params), li, False)
    _end()
