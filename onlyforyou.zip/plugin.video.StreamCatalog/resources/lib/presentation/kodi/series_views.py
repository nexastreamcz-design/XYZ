# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.config import addon_handle
from resources.lib.domain.history_service import get_active_series_items, remove_series_from_history
from resources.lib.utils import _end, _fail, _notify, _set_info, _url


def render_active_series(is_kids="false"):
    xbmcplugin.setContent(addon_handle, "tvshows")
    items = get_active_series_items(is_kids=is_kids == "true")
    if not items:
        return _fail("Zatím nemáte rozezkoukaný žádný seriál v této kategorii.")

    for item in items:
        show_name = item["show_name"]
        show_data = item["show_data"]
        last_episode = item["last_episode"]
        metadata = item["metadata"]
        season = show_data.get("season", "")
        tmdb_id = show_data.get("tmdb_id", "")
        orig_title = show_data.get("orig_title", show_name)

        label, plot = _build_show_label(show_name, season, last_episode, metadata)
        li = xbmcgui.ListItem(label)
        artwork = {
            "thumb": metadata.get("episode_still") or metadata.get("season_poster") or show_data.get("img", "DefaultTVShows.png"),
            "poster": metadata.get("season_poster") or show_data.get("img", "DefaultTVShows.png"),
            "fanart": metadata.get("episode_still") or metadata.get("season_poster") or show_data.get("img", "DefaultTVShows.png"),
            "icon": metadata.get("episode_still") or metadata.get("season_poster") or show_data.get("img", "DefaultTVShows.png"),
        }
        li.setArt(artwork)
        _set_info(li, {"title": label, "plot": plot, "mediatype": "tvshow"})
        li.addContextMenuItems(
            [
                (
                    "Zobrazit všechny série",
                    "Container.Update(%s)"
                    % _url(mode="series_list", serial_title=show_name, serial_original_name=orig_title, tmdb_id=tmdb_id, is_kids=is_kids),
                ),
                (
                    "Odebrat z rozkoukaných",
                    "RunPlugin(%s)" % _url(mode="remove_series_from_watched", show_name=show_name, is_kids=is_kids),
                ),
            ]
        )
        url_kwargs = {
            "mode": "episodes",
            "serial_title": show_name,
            "serial_original_name": orig_title,
            "tmdb_id": tmdb_id,
            "season": season,
            "is_kids": is_kids,
        }
        if last_episode and last_episode.get("episode"):
            url_kwargs["focus_episode"] = last_episode["episode"]
            if last_episode.get("ident"):
                url_kwargs["resume_ident"] = last_episode["ident"]
                url_kwargs["resume_time"] = last_episode.get("resume_time", 0)
                url_kwargs["resume_total"] = last_episode.get("total_time", 0)
        url = _url(**url_kwargs)
        xbmcplugin.addDirectoryItem(addon_handle, url, li, True)
    _end()


def remove_series_and_refresh(show_name, is_kids="false"):
    removed_count = remove_series_from_history(show_name, is_kids=is_kids == "true")
    if removed_count > 0:
        _notify('Odebráno %s epizod seriálu "%s"' % (removed_count, show_name))
    else:
        _notify('Seriál "%s" nebyl nalezen v historii' % show_name)
    xbmc.executebuiltin("Container.Refresh")


def _build_show_label(show_name, season, last_episode, metadata):
    episode_name = metadata.get("episode_name", "")
    episode_plot = metadata.get("episode_plot", "")
    if last_episode and episode_name:
        label = "[B]%s[/B] - S%02dE%02d %s [COLOR cyan][Rozkoukané][/COLOR]" % (
            show_name,
            int(season),
            int(last_episode["episode"]),
            episode_name,
        )
        plot = 'Pokračujte ve sledování epizody "%s" (Série %s, Epizoda %s)' % (episode_name, season, last_episode["episode"])
        if episode_plot:
            plot += "\n\n" + episode_plot
        return label, plot
    if last_episode:
        label = "[B]%s[/B] - S%02dE%02d [COLOR cyan][Rozkoukané][/COLOR]" % (show_name, int(season), int(last_episode["episode"]))
        plot = "Pokračujte ve sledování série %s, epizody %s" % (season, last_episode["episode"])
        return label, plot
    return "[B]%s[/B] [COLOR cyan][Rozkoukané][/COLOR]" % show_name, "Pokračujte ve sledování seriálu %s" % show_name
