# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import tmdb_api
import webshare
from resources.lib.config import addon, addon_handle, TMDB_KEY
from resources.lib.utils import _url, _add_dir, _set_info, _end, _fail, get_ssl_context
from resources.lib.local_db import _load_searches, _save_search
from resources.lib.tmdb_search_rank import sort_tmdb_search_results

def do_search(search_id='', query=''):
    if not query:
        popisek = 'osobu' if search_id == 'person' else 'dětský pořad' if search_id == 'kids' else 'seriál' if search_id == 'tvshow' else 'film' if search_id == 'movie' else 'vše (Filmy i Seriály)'
        kb = xbmc.Keyboard('', 'Hledat ' + popisek)
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip(): return _fail()
        query = kb.getText().strip()
    
    _save_search(query, search_id)

    if search_id == 'person':
        _do_search_person(query)
    elif search_id == 'tvshow':
        _search_series_with_tmdb(query)
    elif search_id == 'movie':
        _search_movies_with_tmdb(query, page=1)
    elif search_id == 'kids':
        _search_kids_with_tmdb(query)
    else:
        _search_multi_with_tmdb(query)

def search_more(keyword, search_id='movie', page=1):
    import sys
    try:
        from urllib.parse import parse_qsl
    except ImportError:
        from urllib import parse_qsl
    current_params = dict(parse_qsl(sys.argv[2][1:]))
    is_alphabet = current_params.get('is_alphabet') == 'true'

    if search_id == 'movie': 
        _search_movies_with_tmdb(keyword, page=int(page), is_alphabet=is_alphabet)
    elif search_id == 'tvshow':
        _search_series_with_tmdb(keyword, page=int(page), is_alphabet=is_alphabet)
    else: 
        do_search(search_id=search_id, query=keyword)

def search_menu(search_id='', is_kids='false'):
    xbmcplugin.setContent(addon_handle, 'videos')
    _add_dir('[COLOR lime]>> Nové hledání[/COLOR]', _url(mode='do_search', search_id=search_id, is_kids=is_kids))
    if search_id != 'person':
        _add_dir('[COLOR gold]Hledat podle herce / režiséra[/COLOR]', _url(mode='search_menu', search_id='person', is_kids=is_kids))
    if search_id != 'person':
        try:
            trends = tmdb_api.get_trending(TMDB_KEY)
            if trends:
                kids_genres, filtered = {16, 10751, 10762}, []
                for t in trends:
                    if is_kids == 'true':
                        if set(t.get('genre_ids', [])).intersection(kids_genres): filtered.append(t)
                    elif search_id == 'movie':
                        if t.get('type') == 'movie' or t.get('media_type') == 'movie': filtered.append(t)
                    elif search_id == 'tvshow':
                        if t.get('type') == 'tvshow' or t.get('media_type') == 'tv': filtered.append(t)
                    else: filtered.append(t)
                if filtered:
                    li_header = xbmcgui.ListItem('[COLOR FF10B981][B]Aktuálně v kurzu[/B][/COLOR]')
                    li_header.setArt({'icon': 'DefaultTags.png', 'thumb': 'DefaultTags.png'})
                    xbmcplugin.addDirectoryItem(addon_handle, _url(mode='search_menu', search_id=search_id, is_kids=is_kids), li_header, True)
                    
                    # --- ZDE JE ZMĚNA: Použijeme hlavní vykreslovač pro plné detaily ---
                    from resources.lib.media_core import _add_tmdb_item
                    for t in filtered[:3]:
                        m_type = t.get('media_type') or t.get('type')
                        sid = 'movie' if m_type == 'movie' else 'tvshow'
                        
                        # Příprava dat pro hlavní vykreslovač
                        t['tmdb_id'] = str(t.get('id', ''))
                        t['is_kids'] = (is_kids == 'true')
                        t['title'] = t.get('title') or t.get('name') or t.get('original_name') or 'Neznámý název'
                        t['plot'] = t.get('overview') or t.get('plot', '')
                        
                        # Tohle stáhne herce, hodnocení a vytvoří plnohodnotnou položku
                        _add_tmdb_item(t, sid)
                    # -------------------------------------------------------------------
        except: pass
    searches = _load_searches(search_id)
    if searches:
        _add_dir('[COLOR red][B]Historie hledání[/B][/COLOR]', '')
        for s in searches:
            li = xbmcgui.ListItem(s)
            li.setArt({'icon': 'DefaultAddonsSearch.png', 'thumb': 'DefaultAddonsSearch.png'})
            li.addContextMenuItems([('Smazat z historie', f'RunPlugin({_url(mode="delete_search_item", query=s, search_id=search_id)})')])
            xbmcplugin.addDirectoryItem(addon_handle, _url(mode='do_search', search_id=search_id, query=s, is_kids=is_kids), li, True)
        _add_dir('[COLOR gray]Vymazat celou historii[/COLOR]', _url(mode='clear_search_history', search_id=search_id))
    _end()

def _search_kids_with_tmdb(keyword):
    from resources.lib.media_core import _add_tmdb_item
    xbmcplugin.setContent(addon_handle, 'videos')
    try:
        import urllib.request, urllib.parse, json
        url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_KEY}&language=cs-CZ&query={urllib.parse.quote(keyword)}"
        with urllib.request.urlopen(url, context=get_ssl_context()) as r:
            results = json.loads(r.read().decode('utf-8')).get('results', [])
    except: results = []
    if not results: return _fail('V databázi TMDB nebylo nic nalezeno pro: ' + keyword)
    vip_ids = set()
    kids_genres, filtered_results = {16, 10751, 10762}, []
    for item in results:
        m_type = item.get('media_type', '')
        if m_type in ['movie', 'tv'] and set(item.get('genre_ids', [])).intersection(kids_genres): filtered_results.append(item)
    if not filtered_results: return _fail('Nenalezena žádná pohádka pro: ' + keyword)
    sort_tmdb_search_results(filtered_results, keyword, vip_ids)
    for item in filtered_results:
        m_type = item.get('media_type', '')
        item['tmdb_id'], item['year'], item['orig_title'] = str(item.get('id', '')), (item.get('release_date') or item.get('first_air_date') or '').split('-')[0], item.get('original_title') or item.get('original_name') or ''
        if item.get('poster_path'): item['poster'] = 'https://image.tmdb.org/t/p/w500' + item['poster_path']
        if item.get('backdrop_path'): item['backdrop'] = 'https://image.tmdb.org/t/p/w1280' + item['backdrop_path']
        if m_type == 'tv': item['title'] = f"[COLOR gray][TV][/COLOR] {item.get('name', '')}"; _add_tmdb_item(item, 'tvshow')
        else: item['title'] = item.get('title', ''); _add_tmdb_item(item, 'movie')
    _end()

def _search_multi_with_tmdb(keyword):
    from resources.lib.media_core import _add_tmdb_item
    xbmcplugin.setContent(addon_handle, 'videos')
    try:
        import urllib.request, urllib.parse, json
        url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_KEY}&language=cs-CZ&query={urllib.parse.quote(keyword)}"
        with urllib.request.urlopen(url, context=get_ssl_context()) as r:
            results = json.loads(r.read().decode('utf-8')).get('results', [])
    except Exception as e: xbmc.log(f"NEXASTREAM MULTI-SEARCH ERROR: {str(e)}", xbmc.LOGERROR); results = []
    if not results: return _fail('V databázi TMDB nebylo nic nalezeno pro: ' + keyword)
    vip_ids = set()
    sort_tmdb_search_results(results, keyword, vip_ids)
    for item in results:
        m_type = item.get('media_type', '')
        if m_type not in ['movie', 'tv']: continue 
        item['tmdb_id'], item['year'], item['orig_title'] = str(item.get('id', '')), (item.get('release_date') or item.get('first_air_date') or '').split('-')[0], item.get('original_title') or item.get('original_name') or ''
        if item.get('poster_path'): item['poster'] = 'https://image.tmdb.org/t/p/w500' + item['poster_path']
        if item.get('backdrop_path'): item['backdrop'] = 'https://image.tmdb.org/t/p/w1280' + item['backdrop_path']
        if m_type == 'tv': item['title'] = f"[COLOR gray][TV][/COLOR] {item.get('name', '')}"; _add_tmdb_item(item, 'tvshow')
        else: item['title'] = item.get('title', ''); _add_tmdb_item(item, 'movie')
    _end()

def _search_series_with_tmdb(keyword, page=1, is_alphabet=False):
    from resources.lib.media_core import _add_tmdb_item
    xbmcplugin.setContent(addon_handle, 'tvshows')
    page = int(page)
    results = []
    total_pages = 1
    
    if is_alphabet:
        current_page = page
        pfx = keyword.lower()
        prog = xbmcgui.DialogProgress()
        prog.create(addon.getAddonInfo('name') or 'Addon', f'Filtruji seriály na: {keyword}')
        try:
            while len(results) < 20 and current_page <= page + 10:
                if prog.iscanceled(): break
                prog.update(int(((current_page - page) / 10.0) * 100), f'Prohledávám databázi (strana {current_page})...')
                
                raw = tmdb_api.search_tvshows(TMDB_KEY, keyword, page=current_page)
                page_results, total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
                if not page_results: break
                
                for x in page_results:
                    t = str(x.get('name', x.get('title', ''))).lower()
                    o = str(x.get('original_name', x.get('orig_title', ''))).lower()
                    if t.startswith(pfx) or o.startswith(pfx):
                        if x not in results: results.append(x)
                        
                if current_page >= total_pages: break
                current_page += 1
        finally: prog.close()
        next_page = current_page if current_page <= total_pages else 0
    else:
        try:
            raw = tmdb_api.search_tvshows(TMDB_KEY, keyword, page=page)
            results, total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
        except: results, total_pages = [], 1
        next_page = page + 1 if page < total_pages else 0

    if not results: 
        if not is_alphabet:
            from resources.lib.tvshows import show_series_list
            return show_series_list(serial_title=keyword)
        else:
            return _fail('V TMDB nebylo nalezeno nic pod: ' + keyword)

    vip_ids = set()
    sort_tmdb_search_results(results, keyword, vip_ids)
    for item in results: _add_tmdb_item(item, 'tvshow')
    if next_page and next_page <= total_pages: 
        _add_dir(f'[B]>> Další strana[/B]', _url(mode='search_more', keyword=keyword, search_id='tvshow', page=next_page, is_alphabet='true' if is_alphabet else 'false'))
    _end()

def _search_movies_with_tmdb(keyword, page=1, is_alphabet=False):
    from resources.lib.media_core import _add_tmdb_item
    xbmcplugin.setContent(addon_handle, 'movies')
    page = int(page)
    results = []
    total_pages = 1
    
    if is_alphabet:
        current_page = page
        pfx = keyword.lower()
        prog = xbmcgui.DialogProgress()
        prog.create(addon.getAddonInfo('name') or 'Addon', f'Filtruji filmy na: {keyword}')
        try:
            while len(results) < 20 and current_page <= page + 10:
                if prog.iscanceled(): break
                prog.update(int(((current_page - page) / 10.0) * 100), f'Prohledávám databázi (strana {current_page})...')
                
                raw = tmdb_api.search_movies(TMDB_KEY, keyword, page=current_page)
                page_results, total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
                if not page_results: break
                
                for x in page_results:
                    t = str(x.get('title', '')).lower()
                    o = str(x.get('orig_title', x.get('original_title', ''))).lower()
                    if t.startswith(pfx) or o.startswith(pfx):
                        if x not in results: results.append(x)
                        
                if current_page >= total_pages: break
                current_page += 1
        finally: prog.close()
        next_page = current_page if current_page <= total_pages else 0
    else:
        try:
            raw = tmdb_api.search_movies(TMDB_KEY, keyword, page=page)
            results, total_pages = (raw if isinstance(raw, tuple) else (raw, 1))
        except: results, total_pages = [], 1
        next_page = page + 1 if page < total_pages else 0

    if not results: return _fail('V TMDB nebyl nalezen film pod: ' + keyword)
    vip_ids = set()
    sort_tmdb_search_results(results, keyword, vip_ids)
    for item in results: _add_tmdb_item(item, 'movie')
    if next_page and next_page <= total_pages: 
        _add_dir(f'[B]>> Další strana[/B]', _url(mode='search_more', keyword=keyword, search_id='movie', page=next_page, is_alphabet='true' if is_alphabet else 'false'))
    _end()

def _do_search_person(query, page=1):
    xbmcplugin.setContent(addon_handle, 'videos')
    page = int(page)
    results, total_pages = tmdb_api.search_people(TMDB_KEY, query, page)
    if not results: return _fail('Nebyla nalezena žádná osoba: ' + query)
    for p in results:
        li = xbmcgui.ListItem(f"[B]{p['name']}[/B]")
        if p['thumb']: li.setArt({'thumb': p['thumb'], 'icon': p['thumb']})
        if p['known_for']: _set_info(li, {'title': p['name'], 'plot': 'Známý z: ' + p['known_for']})
        xbmcplugin.addDirectoryItem(addon_handle, _url(mode='person_credits', person_id=p['id'], person_name=p['name']), li, True)
    if page < total_pages: _add_dir(f'[B]>> Další strana ({page + 1}/{total_pages})[/B]', _url(mode='do_search_person', query=query, page=page + 1))
    _end()

def _do_search_files(query, media_type='movie', is_alphabet=False):
    from resources.lib.auth import _get_token
    from resources.lib.media_core import _show_file_items
    token = _get_token()
    if not token and not (addon.getSetting('fs_username') and addon.getSetting('fs_password')):
        return _fail('Pro hledání souborů zadejte WebShare nebo FastShare v nastavení.')
    poster, backdrop = '', ''
    
    if not is_alphabet:
        try:
            tmdb_results = tmdb_api.search_movies(TMDB_KEY, query)
            if tmdb_results and isinstance(tmdb_results, tuple): tmdb_results = tmdb_results[0]
            if tmdb_results and len(tmdb_results) > 0: best = tmdb_results[0]; poster, backdrop = best.get('poster', ''), best.get('backdrop', '')
        except: pass
        
    prog = xbmcgui.DialogProgress()
    prog.create(addon.getAddonInfo('name') or 'Addon', 'Hledani: %s' % query)
    try: 
        files = []
        if token:
            files = webshare.search_for_title(token, query)
            if is_alphabet and files:
                pfx = query.lower()
                from resources.lib.utils import clean_title
                files = [f for f in files if str(clean_title(f.get('name', ''), remove_quality=True)).lower().startswith(pfx)]
    except: files = []
    finally: prog.close()
    
    if not files: return _fail('Zadne vysledky pro: %s' % query)
    xbmcplugin.setContent(addon_handle, 'movies' if media_type == 'movie' else 'tvshows')
    _show_file_items(files, media_type=media_type, poster=poster, backdrop=backdrop)
    _end()

def alphabet_root(prefix='', media_type='movie'):
    xbmcplugin.setContent(addon_handle, 'videos')
    if prefix:
        _add_dir('[COLOR orange]Vyhledat vše co začíná na "%s"[/COLOR]' % prefix, _url(mode='alphabet_search', prefix=prefix, media_type=media_type))
        letters = list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    else: letters = (list('ABCDEFGHIJKLMNOPQRSTUVWXYZ') + [u'\xc1',u'\u010c',u'\u010e',u'\xc9',u'\u011a',u'\xcd',u'\u0147',u'\xd3',u'\u0158',u'\u0160',u'\u0164',u'\xda',u'\u016e',u'\xdd',u'\u017d'] + list('0123456789'))
    for letter in letters: _add_dir('[B]%s[/B]' % (prefix + letter), _url(mode='alphabet_root', prefix=(prefix + letter), media_type=media_type))
    _end()

def alphabet_search(prefix, media_type='movie'):
    if media_type == 'tvshow': _search_series_with_tmdb(prefix, page=1, is_alphabet=True)
    else: _search_movies_with_tmdb(prefix, page=1, is_alphabet=True)
