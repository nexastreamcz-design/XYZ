# -*- coding: utf-8 -*-
"""
Měření rychlosti internetu pro adaptivní strop velikosti souborů.

- measure_download_mbps() stáhne ~25 MB z veřejného CDN a spočítá Mbps.
- mbps_to_max_size_mb() převede naměřenou rychlost na doporučený max. souboru.
- run_measurement_ui() obstará uživatelské rozhraní (progress bar + notifikace)
  a uloží výsledek do nastavení doplňku.
"""

import time
import ssl
import socket
import threading
import urllib.request
import urllib.error

import xbmc
import xbmcgui

from resources.lib.config import addon
from resources.lib.utils import format_size


# --------------------------------------------------------------------------- #
# Konfigurace
# --------------------------------------------------------------------------- #

# Primární endpoint: Cloudflare – stabilní CDN, široká dostupnost (CZ/SK).
# Parametr ?bytes= určuje, kolik bajtů se má odeslat.
PRIMARY_URL = 'https://speed.cloudflare.com/__down?bytes={bytes}'

# Záložní endpoint (Tele2 – evropské CDN). Pevná 10 MB velikost.
FALLBACK_URL = 'https://speedtest.tele2.net/10MB.zip'
FALLBACK_SIZE_BYTES = 10 * 1024 * 1024

CHUNK = 64 * 1024          # 64 kB čtecí chunk
DEFAULT_TARGET_MB = 25     # kolik MB stáhneme z primáru
DEFAULT_TIMEOUT = 15       # hard timeout v sekundách


# --------------------------------------------------------------------------- #
# Měření
# --------------------------------------------------------------------------- #

def _ssl_ctx():
    try:
        return ssl.create_default_context()
    except Exception:
        return None


def _download_and_measure(url, max_bytes, timeout):
    """Stáhne do `max_bytes` z URL. Vrací (bytes_read, elapsed_seconds)."""
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Kodi-StreamCatalog-Speedtest/1.0',
        'Cache-Control': 'no-cache',
    })
    ctx = _ssl_ctx()

    start = time.time()
    bytes_read = 0
    deadline = start + timeout
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            while True:
                if time.time() >= deadline:
                    break
                if bytes_read >= max_bytes:
                    break
                remaining = min(CHUNK, max_bytes - bytes_read)
                try:
                    buf = r.read(remaining)
                except (socket.timeout, ssl.SSLError):
                    break
                if not buf:
                    break
                bytes_read += len(buf)
    finally:
        elapsed = max(time.time() - start, 0.001)
    return bytes_read, elapsed


def measure_download_mbps(target_mb=DEFAULT_TARGET_MB, timeout=DEFAULT_TIMEOUT):
    """
    Vrátí tuple (mbps, bytes_read, elapsed, source).

    mbps – skutečný naměřený download throughput.
    source – 'cloudflare' | 'tele2' | 'failed'

    Pokud primární URL selže nebo vrátí příliš málo dat, zkusíme fallback.
    """
    target_bytes = int(target_mb * 1024 * 1024)
    primary = PRIMARY_URL.format(bytes=target_bytes)

    try:
        bytes_read, elapsed = _download_and_measure(primary, target_bytes, timeout)
        if bytes_read >= 1024 * 512:  # aspoň 512 kB, ať nepočítáme z nesmyslu
            mbps = (bytes_read * 8.0) / (elapsed * 1_000_000.0)
            return (mbps, bytes_read, elapsed, 'cloudflare')
        xbmc.log('NEXASTREAM speedtest: primary dodal jen %d B, zkousim fallback' % bytes_read,
                 xbmc.LOGWARNING)
    except (urllib.error.URLError, socket.error, ssl.SSLError, Exception) as e:
        xbmc.log('NEXASTREAM speedtest: primary selhal (%s), zkousim fallback' % e,
                 xbmc.LOGWARNING)

    try:
        bytes_read, elapsed = _download_and_measure(FALLBACK_URL, FALLBACK_SIZE_BYTES, timeout)
        if bytes_read >= 1024 * 512:
            mbps = (bytes_read * 8.0) / (elapsed * 1_000_000.0)
            return (mbps, bytes_read, elapsed, 'tele2')
    except Exception as e:
        xbmc.log('NEXASTREAM speedtest: fallback selhal (%s)' % e, xbmc.LOGERROR)

    return (0.0, 0, 0.0, 'failed')


# --------------------------------------------------------------------------- #
# Převod Mbps → doporučený max. soubor
# --------------------------------------------------------------------------- #

def mbps_to_max_size_mb(mbps):
    """
    Mapování naměřené rychlosti na strop velikosti souboru.

    Uvažujeme 75% využitelnost linky (rezerva na kolísání + overhead).
    Pro 2h film: bitrate v Mbps × 900 ≈ velikost v MB.

    Tabulka stropů:
        <4 Mbps       -> 1 200 MB (SD)
        4–10 Mbps     -> 3 000 MB (720p-ish)
        10–25 Mbps    -> 7 000 MB (1080p)
        25–60 Mbps    -> 15 000 MB (4K-light)
        >60 Mbps      -> 0 (= bez limitu)
    """
    try:
        m = float(mbps)
    except (TypeError, ValueError):
        return 0

    if m <= 0:
        return 0
    if m < 4:
        return 1200
    if m < 10:
        return 3000
    if m < 25:
        return 7000
    if m < 60:
        return 15000
    return 0  # super rychlá linka, nic neomezujeme


# --------------------------------------------------------------------------- #
# UI
# --------------------------------------------------------------------------- #

class _MeasureThread(threading.Thread):
    """Měření ve vlákně, aby nezamrzlo UI."""
    def __init__(self):
        super(_MeasureThread, self).__init__()
        self.daemon = True
        self.result = None

    def run(self):
        try:
            self.result = measure_download_mbps()
        except Exception as e:
            xbmc.log('NEXASTREAM speedtest thread: %s' % e, xbmc.LOGERROR)
            self.result = (0.0, 0, 0.0, 'failed')


def run_measurement_ui():
    """
    Spustí měření s progress barem a po skončení uloží výsledek do nastavení
    a zobrazí uživateli notifikaci.
    """
    dlg = xbmcgui.DialogProgressBG()
    try:
        dlg.create(addon.getAddonInfo('name') or 'Addon', 'Měřím rychlost internetu...')
    except Exception:
        dlg = None

    t = _MeasureThread()
    t.start()

    # Animace progress baru (1 % / 150 ms, max 90 % dokud nedoběhne měření)
    pct = 0
    while t.is_alive():
        pct = min(pct + 2, 90)
        if dlg:
            try:
                dlg.update(pct, addon.getAddonInfo('name') or 'Addon', 'Měřím rychlost internetu... %d %%' % pct)
            except Exception:
                pass
        xbmc.sleep(150)

    t.join(timeout=1)
    if dlg:
        try:
            dlg.update(100, addon.getAddonInfo('name') or 'Addon', 'Hotovo')
            dlg.close()
        except Exception:
            pass

    mbps, bytes_read, elapsed, source = t.result or (0.0, 0, 0.0, 'failed')

    if source == 'failed' or mbps <= 0:
        xbmcgui.Dialog().notification(
            addon.getAddonInfo('name') or 'Addon',
            'Měření selhalo – zkontroluj připojení. Limit zůstal nezměněn.',
            xbmcgui.NOTIFICATION_WARNING, 5000,
        )
        xbmc.log('NEXASTREAM speedtest: measurement failed', xbmc.LOGWARNING)
        return

    max_mb = mbps_to_max_size_mb(mbps)

    # Uložit do nastavení
    try:
        addon.setSetting('measured_mbps', '%.1f' % mbps)
        addon.setSetting('last_measured_ts', time.strftime('%Y-%m-%d %H:%M'))
        addon.setSetting('max_size_mb', str(int(max_mb)))
    except Exception as e:
        xbmc.log('NEXASTREAM speedtest: setSetting selhal (%s)' % e, xbmc.LOGERROR)

    # Uživatelská hláška
    limit_text = 'bez limitu' if max_mb == 0 else format_size(max_mb * 1024 * 1024)
    msg = 'Rychlost: %.1f Mbps  (%s, %.1f s)  -> limit: %s' % (
        mbps, source.upper(), elapsed, limit_text
    )
    xbmc.log('NEXASTREAM speedtest: %s' % msg, xbmc.LOGINFO)
    xbmcgui.Dialog().notification(
        addon.getAddonInfo('name') or 'Addon',
        msg,
        xbmcgui.NOTIFICATION_INFO, 6000,
    )
