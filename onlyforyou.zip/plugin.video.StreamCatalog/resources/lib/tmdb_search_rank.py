# -*- coding: utf-8 -*-
"""Lokální relevance TMDB výsledků hledání (bez mazání položek, jen řazení)."""
import re

import webshare

# Vyšší = lepší shoda s dotazem
_SCORE_EXACT = 1000000
_SCORE_PREFIX = 500000
_SCORE_ALL_WORDS = 350000
_SCORE_WORD = 300000
_SCORE_SUBSTR = 100000
_SCORE_WEAK = 1


def _strip_wrapping_quotes(q):
    q = (q or '').strip()
    if len(q) >= 2 and q[0] == q[-1] and q[0] in ('"', "'"):
        return q[1:-1].strip()
    return q


def _strip_leading_article(t):
    if t.startswith('the ') and len(t) > 4:
        return t[4:].strip()
    return t


def _title_variants(item):
    out, seen = [], set()
    for key in ('title', 'name', 'original_title', 'original_name', 'orig_title'):
        v = item.get(key)
        if not v:
            continue
        s = str(v).strip()
        if not s or s in seen:
            continue
        seen.add(s)
        out.append(s)
    return out


def _score_title_against_query(t_norm, q_norm):
    if not q_norm:
        return _SCORE_WEAK
    if not t_norm:
        return _SCORE_WEAK

    t_article = _strip_leading_article(t_norm)
    q_article = _strip_leading_article(q_norm)

    if t_norm == q_norm or t_article == q_article:
        return _SCORE_EXACT
    if t_norm == q_article or t_article == q_norm:
        return _SCORE_EXACT - 500

    if t_norm.startswith(q_norm + ' ') or t_article.startswith(q_article + ' '):
        return _SCORE_PREFIX
    if len(q_norm) >= 2 and (t_norm.startswith(q_norm) or t_article.startswith(q_norm)):
        return _SCORE_PREFIX - 1000

    tokens = [tok for tok in q_norm.split() if tok]
    if tokens:
        try:
            if all(re.search(r'\b' + re.escape(tok) + r'\b', t_norm) for tok in tokens):
                return _SCORE_ALL_WORDS if len(tokens) > 1 else _SCORE_WORD
        except re.error:
            pass

    if q_norm in t_norm or q_norm in t_article:
        return _SCORE_SUBSTR

    return _SCORE_WEAK


def tmdb_match_score(query, item):
    """
    Vrátí nejlepší skóre shody dotazu s libovolným názvem položky (CZ / EN / original).
    """
    q_raw = _strip_wrapping_quotes(query or '')
    q_norm = webshare._norm(q_raw)
    if not q_norm:
        return _SCORE_WEAK

    best = _SCORE_WEAK
    for title in _title_variants(item):
        t_norm = webshare._norm(title)
        best = max(best, _score_title_against_query(t_norm, q_norm))
    return best


def tmdb_search_sort_key(item, query, vip_ids):
    """Řadicí klíč: VIP první, pak relevance, pak TMDB popularita."""
    tid = str(item.get('id', item.get('tmdb_id', '')) or '')
    vip_rank = 0 if tid in vip_ids else 1
    score = tmdb_match_score(query, item)
    try:
        pop = float(item.get('popularity') or 0.0)
    except (TypeError, ValueError):
        pop = 0.0
    return (vip_rank, -score, -pop)


def sort_tmdb_search_results(results, query, vip_ids):
    """In-place řazení seznamu výsledků TMDB."""
    if not results:
        return results
    results.sort(key=lambda x: tmdb_search_sort_key(x, query, vip_ids))
    return results
