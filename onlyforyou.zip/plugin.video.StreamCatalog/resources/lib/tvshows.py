# -*- coding: utf-8 -*-
import json
import re
import time
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import tmdb_api
import webshare
from resources.lib.config import addon, addon_handle, TMDB_KEY
from resources.lib.utils import (
    _set_info,
    _url,
    _end,
    _fail,
    _norm,
    clean_title,
    format_size,
    parse_video_info,
    get_ssl_context,
    is_safe_match,
    format_stream_label,
    stream_passes_lang_filter,
    stream_list_sort_tuple,
    perf_start,
    perf_mark_items,
    perf_end,
)
from resources.lib.auth import _get_token
from resources.lib.local_db import _load_favorites, _load_watched
def _norm_prov_key(p):
    u = str(p or '').lower()
    if u in ('ws', 'webshare'):
        return 'webshare'
    if u in ('fs', 'fastshare'):
        return 'fastshare'
    return u


def _tokenize_vip_play_params(play_params):
    """
    Stejné pravidlo jako media_core._add_video_item: u stream_type VIP uloží
    ident (+ volitelnou url) do vip_vault a do URL pluginu pošle jen token vip:...
    aby se skutečný odkaz nedostal do kodi.log.
    """
    out = dict(play_params)
    if (out.get('stream_type') or '').strip().upper() != 'VIP':
        return out
    ident = out.get('ident')
    if not ident:
        return out
    try:
        from resources.lib.vip_vault import put as _vip_put
        token = _vip_put({
            'ident': ident,
            'provider': str(out.get('provider', '') or ''),
            'url': str(out.get('url', '') or ''),
        })
        if token:
            out['ident'] = token
            out.pop('url', None)
    except Exception as _e:
        xbmc.log('NEXASTREAM vip_vault: tokenize tvshows failed: %s' % _e, xbmc.LOGWARNING)
    return out


def toggle_autoplay_mode():
    """Přepne setting 'autoplay_mode' (0=Autoplay, 1=Složka s výběrem kvality) a obnoví seznam."""
    current = addon.getSetting('autoplay_mode')
    new_mode = '0' if current == '1' else '1'
    addon.setSetting('autoplay_mode', new_mode)
    label = 'Autoplay' if new_mode == '0' else 'Složka (výběr kvality)'
    try:
        xbmcgui.Dialog().notification(addon.getAddonInfo('name') or 'Addon', 'Režim kliknutí: %s' % label, xbmcgui.NOTIFICATION_INFO, 1500)
    except Exception:
        pass
    xbmc.executebuiltin('Container.Refresh')


def show_series_list(serial_title, serial_year='', serial_original_name='', tmdb_id='', num_seasons=0, is_kids='false'):
    perf_tag = 'tvshows.show_series_list'
    perf_start(perf_tag)
    xbmcplugin.setContent(addon_handle, 'tvshows')
    num_seasons = int(num_seasons) if num_seasons else 0

    if not (tmdb_id and num_seasons):
        orig, cz = serial_original_name or serial_title, serial_title
        for query in [orig, cz]:
            try:
                results = tmdb_api.search_tvshows(TMDB_KEY, query)
                if isinstance(results, tuple): results = results[0]
                if results:
                    best = results[0]
                    tmdb_id = best.get('tmdb_id', best.get('id', ''))
                    if tmdb_id:
                        det = tmdb_api.get_tvshow_details(TMDB_KEY, tmdb_id)
                        if det:
                            num_seasons = det.get('seasons', det.get('number_of_seasons', 0))
                            if det.get('orig_title'): serial_original_name = det['orig_title']
                if tmdb_id and num_seasons: break
            except: pass

    if tmdb_id and num_seasons: found_seasons = list(range(1, int(num_seasons) + 1))
    else:
        token = _get_token()
        if not token and not (addon.getSetting('fs_username') and addon.getSetting('fs_password')):
            return _fail('Pro detekci sezón bez TMDB zadejte WebShare nebo FastShare v nastavení.')
        found_set = set()
        search_queries = []
        if serial_original_name: search_queries.append('%s S01' % serial_original_name)
        if serial_title and _norm(serial_title) != _norm(serial_original_name or ''): search_queries.append('%s S01' % serial_title)
        prog = xbmcgui.DialogProgress()
        prog.create(addon.getAddonInfo('name') or 'Addon', 'Detekuji serie: %s' % serial_title)
        try:
            if token:
                for q in search_queries:
                    try:
                        for f in webshare._raw_search(token, q, limit=50):
                            if f.get('season'): found_set.add(f['season'])
                    except: pass
                max_s = max(found_set) if found_set else 0
                search_base = serial_original_name or serial_title
                for s in range(1, max_s + 3):
                    if s in found_set: continue
                    try:
                        for f in webshare._raw_search(token, '%s S%02d' % (search_base, s), limit=20):
                            if f.get('season'): found_set.add(f['season'])
                    except: pass
        finally: prog.close()
        found_seasons = sorted(found_set)

    if not found_seasons: found_seasons = [1]

    poster = ''
    if tmdb_id and TMDB_KEY:
        try:
            det = tmdb_api.get_tvshow_details(TMDB_KEY, tmdb_id)
            poster = det.get('poster', '') if det else ''
        except: pass

    season_data = {}
    if tmdb_id:
        try:
            ctx = get_ssl_context()
            url = f"https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={TMDB_KEY}&language=cs-CZ"
            with urllib.request.urlopen(url, context=ctx) as r:
                tmdb_info = json.loads(r.read().decode('utf-8'))
                for s_info in tmdb_info.get('seasons', []): season_data[s_info.get('season_number')] = s_info
        except: pass

    season_favs = _load_favorites().get('season', {})
    directory_items = []
    for s in found_seasons:
        s_info = season_data.get(s, {})
        s_name = s_info.get('name') or f'Série {s}'
        s_plot = s_info.get('overview') or f'Epizody pro {s_name} oblíbeného seriálu {serial_title}.'
        s_poster = 'https://image.tmdb.org/t/p/w500' + s_info['poster_path'] if s_info.get('poster_path') else poster
        li = xbmcgui.ListItem(f'[B]{s_name}[/B]')
        li.setArt({'thumb': s_poster, 'poster': s_poster, 'fanart': poster, 'icon': s_poster})
        _set_info(li, {'title': s_name, 'plot': s_plot, 'mediatype': 'season'})
        item_key, fav_title = f"{tmdb_id}_S{s}", f"{serial_original_name or serial_title}"
        if item_key in season_favs: li.addContextMenuItems([('Odebrat z oblíbených', 'RunPlugin(%s)' % _url(mode='remove_favorite', item_key=item_key, media_type='season'))])
        else: li.addContextMenuItems([('Přidat do oblíbených', 'RunPlugin(%s)' % _url(mode='add_favorite', tmdb_id=tmdb_id, title=fav_title, media_type='season', season=s, orig_title=serial_original_name))])
        folder_url = _url(mode='episodes', serial_title=serial_title, serial_original_name=serial_original_name, serial_year=serial_year, tmdb_id=tmdb_id, season=s, is_kids=is_kids)
        directory_items.append((folder_url, li, True))
    if directory_items:
        xbmcplugin.addDirectoryItems(addon_handle, directory_items)
        perf_mark_items(perf_tag, len(directory_items))
    perf_end(perf_tag, extra='http=tmdb+providers')
    _end()

def show_episodes(serial_title, season, serial_year='', serial_original_name='', tmdb_id='', is_kids='false', focus_episode='', resume_ident='', resume_time='', resume_total=''):
    perf_tag = 'tvshows.show_episodes'
    perf_start(perf_tag)
    xbmcplugin.setContent(addon_handle, 'episodes')
    season, token = int(season), _get_token()
    if not token and not (addon.getSetting('fs_username') and addon.getSetting('fs_password')):
        return _fail('Pro načtení epizod zadejte WebShare nebo FastShare v nastavení.')
    orig_name, cz_name, items, existing = serial_original_name or serial_title, serial_title, [], set()
    
    # Pokud tmdb_id chybí, zkusíme ho automaticky vyhledat HNED na začátku
    if not tmdb_id and TMDB_KEY:
        xbmc.log(f"NEXASTREAM: tmdb_id missing at start, attempting early auto-search for '{orig_name}' or '{cz_name}'", xbmc.LOGINFO)
        
        # Funkce pro přípravu vyhledávacích dotazů
        def prepare_search_queries(name):
            if not name:
                return []
            queries = []
            # Vyčistíme název
            cleaned = name.strip().rstrip('-').rstrip().strip()
            cleaned = ' '.join(cleaned.split())
            
            # Přidáme celý vyčištěný název
            if cleaned:
                queries.append(cleaned)
            
            # Pokud název obsahuje pomlčku, rozdělíme ho a zkusíme každou část
            if ' - ' in cleaned:
                parts = [p.strip() for p in cleaned.split(' - ') if p.strip()]
                queries.extend(parts)
            
            return queries
        
        # Vytvoříme seznam všech možných vyhledávacích dotazů
        all_queries = []
        all_queries.extend(prepare_search_queries(orig_name))
        all_queries.extend(prepare_search_queries(cz_name))
        
        # Odstraníme duplicity, ale zachováme pořadí
        seen = set()
        unique_queries = []
        for q in all_queries:
            if q and q not in seen:
                unique_queries.append(q)
                seen.add(q)
        
        # Zkusíme každý dotaz, dokud nenajdeme tmdb_id
        for clean_query in unique_queries:
            try:
                xbmc.log(f"NEXASTREAM: Searching TMDB for: '{clean_query}'", xbmc.LOGINFO)
                results = tmdb_api.search_tvshows(TMDB_KEY, clean_query)
                if isinstance(results, tuple):
                    results = results[0]
                if results:
                    best = results[0]
                    tmdb_id = str(best.get('tmdb_id', best.get('id', '')))
                    if tmdb_id:
                        xbmc.log(f"NEXASTREAM: Early auto-found tmdb_id={tmdb_id} for '{clean_query}'", xbmc.LOGINFO)
                        break
            except Exception as e:
                xbmc.log(f"NEXASTREAM: Early auto-search failed for '{clean_query}': {str(e)}", xbmc.LOGWARNING)
    
    vip_episodes = {}

    def _merge(new_items):
        for ni in new_items:
            if ni['ident'] not in existing: items.append(ni); existing.add(ni['ident'])

    prog = xbmcgui.DialogProgress()
    prog.create(addon.getAddonInfo('name') or 'Addon', 'Nacitam serie %d: %s' % (season, cz_name or orig_name))
    try:
        show_ws, show_fs = addon.getSetting('show_ws') != 'false', addon.getSetting('show_fs') != 'false'
        if show_ws and token:
            ws_results = webshare._raw_search(token, '%s S%02d' % (orig_name, season), limit=50)
            if cz_name and _norm(cz_name) != _norm(orig_name): ws_results.extend(webshare._raw_search(token, '%s S%02d' % (cz_name, season), limit=50))
            ws_results.extend(webshare._raw_search(token, orig_name, limit=150))
            if cz_name and _norm(cz_name) != _norm(orig_name): ws_results.extend(webshare._raw_search(token, cz_name, limit=150))
            for f in ws_results:
                f['provider'] = 'webshare'
                f.update(webshare.parse_filename(f['name']))
            _merge(ws_results)
        if show_fs:
            import fastshare
            fs_results = fastshare.smart_search(f"{cz_name} S{season:02d}", f"{orig_name} S{season:02d}" if orig_name else None)
            fs_results.extend(fastshare.smart_search(cz_name, orig_name))
            for f in fs_results:
                f.update(webshare.parse_filename(f['name']))
                f['size_str'] = format_size(f.get('size', 0))
                f['provider'] = 'fastshare'
            _merge(fs_results)
        if addon.getSetting('enable_hellspy') != 'false':
            try:
                from resources.lib.utils import search_hellspy_kodi
                hs_results = search_hellspy_kodi('%s S%02d' % (orig_name, season))
                if cz_name and _norm(cz_name) != _norm(orig_name):
                    hs_results.extend(search_hellspy_kodi('%s S%02d' % (cz_name, season)))
                unique_hs = []
                seen_hs_idents = set()
                for hsf in hs_results:
                    if hsf['ident'] not in seen_hs_idents:
                        seen_hs_idents.add(hsf['ident'])
                        unique_hs.append(hsf)
                for hsf in unique_hs:
                    hsf.update(webshare.parse_filename(hsf.get('name', '')))
                _merge(unique_hs)
            except Exception:
                pass
    except Exception as e: xbmc.log(f"NEXASTREAM EPISODES FETCH ERROR: {str(e)}", xbmc.LOGERROR)
    finally: prog.close()

    title_candidates = [x for x in (cz_name, orig_name) if x and str(x).strip()]
    if tmdb_id and TMDB_KEY:
        try:
            det = tmdb_api.get_tvshow_details(TMDB_KEY, str(tmdb_id))
            if det:
                for key in ('title', 'orig_title'):
                    v = det.get(key)
                    if v and str(v).strip():
                        title_candidates.append(str(v).strip())
                for at in det.get('alt_titles') or []:
                    s = str(at).strip()
                    if s:
                        title_candidates.append(s)
        except Exception as _e:
            xbmc.log('NEXASTREAM EPISODES: TMDB details for filter titles: %s' % _e, xbmc.LOGDEBUG)
    match_titles = _effective_series_match_titles(*title_candidates)
    if not match_titles:
        match_titles = [cz_name or orig_name or '']

    # TMDB sezóna před filtrem: čísla dílů a názvy potřebujeme pro WS/FS soubory bez SxxEyy v názvu
    ep_names, ep_plots, ep_stills, season_poster = {}, {}, {}, ''
    ep_directors, ep_casts = {}, {}
    season_ep_nums = frozenset()

    xbmc.log(f"NEXASTREAM: TMDB season prefetch for filter - tmdb_id={tmdb_id}, season={season}", xbmc.LOGINFO)
    if tmdb_id and TMDB_KEY:
        try:
            season_data = tmdb_api.get_tv_season(TMDB_KEY, tmdb_id, season)
            if season_data:
                season_poster = 'https://image.tmdb.org/t/p/w500' + season_data['poster_path'] if season_data.get('poster_path') else ''
                episodes_list = season_data.get('episodes') or []
                xbmc.log(f"NEXASTREAM: Loaded {len(episodes_list)} TMDB episodes for season {season} (before filter)", xbmc.LOGINFO)
                for ep in episodes_list:
                    n = ep.get('episode_number')
                    if n is not None:
                        ep_names[n] = ep.get('name', '')
                        ep_plots[n] = ep.get('overview', '')
                        ep_stills[n] = 'https://image.tmdb.org/t/p/w500' + ep['still_path'] if ep.get('still_path') else season_poster
                        crew = ep.get('crew', [])
                        ep_directors[n] = next((m.get('name') for m in crew if m.get('job') == 'Director'), '')
                        ep_casts[n] = [m.get('name', '') for m in ep.get('guest_stars', [])[:10]]
                season_ep_nums = frozenset(ep_names.keys())
            else:
                xbmc.log(f"NEXASTREAM: No season data from TMDB for tmdb_id={tmdb_id}, season={season}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"NEXASTREAM TMDB SEASON PREFETCH ERROR: {str(e)}", xbmc.LOGERROR)
    else:
        xbmc.log(f"NEXASTREAM: Skipping TMDB prefetch - tmdb_id={tmdb_id}, TMDB_KEY={'SET' if TMDB_KEY else 'NOT SET'}", xbmc.LOGWARNING)

    filtered = _filter_season(items, season, match_titles, season_ep_nums, ep_names)
    groups = _group_by_episode(filtered)
    for vip_ep_num in vip_episodes.keys():
        if vip_ep_num not in groups: groups[vip_ep_num] = []
    if not groups:
        return _fail('Zadne epizody pro: %s S%02d' % (cz_name, season))

    groups = _remap_orphans_by_tmdb_episode_titles(groups, ep_names)

    # Načtení historie sledování pro indikaci rozkoukání
    watched_data = _load_watched()
    episode_favs = _load_favorites().get('episode', {})

    # Rychlý přepínač režimu kliknutí (Autoplay / Složka s výběrem kvality)
    _ap_mode = addon.getSetting('autoplay_mode')
    if _ap_mode == '1':
        _mode_label = '[B]Režim kliknutí:[/B] [COLOR yellow]Složka (výběr kvality)[/COLOR]   [COLOR grey]›[/COLOR]   [I]přepnout na Autoplay[/I]'
    else:
        _mode_label = '[B]Režim kliknutí:[/B] [COLOR cyan]Autoplay[/COLOR]   [COLOR grey]›[/COLOR]   [I]přepnout na Složku[/I]'
    _toggle_li = xbmcgui.ListItem(_mode_label)
    _toggle_li.setArt({'icon': 'DefaultAddonProgram.png', 'thumb': 'DefaultAddonProgram.png'})
    _toggle_li.setProperty('IsPlayable', 'false')
    _set_info(_toggle_li, {'title': _mode_label, 'plot': 'Kliknutím přepneš výchozí akci při otevření dílu mezi automatickým přehráním a zobrazením složky s výběrem kvality. Nastavení je společné s hlavním přepínačem v Nastavení doplňku.', 'mediatype': 'video'})
    xbmcplugin.addDirectoryItem(addon_handle, _url(mode='toggle_autoplay_mode'), _toggle_li, False)
    perf_mark_items(perf_tag, 1)

    # Pinovaná položka "Pokračovat Sxx Exx" pokud je dostupná rozkoukaná epizoda pro focus_episode
    try:
        _focus_ep_num = int(focus_episode) if focus_episode not in (None, '', 0) else 0
    except (TypeError, ValueError):
        _focus_ep_num = 0
    _ap_mode = addon.getSetting('autoplay_mode')
    if _focus_ep_num:
        pinned_record = None
        pinned_ident = ''

        # Primarni cesta: resume_ident prisel v URL z Rozkoukanych -> pouzit rovnou,
        # bez jakehokoliv hledani (eliminuje zamenu za cizi serial se stejnym S/E).
        if resume_ident:
            _direct = watched_data.get(resume_ident)
            if _direct and _direct.get('media_type') == 'episode' and _direct.get('resume_time', 0) > 0 and _direct.get('playcount', 0) == 0:
                pinned_record = _direct
                pinned_ident = resume_ident

        # Fallback: resume_ident nebyl predan (stara URL) nebo zaznam v mezicase zmizel.
        # Scan pres watched_data s pridanym filtrem serialu, aby se nevybral cizi show.
        if pinned_record is None:
            _tmdb_str = str(tmdb_id) if tmdb_id else ''
            _cz_norm = _norm(cz_name) if cz_name else ''
            _orig_norm = _norm(orig_name) if orig_name else ''
            for _ident, _w in watched_data.items():
                if _w.get('media_type') != 'episode':
                    continue
                try:
                    if int(_w.get('season', 0) or 0) != season or int(_w.get('episode', 0) or 0) != _focus_ep_num:
                        continue
                except (TypeError, ValueError):
                    continue
                if _w.get('resume_time', 0) <= 0 or _w.get('playcount', 0) != 0:
                    continue
                # Filtr podle serialu, aby se nevybral cizi show se stejnym S/E
                _w_tmdb = str(_w.get('tmdb_id', '') or '')
                if _tmdb_str and _w_tmdb:
                    if _w_tmdb != _tmdb_str:
                        continue
                else:
                    _w_series = _norm(_w.get('series_title', '') or '')
                    if not _w_series:
                        # zaznam nema ani tmdb_id ani series_title -> nemuzeme bezpecne priradit
                        continue
                    _matches = False
                    for _cand in (_cz_norm, _orig_norm):
                        if not _cand:
                            continue
                        if _cand == _w_series or _cand in _w_series or _w_series in _cand:
                            _matches = True
                            break
                    if not _matches:
                        continue
                if pinned_record is None or _w.get('time', 0) > pinned_record.get('time', 0):
                    pinned_record = _w
                    pinned_ident = _ident

        if pinned_record:
            pinned_ep_name = ep_names.get(_focus_ep_num, '')
            pinned_ep_plot = ep_plots.get(_focus_ep_num, '')
            pinned_ep_still = ep_stills.get(_focus_ep_num, season_poster)
            pinned_label = ('[B][COLOR cyan]► Pokračovat[/COLOR][/B]  S%02dE%02d  %s  [COLOR cyan][Rozkoukané][/COLOR]' % (season, _focus_ep_num, pinned_ep_name)) if pinned_ep_name else ('[B][COLOR cyan]► Pokračovat[/COLOR][/B]  S%02dE%02d  [COLOR cyan][Rozkoukané][/COLOR]' % (season, _focus_ep_num))
            pinned_li = xbmcgui.ListItem(pinned_label)
            if pinned_ep_still:
                pinned_li.setArt({'thumb': pinned_ep_still, 'poster': season_poster, 'fanart': pinned_ep_still, 'icon': pinned_ep_still})
            _set_info(pinned_li, {
                'title': pinned_label,
                'season': season,
                'episode': _focus_ep_num,
                'plot': pinned_ep_plot or '',
                'mediatype': 'episode',
                'originaltitle': orig_name,
            })
            pinned_resume = int(pinned_record.get('resume_time', 0) or 0)
            pinned_total = int(pinned_record.get('total_time', 0) or 0)
            # Preferovat hodnoty predane v URL (jsou konzistentni s tim, co ukazuje Rozkoukane)
            try:
                _url_resume = int(resume_time) if resume_time not in (None, '', 0, '0') else 0
            except (TypeError, ValueError):
                _url_resume = 0
            try:
                _url_total = int(resume_total) if resume_total not in (None, '', 0, '0') else 0
            except (TypeError, ValueError):
                _url_total = 0
            if _url_resume > 0:
                pinned_resume = _url_resume
            if _url_total > 0:
                pinned_total = _url_total
            if pinned_resume > 0:
                pinned_li.setProperty('ResumeTime', str(pinned_resume))
            if pinned_total > 0:
                pinned_li.setProperty('TotalTime', str(pinned_total))
            pinned_li.setProperty('IsPlayable', 'true')

            pinned_provider = pinned_record.get('provider', '') or 'webshare'
            pinned_size = pinned_record.get('size', '') or ''
            pinned_raw_title = pinned_record.get('raw_title') or pinned_record.get('title') or ''

            autoplay_params = {
                'mode': 'play_from_here',
                'serial_title': cz_name,
                'season': season,
                'start_ep': _focus_ep_num,
                'serial_year': serial_year,
                'serial_original_name': orig_name,
                'tmdb_id': tmdb_id,
                'is_kids': is_kids,
                'resume_ident': pinned_ident,
                'resume_time': pinned_resume,
                'resume_total': pinned_total,
            }
            autoplay_pin_url = _url(**autoplay_params)

            direct_play_params = {
                'mode': 'play',
                'ident': pinned_ident,
                'title': pinned_raw_title or pinned_label,
                'media_type': 'episode',
                'size': pinned_size,
                'provider': pinned_provider,
                'is_kids': is_kids,
                'season': season,
                'episode': _focus_ep_num,
                'tmdb_id': tmdb_id,
                'stream_type': pinned_record.get('stream_type', ''),
            }
            if pinned_provider in ('HELLSPY', 'HL') and pinned_record.get('url'):
                direct_play_params['url'] = pinned_record.get('url')
            direct_play_url = _url(**direct_play_params)

            variants_pin_url = _url(
                mode='episode_variants',
                variants=json.dumps([{'name': v.get('name', ''), 'ident': v.get('ident', ''), 'size': v.get('size_str', ''), 'size_b': str(v.get('size', 0)), 'positive': str(v.get('positive', 0)), 'negative': str(v.get('negative', 0)), 'desc': v.get('desc', ''), 'provider': v.get('provider', 'webshare'), 'url': v.get('url', '')} for v in groups.get(_focus_ep_num, [])]),
                tmdb_id=tmdb_id,
                season=season,
                ep_num=_focus_ep_num,
                ep_name=pinned_ep_name,
                ep_plot=pinned_ep_plot,
                orig_title=orig_name,
                is_kids=is_kids,
                serial_title=(cz_name or orig_name or '').strip(),
            )

            if _ap_mode == '1':
                pin_primary_url = direct_play_url
                pin_is_folder = False
                pin_ctx = [
                    ('Přehrát vše odtud (Autoplay)', 'RunPlugin(%s)' % autoplay_pin_url),
                    ('Vybrat jinou kvalitu', 'Container.Update(%s)' % variants_pin_url),
                ]
            else:
                pin_primary_url = autoplay_pin_url
                pin_is_folder = False
                pinned_li.setProperty('IsPlayable', 'false')
                pin_ctx = [
                    ('Pokračovat bez autoplay', 'RunPlugin(%s)' % direct_play_url),
                    ('Vybrat jinou kvalitu', 'Container.Update(%s)' % variants_pin_url),
                ]
            pinned_li.addContextMenuItems(pin_ctx)
            xbmcplugin.addDirectoryItem(addon_handle, pin_primary_url, pinned_li, pin_is_folder)
            perf_mark_items(perf_tag, 1)

    directory_items = []
    for ep_num in sorted(groups.keys()):
        variants, ep_name, ep_plot, ep_still = groups[ep_num], ep_names.get(ep_num, ''), ep_plots.get(ep_num, ''), ep_stills.get(ep_num, season_poster)
        if ep_num == 999: folder_title = '[B]Nezařazeno / Komplet[/B]  [I](filmy, komplety, speciály)[/I]'
        elif ep_num > 10000000: folder_title = f'[B]Díl ze dne: {str(ep_num)[-2:]}.{str(ep_num)[-4:-2]}.{str(ep_num)[:4]}[/B]' + (f"  {ep_name}" if ep_name else "")
        else:
            ep_label = 'S%02dE%02d' % (season, ep_num)
            folder_title = ('[B]%s  %s[/B]' % (ep_label, ep_name) if ep_name else '[B]%s[/B]' % ep_label)
            
            # Přidání indikátorů
            indicators = ""
            if ep_num in vip_episodes: 
                indicators += "[COLOR gold][★] [/COLOR]"
            
            # Kontrola, zda je epizoda rozkoukána (má resume_time > 0 a není zhlédnutá)
            is_in_progress = False
            for variant in variants:
                ident = variant.get('ident', '')
                if ident in watched_data:
                    w_data = watched_data[ident]
                    if w_data.get('resume_time', 0) > 0 and w_data.get('playcount', 0) == 0:
                        is_in_progress = True
                        break
            
            if is_in_progress:
                indicators += "[COLOR cyan][Rozkoukané] [/COLOR]"
            
            folder_title = indicators + folder_title
            
        li = xbmcgui.ListItem(folder_title)
        if ep_still: li.setArt({'thumb': ep_still, 'poster': season_poster, 'fanart': ep_still, 'icon': ep_still})
        _set_info(li, {
            'title': ('S%02dE%02d - %s' % (season, ep_num, ep_name) if ep_name else 'S%02dE%02d' % (season, ep_num)) if ep_num < 999 else folder_title, 
            'season': season, 
            'episode': ep_num, 
            'plot': ep_plot or '', 
            'mediatype': 'episode', 
            'originaltitle': orig_name,
            'director': ep_directors.get(ep_num, ''),
            'cast': ep_casts.get(ep_num, [])
        })
        item_key, fav_title = f"{tmdb_id}_{season}_{ep_num}", f"{cz_name or orig_name} - S{season:02d}E{ep_num:02d}"
        autoplay_url = _url(mode='play_from_here', serial_title=cz_name, season=season, start_ep=ep_num, serial_year=serial_year, serial_original_name=orig_name, tmdb_id=tmdb_id, is_kids=is_kids)
        variants_url = _url(mode='episode_variants', variants=json.dumps([{'name': v['name'], 'ident': v['ident'], 'size': v.get('size_str', ''), 'size_b': str(v.get('size', 0)), 'positive': str(v.get('positive', 0)), 'negative': str(v.get('negative', 0)), 'desc': v.get('desc', ''), 'provider': v.get('provider', 'webshare'), 'url': v.get('url', '')} for v in variants]), tmdb_id=tmdb_id, season=season, ep_num=ep_num, ep_name=ep_name, ep_plot=ep_plot, orig_title=orig_name, is_kids=is_kids, serial_title=(cz_name or orig_name or '').strip())
        ctx_items, is_folder = [], False
        if _ap_mode == '1': primary_url, is_folder = variants_url, True; ctx_items.append(('Přehrát vše odtud (Autoplay)', 'RunPlugin(%s)' % autoplay_url))
        else: primary_url = autoplay_url; li.setProperty('IsPlayable', 'false'); ctx_items.append(('Vybrat jinou kvalitu', 'Container.Update(%s)' % variants_url))
        if item_key in episode_favs: ctx_items.append(('Odebrat z oblíbených', 'RunPlugin(%s)' % _url(mode='remove_favorite', item_key=item_key, media_type='episode')))
        else: ctx_items.append(('Přidat do oblíbených', 'RunPlugin(%s)' % _url(mode='add_favorite', tmdb_id=tmdb_id, title=fav_title, media_type='episode', season=season, episode=ep_num, orig_title=orig_name)))
        li.addContextMenuItems(ctx_items)
        directory_items.append((primary_url, li, is_folder))
    if directory_items:
        xbmcplugin.addDirectoryItems(addon_handle, directory_items)
        perf_mark_items(perf_tag, len(directory_items))
    perf_end(perf_tag, extra='http=providers+tmdb')
    _end()

def show_episode_variants(variants_json, season, ep_num, ep_name='', ep_plot='', orig_title='', tmdb_id='', is_kids='false', serial_title=''):
    xbmcplugin.setContent(addon_handle, 'episodes')
    season, ep_num = int(season), int(ep_num)
    show_label = (serial_title or orig_title or '').strip()
    approved_skip = set()
    watched_data = _load_watched()

    try: variants = json.loads(variants_json)
    except: variants = []

    variants = [v for v in variants if isinstance(v, dict)]
    for v in variants:
        sb = v.get('size_b')
        if sb is not None and str(sb).strip() != '':
            try:
                v['size'] = int(float(sb))
            except (TypeError, ValueError):
                pass
    variants = [v for v in variants if stream_passes_lang_filter(v)]
    variants.sort(key=stream_list_sort_tuple, reverse=True)
    for v in variants:
        if isinstance(v, dict):
            name = v.get('name', '')
            ident = v.get('ident', '')
            size = v.get('size', '')
            provider = v.get('provider', 'webshare')
            if (_norm_prov_key(provider), str(ident)) in approved_skip:
                continue

            # Detekce typu streamu (EARLY BRANCHING)
            stream_type = 'STANDARD'
            if v.get('stream_type') == 'AUTO_CACHED':
                stream_type = 'AUTO_CACHED'
            elif v.get('stream_type') == 'VIP' or "★" in name:
                stream_type = 'VIP'
            elif str(provider).upper() in ('HELLSPY', 'HL'):
                stream_type = 'HELLSPY'
            
            size_str = size
            if isinstance(size, int) and size > 0:
                size_str = format_size(size)
            elif isinstance(size, str) and size.isdigit() and int(size) > 100000:
                size_str = format_size(int(size))

            # Příprava dat pro univerzální formátovač
            stream_data = {
                'stream_type': stream_type,
                'name': name,
                'provider': provider,
                'size_str': size_str,
                'orig_title': orig_title,
                'tmdb_title': show_label,
                'plus': v.get('positive', 0),
                'minus': v.get('negative', 0)
            }
            if stream_type == 'AUTO_CACHED':
                stream_data['auto_meta'] = v.get('auto_meta') or {}
            
            # POUŽITÍ UNIVERZÁLNÍHO FORMÁTOVAČE
            formatted = format_stream_label(stream_data, context='episode')
            
            display_name = formatted['label']
            rich_plot = formatted['plot']
            if ep_plot: rich_plot += f"\n\n--- Popis epizody ---\n{ep_plot}"
            
            li = xbmcgui.ListItem(display_name)
            li.setProperty('IsPlayable', 'true')

            info = {'title': display_name, 'originaltitle': orig_title, 'season': season, 'episode': ep_num, 'plot': rich_plot, 'mediatype': 'episode'}
            
            w_data = watched_data.get(ident, {})
            if w_data:
                if w_data.get('playcount', 0) >= 1: info['playcount'] = 1
                elif w_data.get('resume_time', 0) > 0: li.setProperty('ResumeTime', str(w_data['resume_time']))
            _set_info(li, info)
            
            li.addContextMenuItems([
                ('Stáhnout na disk', 'RunPlugin(%s)' % _url(mode='download_file', ident=ident, title=name)),
                ('Označit jako Zhlédnuté', 'RunPlugin(%s)' % _url(mode='add_watched', ident=ident, title=name, size=size_str, media_type='episode')),
                ('Exportovat do knihovny (STRM)', 'RunPlugin(%s)' % _url(mode='export_strm', ident=ident, title=orig_title or name, media_type='episode', season=season, episode=ep_num))
            ])
            
            # Přidat URL parametr pro Hellspy streamy
            play_params = {
                'mode': 'play',
                'ident': ident,
                'title': name,
                'media_type': 'episode',
                'size': size_str,
                'provider': provider,
                'is_kids': is_kids,
                'stream_type': stream_type,
                'tmdb_id': str(tmdb_id),
                'season': str(season),
                'episode': str(ep_num),
            }

            # Pro Hellspy přidat kompletní URL s fileHash
            if provider in ['HELLSPY', 'HL'] and v.get('url'):
                play_params['url'] = v.get('url')

            play_params = _tokenize_vip_play_params(play_params)

            xbmcplugin.addDirectoryItem(addon_handle, _url(**play_params), li, False)
    _end()

def _effective_series_match_titles(*names):
    """
    Odstraní zkrácené / zdvojené varianty názvu seriálu pro filtrování souborů.
    Typicky TMDB cs: „Blue“ + original „Bluey“ — kratší je předpona delšího, nesmí sama propouštět Blue Bloods.
    """
    raw, seen_lower = [], set()
    for n in names:
        if not n:
            continue
        s = str(n).strip()
        if not s:
            continue
        lk = s.lower()
        if lk in seen_lower:
            continue
        seen_lower.add(lk)
        raw.append(s)
    if len(raw) <= 1:
        return raw

    def compact_norm(s):
        short = re.split(r'[:\-]', clean_title(s, remove_quality=False))[0].strip()
        return webshare._norm(short).replace(' ', '')

    comps = [(r, compact_norm(r)) for r in raw]
    kept = []
    for i, (orig_i, ni) in enumerate(comps):
        if not ni:
            continue
        skip = False
        for j, (orig_j, nj) in enumerate(comps):
            if i == j or not nj:
                continue
            if len(nj) <= len(ni):
                continue
            if nj.startswith(ni) or ni in nj:
                skip = True
                break
        if not skip:
            kept.append(orig_i)
    return kept if kept else raw


def _norm_filename_title_prefix(fn_raw):
    """Část názvu souboru před prvním SxxExx / rokem (jako u webshare._title_matches), z webshare._norm."""
    fn_spaced = webshare._norm(fn_raw)
    if not fn_spaced:
        return ''
    ep_m = re.search(r'\b[Ss]\d{1,2}[Ee]\d{1,2}\b|\b(19|20)\d{2}\b', fn_spaced)
    return fn_spaced[:ep_m.start()].strip() if ep_m else fn_spaced


def _norm_compacts_for_substring_gate(titles, min_len=5):
    """
    Slepené webshare._norm varianty všech názvů v match_titles (CZ + EN z TMDB).
    V souboru stačí jedna z nich — jinak by „Prasátko Peppa“ ořezalo uploady jen s „Peppa.Pig“.
    """
    out, seen = [], set()
    for t in titles or []:
        if not t:
            continue
        short = re.split(r'[:\-]', clean_title(str(t), remove_quality=False))[0].strip()
        short = re.sub(r'\s*\(\s*(19|20)\d{2}\s*\)\s*$', '', short, flags=re.I).strip()
        c = webshare._norm(short).replace(' ', '')
        if len(c) < min_len or c in seen:
            continue
        seen.add(c)
        out.append(c)
    return out


def _within_edit_distance_one(a, b):
    """Rychlá tolerance překlepu: max 1 vložení/smazání/záměna znaku."""
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la > lb:
        a, b = b, a
        la, lb = lb, la
    i = j = edits = 0
    while i < la and j < lb:
        if a[i] == b[j]:
            i += 1
            j += 1
            continue
        edits += 1
        if edits > 1:
            return False
        if la == lb:
            i += 1
            j += 1
        else:
            j += 1
    if j < lb or i < la:
        edits += 1
    return edits <= 1


def _contains_word_with_typo_tolerance(word, haystack_words):
    """Pro delší slova povolí malý překlep (1 edit), jinak exact match."""
    if word in haystack_words:
        return True
    if len(word) < 7:
        return False
    for hw in haystack_words:
        if abs(len(hw) - len(word)) > 1:
            continue
        if _within_edit_distance_one(word, hw):
            return True
    return False


def _passes_relaxed_series_gate(titles, filename):
    """
    Měkčí fallback gate pro případy, kdy je v názvu seriálu drobný překlep
    (např. dobrodruzsvi vs dobrodruzstvi), ale jinak sedí klíčová slova.
    """
    fn_words = [w for w in webshare._norm(filename).split() if len(w) > 2]
    if not fn_words:
        return False
    for t in titles or []:
        short_t = re.split(r'[:\-]', clean_title(str(t), remove_quality=False))[0].strip()
        t_words = [w for w in webshare._norm(short_t).split() if len(w) > 3]
        if len(t_words) < 2:
            continue
        hits = sum(1 for w in t_words if _contains_word_with_typo_tolerance(w, fn_words))
        # Musí sedět většina názvu, minimálně dvě klíčová slova.
        needed = max(2, int(round(len(t_words) * 0.6)))
        if hits >= needed:
            return True
    return False


def _episode_from_num_dash_title(name):
    """
    Epizoda ve tvaru „08 - Název“ (číslo 1–99, pomlčka/tečka, pak text).
    Typické u uploadů bez SxxEyy; používá se hlavně u sezóny 1 (viz _filter_season).
    """
    n, _t = _num_dash_episode_and_title_tail(name)
    return n


def _num_dash_episode_and_title_tail(name):
    """
    Vrátí (číslo dílu 1–99, text za „NN - “) nebo (None, None).
    Příponu a případné tagy v hranatých závorkách na konci tail ořeže.
    """
    if not name:
        return None, None
    s = re.sub(r'\.(?:avi|mkv|mp4|ts|m4v|wmv|flv|webm)\s*$', '', str(name), flags=re.I)
    m = re.search(r'(?:^|[\s\-–.])([1-9]\d?|0[1-9])(?:\s*[-–.]\s*|\s+)(.+)$', s)
    if not m:
        return None, None
    if webshare._episode_match_is_iso_date_day(s, m):
        return None, None
    v = int(m.group(1))
    if not (1 <= v <= 99):
        return None, None
    tail = m.group(2).strip()
    tail = re.sub(r'\s*[\[\(].*$', '', tail).strip()
    return v, (tail or None)


def _episode_tail_matches_tmdb(tail_str, ep_title):
    """Shoda textu za pomlčkou s TMDB názvem epizody (normalizace, podřetězce / slova)."""
    if not tail_str or not ep_title:
        return False
    t_ep = webshare._norm(str(ep_title).strip())
    t_tail = webshare._norm(str(tail_str).strip())
    if not t_ep or not t_tail:
        return False
    c_ep = re.sub(r'[^a-z0-9]', '', t_ep)
    c_tail = re.sub(r'[^a-z0-9]', '', t_tail)
    if len(c_tail) < 3:
        return False
    if c_tail in c_ep or c_ep in c_tail:
        return True
    w_ep = set(w for w in t_ep.split() if len(w) > 2)
    w_tail = [w for w in t_tail.split() if len(w) > 2]
    if len(w_tail) >= 2:
        return w_ep and all(w in w_ep for w in w_tail)
    if len(w_tail) == 1:
        w = w_tail[0]
        return w in w_ep or (len(w) >= 5 and w in c_ep)
    return len(c_tail) >= 6 and c_tail in c_ep


def _passes_episode_anchor_gate(name, season_ep_nums, ep_names):
    """
    TOP kotva: v názvu je „NN - název dílu“ a obojí sedí s TMDB pro tuto sezónu.
    Obchází gate/basic_match na celý seriál (např. soubor jen „Smolikovi 08 - …“
    vs dlouhý oficiální název v katalogu).
    """
    if not season_ep_nums or not ep_names:
        return False
    nd, tail = _num_dash_episode_and_title_tail(name)
    if nd is None or nd not in season_ep_nums or not tail:
        return False
    c_tail = re.sub(r'[^a-z0-9]', '', webshare._norm(tail))
    if len(c_tail) < 4:
        return False
    ep_t = (ep_names.get(nd) or '').strip()
    if not ep_t:
        return False
    return _episode_tail_matches_tmdb(tail, ep_t)


def _ep_title_match_rules(ep_names):
    """Pravidla pro shodu TMDB názvu epizody s názvem souboru (subs / víceslovné)."""
    subs, word_rules = [], []
    if not ep_names:
        return subs, word_rules
    for ep_num, raw in ep_names.items():
        if raw is None or ep_num is None:
            continue
        t = webshare._norm(str(raw).strip())
        if not t:
            continue
        ct = re.sub(r'[^a-z0-9]', '', t)
        words = [w for w in t.split() if len(w) > 3]
        if len(ct) >= 8:
            subs.append((ep_num, ct))
        elif len(words) >= 2:
            word_rules.append((ep_num, words))
    subs.sort(key=lambda x: -len(x[1]))
    word_rules.sort(key=lambda x: (-len(x[1]), -sum(len(w) for w in x[1])))
    return subs, word_rules


def _first_ep_num_from_title_rules(name, subs, word_rules):
    if not name:
        return None
    cf = re.sub(r'[^a-z0-9]', '', webshare._norm(str(name)))
    fn_words = set(webshare._norm(str(name)).split())
    for ep_num, ct in subs:
        if ct and ct in cf:
            return ep_num
    for ep_num, words in word_rules:
        if words and all(w in fn_words for w in words):
            return ep_num
    return None


def _explicit_conflicting_season_tag(name, target_season):
    """True, pokud název explicitně ukazuje na jinou sezónu než target_season."""
    m = re.search(r'(?i)[Ss](\d{1,2})[Ee]\d', str(name))
    if m and int(m.group(1)) != int(target_season):
        return True
    m = re.search(r'(?i)\b(\d{1,2})[xX]\d{1,4}\b', str(name))
    if m and int(m.group(1)) != int(target_season):
        return True
    return False


_PACK_HINT = re.compile(
    r'\b(?:komplet|complete|kolekce|collection|pack|box\s*set)\b|'
    r'(?:^|\s)\d{1,2}\s*[-–]\s*\d{1,2}(?:\s*[-–]\s*\d{1,2})*\s*(?:díl|dil|ep\.?|epizod)|'
    r'\b(?:všech|vsech|all)\s*\d+\s*(?:díl|dil|ep)|'
    r'\bsez[oó]n(?:y|a|)\s*\d{1,2}\s*[-–]\s*\d{1,2}\b',
    re.IGNORECASE
)


def _looks_like_season_pack(name):
    """Souhrnné nahrávky / více dílů v jednom souboru — nebrat jen podle čísla dílu z parseru."""
    return bool(_PACK_HINT.search(str(name or '')))


def _tmdb_infer_season_ok(name, target_season, season_ep_nums, subs, word_rules, ep_names=None):
    """
    Soubor bez Sxx v názvu může patřit do prohlížené sezóny, pokud TMDB sedí.

    Největší jistota: „08 - Název dílu“ kde číslo je díl v této sezóně a název odpovídá
    TMDB epizodě stejného čísla. Samotné číslo bez smysluplného názvu bere jen pokud
    TMDB název pro díl nemáme.
    """
    if not season_ep_nums:
        return False
    if _explicit_conflicting_season_tag(name, target_season):
        return False
    ep_names = ep_names or {}
    nd, tail = _num_dash_episode_and_title_tail(name)
    if nd is not None:
        if nd not in season_ep_nums:
            return False
        c_tail = re.sub(r'[^a-z0-9]', '', webshare._norm(tail)) if tail else ''
        meaningful_tail = len(c_tail) >= 4
        ep_t = (ep_names.get(nd) or '').strip()
        if meaningful_tail and ep_t:
            return _episode_tail_matches_tmdb(tail, ep_t)
        return True
    hit = _first_ep_num_from_title_rules(name, subs, word_rules)
    return hit is not None and hit in season_ep_nums


def _remap_orphans_by_tmdb_episode_titles(groups, ep_names):
    """
    Soubory v bucketu 999 (nezařazené) zkusí zařadit pod číslo epizody podle TMDB názvu,
    pokud je celý normalizovaný název epizody obsažen v názvu souboru (silná shoda).

    Kratší víceslovné názvy: všechna významná slova (>3 znaky) musí být v názvu souboru.
    """
    orphans = groups.get(999)
    if not orphans or not ep_names:
        return groups
    subs, word_rules = _ep_title_match_rules(ep_names)
    remaining = []
    for f in orphans:
        name = f.get('name', '')
        hit = None
        nd, tail = _num_dash_episode_and_title_tail(name)
        if nd is not None and tail and ep_names:
            ep_t = (ep_names.get(nd) or '').strip()
            if ep_t and _episode_tail_matches_tmdb(tail, ep_t):
                hit = nd
        if hit is None:
            hit = _first_ep_num_from_title_rules(name, subs, word_rules)
        if hit is not None:
            groups.setdefault(hit, []).append(f)
        else:
            remaining.append(f)
    groups[999] = remaining
    for ep_key in groups:
        if ep_key == 999:
            continue
        groups[ep_key] = [x for x in groups[ep_key] if isinstance(x, dict)]
        groups[ep_key].sort(key=lambda x: (x.get('quality_rank', 99), -x.get('size', 0)))
    return groups


def _filter_season(files, season, match_titles, season_ep_nums=None, ep_names=None):
    res = []
    titles = [t for t in (match_titles or []) if t and str(t).strip()]
    if not titles:
        return res
    season_ep_nums = season_ep_nums or frozenset()
    subs, word_rules = _ep_title_match_rules(ep_names or {})

    def basic_match(t, fn):
        if not t:
            return False
        short_t = re.split(r'[:\-]', clean_title(t, remove_quality=False))[0].strip()
        t_spaced = webshare._norm(short_t)
        fn_spaced = webshare._norm(fn)
        if not t_spaced:
            return False
        words = [w for w in t_spaced.split() if w]
        # Jedno slovo: nejdřív přísné _title_matches; \b jen v PREFIXU před SxxExx (ne v celém řetězci — „Blue on Blue“ za epizodou)
        if len(words) == 1:
            w = words[0]
            if webshare._title_matches(t, fn):
                return True
            if len(w) < 5:
                return False
            title_prefix = _norm_filename_title_prefix(fn)
            if title_prefix and re.search(r'\b' + re.escape(w) + r'\b', title_prefix):
                return True
            return False
        t_compact, fn_compact = t_spaced.replace(' ', ''), fn_spaced.replace(' ', '')
        if t_compact and t_compact in fn_compact:
            return True
        t_words = [w for w in t_spaced.split() if len(w) > 3]
        fn_words = [w for w in fn_spaced.split() if len(w) > 2]
        if len(t_words) >= 3 and fn_words:
            fuzzy_hits = sum(1 for w in t_words if _contains_word_with_typo_tolerance(w, fn_words))
            if fuzzy_hits >= max(2, int(round(len(t_words) * 0.75))):
                return True
        return webshare._title_matches(t, fn)

    gate_slugs = _norm_compacts_for_substring_gate(titles, min_len=5)
    for f in files:
        name = f['name']
        fn_c = webshare._norm(name).replace(' ', '')
        _anchor = _passes_episode_anchor_gate(name, season_ep_nums, ep_names or {})
        # Tvrdá pojistka: v názvu souboru musí být aspoň jedna z variant (CZ i EN), ne jen nejdelší — Peppa vs Prasátko Peppa
        if gate_slugs and not any(slug in fn_c for slug in gate_slugs):
            if not _passes_relaxed_series_gate(titles, name) and not _anchor:
                continue
        if not any(basic_match(t, name) for t in titles) and not _anchor:
            continue
        fs, fe, season_ok = f.get('season'), f.get('episode'), False
        if fs is not None:
            if fs == season and fe is not None: season_ok = True
        else:
            m = re.search(r'(?i)[Ss](\d{1,2})[Ee]\d{1,4}', name)
            if m:
                if int(m.group(1)) == season: season_ok = True
            else:
                m = re.search(r'\b(\d{1,2})[xX](\d{2,4})\b', name)
                if m:
                    if int(m.group(1)) == season: season_ok = True
        if not season_ok:
            if (season == 1 and not re.search(r'(?i)[Ss](?:0*[2-9]|[1-9]\d+)[Ee]', name) and not re.search(r'(?i)\b(?:0*[2-9]|[1-9]\d+)[xX]\d+', name)) or re.search(r'\b(?:19|20)\d{2}[-._]?\d{2}[-._]?\d{2}\b', name): season_ok = True
            elif season == 1 and _episode_from_num_dash_title(name) is not None:
                season_ok = True
            elif _tmdb_infer_season_ok(name, season, season_ep_nums, subs, word_rules, ep_names):
                season_ok = True
            elif (
                fs is None
                and fe is not None
                and int(fe) in season_ep_nums
                and not _explicit_conflicting_season_tag(name, season)
                and not _looks_like_season_pack(name)
            ):
                # Parser (vč. WebShare) už přiřadil díl; TMDB tail match nemusí sedět (diakritika, zkratky).
                season_ok = True
        if season_ok: res.append(f)
    return res

def _group_by_episode(files):
    groups = {}
    for f in files:
        ep = f.get('episode')
        if ep is None:
            clean_name = re.sub(r'(?i)\b(264|265|720|1080|2160|480|576|5\.1|2\.0|7\.1|4k)\b', '', f.get('name', ''))
            m = re.search(r'(?i)[Ss]\d{1,2}[Ee](\d{1,4})', clean_name)
            if m: ep = int(m.group(1))
            else:
                m = re.search(r'\b\d{1,2}[xX](\d{2,4})\b', clean_name)
                if m: ep = int(m.group(1))
                else:
                    m_date = re.search(r'\b((?:19|20)\d{2})[-._]?(\d{2})[-._]?(\d{2})\b', clean_name)
                    if m_date: ep = int(m_date.group(1) + m_date.group(2) + m_date.group(3))
                    else:
                        ep_nd = _episode_from_num_dash_title(clean_name)
                        if ep_nd is not None:
                            ep = ep_nd
                        else:
                            m = re.search(r'(?i)[\[\(](\d{1,3})[\]\)]|\b(?:ep|díl|cast|část)\s*(\d{1,3})\b|\b(\d{1,3})\.\s*(?:díl|cast|část|ep|epizoda)\b|\b(\d{1,3})\.\s*[A-Za-z]|\s+-\s*(\d{1,3})\s*(?:-|\b)|\b(\d{1,3})\s*\.(?:avi|mkv|mp4|ts)\b', clean_name)
                            ep = int(m.group(1) or m.group(2) or m.group(3) or m.group(4) or m.group(5) or m.group(6)) if m else 999
        groups.setdefault(int(ep), []).append(f)
    for ep in groups:
        groups[ep] = [x for x in groups[ep] if isinstance(x, dict)]
        groups[ep].sort(key=lambda x: (x.get('quality_rank', 99), -x.get('size', 0)))
    return groups

def _extract_keyword(title):
    words = [w for w in re.split(r'\W+', title) if len(w) > 3]
    return max(words, key=len) if words else ''

