# -*- coding: utf-8 -*-
import json
import re
import time
import unicodedata
import xbmc
import xbmcgui
import xbmcplugin
import ssl
from resources.lib.config import addon, addon_handle, addon_url, QUALITY_PATTERN

try:
    from urllib.parse import urlencode, parse_qsl
except ImportError:
    from urllib import urlencode
    from urlparse import parse_qsl

_PERF_STATE = {}

def perf_start(tag):
    """Safe performance marker start (no-op when disabled)."""
    if not tag:
        return
    _PERF_STATE[tag] = {'start': time.time(), 'first': None, 'count': 0}

def perf_mark_items(tag, count):
    """Safe performance marker item counter."""
    state = _PERF_STATE.get(tag)
    if not state:
        return
    try:
        c = int(count or 0)
    except Exception:
        c = 0
    if c <= 0:
        return
    if state['first'] is None:
        state['first'] = time.time()
    state['count'] += c

def perf_end(tag, extra=None):
    """Safe performance marker end + log summary."""
    state = _PERF_STATE.pop(tag, None)
    if not state:
        return
    total = time.time() - state['start']
    first = (state['first'] - state['start']) if state['first'] else -1.0
    suffix = f" {extra}" if extra else ""
    xbmc.log(
        f"NEXASTREAM PERF END {tag} total={total:.3f}s first_item={first:.3f}s items={state.get('count', 0)}{suffix}",
        xbmc.LOGINFO,
    )

def vip_safe(value, is_vip, placeholder='[VIP]'):
    """
    Ochrana pred unikem VIP identu/URL do kodi.log.

    Pokud je is_vip True, vrati placeholder, jinak puvodni hodnotu.
    Helper se pouziva v *.py souborech pro vsechny xbmc.log() zpravy, ktere by
    jinak mohly obsahovat citlivou VIP hodnotu (ident, URL, stream link).
    """
    try:
        return placeholder if is_vip else value
    except Exception:
        return placeholder if is_vip else value

def _norm(s):
    """Odstraní diakritiku a převede na malá písmena."""
    try:
        if isinstance(s, bytes): s = s.decode('utf-8')
        n = unicodedata.normalize('NFD', s)
        return u''.join(c for c in n if unicodedata.category(c) != 'Mn').lower().strip()
    except:
        return (s or '').lower().strip()

def clean_title(text, remove_quality=True):
    """
    Vyčistí název od barevných tagů, VIP hvězdiček, [Q], [WS/FS] 
    a volitelně i od technických značek kvality.
    """
    if not text: return ""
    # Odstranění barevných tagů [COLOR...][/COLOR], [B], [I] atd.
    res = re.sub(r'\[/?(?:COLOR|B|I|UPPERCASE)[^\]]*\]', '', text, flags=re.I)
    # Odstranění systémových předpon
    res = re.sub(r'^(?:TREZOR:|VIP:|★|>>|\[Q\]|\[WS\]|\[FS\])\s*', '', res, flags=re.I).strip()
    # Odstranění velikosti v hranatých závorkách na konci (např. [2.5 GB])
    res = re.sub(r'\s*\[\d+(?:\.\d+)?\s*(?:GB|MB)\]$', '', res, flags=re.I)
    
    if remove_quality:
        # Odstranění technických tagů (1080p, HEVC, atd.) definovaných v configu
        res = re.sub(QUALITY_PATTERN, '', res, flags=re.I)
    
    # Odstranění vícenásobných mezer a teček/podtržítek na koncích
    res = re.sub(r'\s+', ' ', res).replace('[]', '').strip(' ._-')
    return res

def format_size(size_bytes):
    """Převede bajty na čitelný formát GB nebo MB."""
    try:
        b = float(size_bytes)
        if b <= 0: return ""
        if b >= 1073741824: return '%.1f GB' % (b / 1073741824.0)
        return '%.0f MB' % (b / 1048576.0)
    except:
        return ""

def parse_size_str(text):
    """
    Inverze format_size: řetězec typu "4.2 GB", "512 MB", "1,5 GB", "900M"
    převede zpět na bajty. Vrací 0, pokud nelze rozparsovat.
    """
    if not text:
        return 0
    try:
        s = str(text).strip().replace(',', '.')
    except Exception:
        return 0
    if not s:
        return 0
    m = re.search(r'([0-9]+(?:\.[0-9]+)?)\s*([KMGT]?)\s*([Bb]?)', s, flags=re.I)
    if not m:
        return 0
    try:
        num = float(m.group(1))
    except (TypeError, ValueError):
        return 0
    unit = (m.group(2) or '').upper()
    mult = {
        '':  1024 * 1024,           # holé číslo bereme jako MB (časté v UI)
        'K': 1024,
        'M': 1024 * 1024,
        'G': 1024 * 1024 * 1024,
        'T': 1024 * 1024 * 1024 * 1024,
    }.get(unit, 1024 * 1024)
    return int(num * mult)

def is_safe_match(filename, official_title):
    """
    Bezpečně ověří, zda název souboru odpovídá oficiálnímu názvu.
    Chrání před záměnou (např. 'Počátek' vs 'Texaský masakr motorovou pilou: Počátek').
    """
    if not filename or not official_title: return False
    
    def normalize(t):
        t = _norm(t) # Odstraní diakritiku a dá na malá
        return re.sub(r'[^a-z0-9]', '', t)
    
    f_norm = normalize(filename)
    o_norm = normalize(official_title)
    
    if not o_norm: return False
    
    # Pokud normalizovaný oficiální název v souboru vůbec není, končíme
    if o_norm not in f_norm: return False
    
    # Ochrana proti "motorové pile": 
    # Pokud je název souboru po normalizaci o moc delší než oficiální název, 
    # mohlo by jít o jiný film, který má dané slovo v názvu.
    # Povolujeme rezervu (např. 15 znaků) pro rok, kvalitu atd.
    if len(f_norm) > (len(o_norm) + 25): 
        # Ještě zkusíme, zda tam není rok filmu, to by zvýšilo důvěru
        year_match = re.search(r'\b(19|20)\d{2}\b', filename)
        if not year_match: return False
        
    return True

def parse_video_info(name, size_str="", plus=0, minus=0, return_dict=False):
    """
    Analyzuje název souboru a vrací strukturovaný text pro 'plot' v Kodi nebo slovník dat.
    Centralizuje logiku detekce rozlišení, kodeků a jazyků.
    """
    n_up = str(name).upper().replace('_', '.').replace('-', '.')
    v_res, v_lang, v_codec, v_audio = [], [], [], []
    v_source = []
    l_tag = ""
    res_colored = ""
    
    # Rozlišení s barvami
    if any(x in n_up for x in ['2160P', '4K', 'UHD']): 
        res_label = '4K'
        v_res.append('4K Ultra HD')
        res_colored = "[COLOR crimson]4K[/COLOR]"
    elif any(x in n_up for x in ['1080P', 'FHD']): 
        res_label = '1080p'
        v_res.append('1080p Full HD')
        res_colored = "[COLOR deepskyblue]1080p[/COLOR]"
    elif any(x in n_up for x in ['720P', 'HD']): 
        res_label = '720p'
        v_res.append('720p HD')
        res_colored = "[COLOR lime]720p[/COLOR]"
    else: 
        res_label = ''
        v_res.append('SD / Neznámé')
        res_colored = ""
    
    # Jazyky a Titulky
    is_cz = re.search(r'\b(?:CZ|CS|CZE|CZDAB|DABING|DAB)\b', n_up)
    is_sk = re.search(r'\b(?:SK|SVK)\b', n_up)
    is_tit = re.search(r'\b(?:TIT|CZtit|CS.TIT|TITULKY|SUBS|SUB)\b', n_up)

    if is_cz: v_lang.append('CZ')
    if is_sk: v_lang.append('SK')
    if re.search(r'\b(?:EN|ENG)\b', n_up): v_lang.append('EN')
    
    # Určení primárního tagu pro label [CZ] / [SK] / [CZtit]
    if is_cz: 
        l_tag = "[COLOR lime][CZ][/COLOR]" if not is_tit else "[COLOR orange][CZtit][/COLOR]"
    elif is_sk:
        l_tag = "[COLOR lime][SK][/COLOR]"
    elif is_tit:
        l_tag = "[COLOR orange][CZtit][/COLOR]"

    # Kodeky
    if any(x in n_up for x in ['HEVC', 'H265', 'X265']): v_codec.append('HEVC')
    elif any(x in n_up for x in ['H264', 'X264', 'AVC']): v_codec.append('H.264')
    elif 'XVID' in n_up or 'DIVX' in n_up: v_codec.append('XviD')
    
    # HDR
    if 'HDR' in n_up: v_codec.append('HDR')
    if 'DV' in n_up or 'DOLBY.VISION' in n_up: v_codec.append('DV')

    # Zdroj
    if 'REMUX' in n_up: v_source.append('Remux')
    elif 'BLURAY' in n_up or 'BDrip' in n_up.lower(): v_source.append('BluRay')
    elif 'WEB' in n_up: v_source.append('WEB-DL')
    
    # Zvuk
    if '5.1' in n_up: v_audio.append('5.1')
    elif '7.1' in n_up: v_audio.append('7.1')
    elif 'ATMOS' in n_up: v_audio.append('Atmos')
    
    # Sestavení doplňkového labelu (pro název v seznamu za svislítkem)
    label_parts = []
    if res_colored: label_parts.append(res_colored)
    # if v_audio: label_parts.append(v_audio[0])
    
    # Pokud chceme slovník (pro pokročilé skládání labelu jinde)
    if return_dict:
        return {
            'res': res_label,
            'res_colored': res_colored,
            'langs': v_lang,
            'codecs': v_codec,
            'source': v_source,
            'audio': v_audio,
            'lang_tag': l_tag,
            'meta': " | ".join(label_parts)
        }

    # Skládání textu pro PLOT
    plot = ""
    if size_str: plot += "Velikost: %s" % size_str
    if plus or minus: plot += "  |  + %s  - %s" % (plus, minus)
    plot += "\nVideo: %s | %s" % (", ".join(v_res), ", ".join(v_codec) if v_codec else "Neznámý kodek")
    if v_lang: plot += "\nJazyk: %s" % ", ".join(v_lang)
    if v_audio: plot += "\nZvuk: %s" % ", ".join(v_audio)
    if re.search(r'\b(?:TIT|SUB|SUBS)\b', n_up): plot += "\nObsahuje titulky"
    plot += "\n\nPůvodní soubor:\n%s" % name
    return plot


def normalize_api_lang(raw):
    """Mapuje text z API (lang) na kód CZ/SK/EN nebo None."""
    if raw is None:
        return None
    u = str(raw).strip().upper()
    if not u:
        return None
    if u in ('CZ', 'CZE', 'CS', 'CES', 'CZDAB'):
        return 'CZ'
    if u in ('SK', 'SVK', 'SLK'):
        return 'SK'
    if u in ('EN', 'ENG'):
        return 'EN'
    return None


def detected_stream_langs(f_dict):
    """
    Jazyky odvozené z názvu souboru (parse_video_info) a z pole lang u VIP/API.
    Vrací seřazený seznam unikátních kódů CZ/SK/EN.
    """
    seen, out = set(), []
    name = ''
    if isinstance(f_dict, dict):
        name = f_dict.get('name') or f_dict.get('title') or ''
    elif f_dict:
        name = str(f_dict)
    if name:
        for c in (parse_video_info(name, return_dict=True).get('langs') or []):
            if c not in seen:
                seen.add(c)
                out.append(c)
    if isinstance(f_dict, dict):
        api = normalize_api_lang(f_dict.get('lang'))
        if api and api not in seen:
            seen.add(api)
            out.append(api)
    return out


def addon_preferred_lang_code():
    """Kód CZ/SK/EN podle nastavení doplňku, nebo None = bez preference."""
    try:
        idx = int(addon.getSetting('preferred_audio_lang') or 0)
    except (TypeError, ValueError):
        idx = 0
    return {1: 'CZ', 2: 'SK', 3: 'EN'}.get(idx)


def stream_language_rank_for_addon(f_dict):
    """
    Číslo pro řazení: vyšší = lepší shoda s preferencí.
    Bez preference vrací 1 pro všechny (řadí se pak hlavně podle velikosti).
    """
    pref = addon_preferred_lang_code()
    if not pref:
        return 1
    langs = detected_stream_langs(f_dict if isinstance(f_dict, dict) else {'name': f_dict})
    if not langs:
        return 1
    if pref in langs:
        return 2
    return 0


def stream_passes_lang_filter(f_dict):
    """Při režimu skrývání: ponechat nejasné (bez značky jazyka), odfiltrovat jednoznačně „cizí“."""
    try:
        mode = int(addon.getSetting('preferred_lang_list_mode') or 0)
    except (TypeError, ValueError):
        mode = 0
    if mode != 1:
        return True
    pref = addon_preferred_lang_code()
    if not pref:
        return True
    langs = detected_stream_langs(f_dict if isinstance(f_dict, dict) else {'name': f_dict})
    if not langs:
        return True
    return pref in langs


def movie_file_sort_tuple(f_dict):
    """Řazení výsledků filmu: approved, jazyk, velikost (sestupně)."""
    appr = 1 if (isinstance(f_dict, dict) and f_dict.get('is_approved')) else 0
    rank = stream_language_rank_for_addon(f_dict)
    try:
        size = int(f_dict.get('size', 0) or 0) if isinstance(f_dict, dict) else 0
    except (TypeError, ValueError):
        size = 0
    return appr, rank, size


def stream_list_sort_tuple(v_dict):
    """Řazení variant (film/epizoda) podle jazyku a velikosti."""
    rank = stream_language_rank_for_addon(v_dict if isinstance(v_dict, dict) else {'name': v_dict})
    sb = 0
    if isinstance(v_dict, dict):
        raw_b = v_dict.get('size_b')
        if raw_b not in (None, ''):
            try:
                sb = int(raw_b)
            except (TypeError, ValueError):
                pass
        if not sb and v_dict.get('size') is not None:
            try:
                sb = int(v_dict['size'])
            except (TypeError, ValueError):
                try:
                    sb = int(re.sub(r'[^0-9]', '', str(v_dict.get('size', '0'))))
                except (TypeError, ValueError):
                    sb = 0
    return rank, sb


def _pref_lang_targets(pref_idx):
    """Vrací (iso_ok frozenset, name_needles tuple) nebo None při bez preference."""
    pref_idx = str(pref_idx or '0')
    if pref_idx == '0':
        return None
    iso_ok = {
        '1': frozenset(('ces', 'cze', 'cs')),
        '2': frozenset(('slk', 'slo', 'sk')),
        '3': frozenset(('eng', 'en')),
    }.get(pref_idx)
    name_needles = {
        '1': ('czech', 'cestina', 'cesky', 'cesko'),
        '2': ('slovak', 'slovencina', 'slovensky'),
        '3': ('english', 'anglictina', 'anglicky'),
    }.get(pref_idx, ())
    if not iso_ok:
        return None
    return iso_ok, name_needles


def apply_preferred_audio_stream(player):
    """
    Po startu přehrávání zvolí audio stopu podle preferred_audio_lang.
    Kodi často uvádí ISO 639-2 (ces, slk, eng); kontrolujeme i název stopy.
    """
    targets = _pref_lang_targets(addon.getSetting('preferred_audio_lang'))
    if not targets:
        return
    iso_ok, name_needles = targets

    def _stream_matches(st):
        if st is None:
            return False
        if isinstance(st, dict):
            lang = (st.get('language') or '').strip().lower()
            name = (st.get('name') or '').lower()
        else:
            lang = str(st).strip().lower()
            name = ''
        if lang and lang.split('-')[0] in iso_ok:
            return True
        blob = _norm('%s %s' % (lang, name))
        for nd in name_needles:
            if _norm(nd) in blob:
                return True
        return False

    def _pick_index_python_api():
        if not hasattr(player, 'getAvailableAudioStreams'):
            return None
        try:
            streams = player.getAvailableAudioStreams()
        except Exception:
            return None
        if not streams:
            return None
        for i, st in enumerate(streams):
            if _stream_matches(st):
                return i
        return None

    def _pick_index_json_rpc():
        try:
            import json as _json
            raw = xbmc.executeJSONRPC(
                _json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetActivePlayers', 'params': {}})
            )
            act = _json.loads(raw).get('result') or []
            pid = None
            for p in act:
                if p.get('type') == 'video':
                    pid = p.get('playerid')
                    break
            if pid is None:
                return None
            raw2 = xbmc.executeJSONRPC(
                _json.dumps(
                    {
                        'jsonrpc': '2.0',
                        'id': 2,
                        'method': 'Player.GetProperties',
                        'params': {'playerid': pid, 'properties': ['audiostreams']},
                    }
                )
            )
            streams = (_json.loads(raw2).get('result') or {}).get('audiostreams') or []
            for st in streams:
                if _stream_matches(st):
                    try:
                        return int(st.get('index', 0))
                    except (TypeError, ValueError):
                        return st.get('index')
        except Exception as e:
            xbmc.log('NEXASTREAM apply_preferred_audio_stream RPC: %s' % e, xbmc.LOGDEBUG)
        return None

    idx = _pick_index_python_api()
    if idx is None:
        idx = _pick_index_json_rpc()
    if idx is None:
        return
    try:
        if hasattr(player, 'setAudioStream'):
            player.setAudioStream(idx)
            xbmc.log('NEXASTREAM: audio stopa nastavena na index %s (preferovaný jazyk)' % idx, xbmc.LOGDEBUG)
            return
    except Exception as e:
        xbmc.log('NEXASTREAM setAudioStream: %s' % e, xbmc.LOGWARNING)
    try:
        import json as _json
        raw = xbmc.executeJSONRPC(
            _json.dumps({'jsonrpc': '2.0', 'id': 3, 'method': 'Player.GetActivePlayers', 'params': {}})
        )
        act = _json.loads(raw).get('result') or []
        pid = next((p.get('playerid') for p in act if p.get('type') == 'video'), None)
        if pid is None:
            return
        xbmc.executeJSONRPC(
            _json.dumps(
                {
                    'jsonrpc': '2.0',
                    'id': 4,
                    'method': 'Player.SetAudioStream',
                    'params': {'playerid': pid, 'stream': idx},
                }
            )
        )
    except Exception as e2:
        xbmc.log('NEXASTREAM SetAudioStream RPC fallback: %s' % e2, xbmc.LOGDEBUG)


def _deactivate_video_subtitles(player):
    """Skryje titulky (čeština / slovenština zvuku = titulky nejsou potřeba)."""
    try:
        if hasattr(player, 'showSubtitles'):
            player.showSubtitles(False)
    except Exception as e:
        xbmc.log('NEXASTREAM showSubtitles(False): %s' % e, xbmc.LOGDEBUG)
    try:
        import json as _json
        raw = xbmc.executeJSONRPC(
            _json.dumps({'jsonrpc': '2.0', 'id': 20, 'method': 'Player.GetActivePlayers', 'params': {}})
        )
        act = _json.loads(raw).get('result') or []
        pid = next((p.get('playerid') for p in act if p.get('type') == 'video'), None)
        if pid is None:
            return
        xbmc.executeJSONRPC(
            _json.dumps(
                {
                    'jsonrpc': '2.0',
                    'id': 21,
                    'method': 'Player.SetSubtitle',
                    'params': {'playerid': pid, 'subtitle': 'off'},
                }
            )
        )
    except Exception as e2:
        xbmc.log('NEXASTREAM SetSubtitle off: %s' % e2, xbmc.LOGDEBUG)


def _is_subtitle_off_row(st):
    """Řádek „bez titulků“ v seznamu stopy Kodi."""
    if isinstance(st, dict):
        blob = _norm('%s %s' % (st.get('name') or '', st.get('language') or ''))
    else:
        blob = _norm(str(st))
    if not blob:
        return False
    for m in ('disable', 'vypnut', 'vyp.'):
        if m in blob:
            return True
    if blob.strip() in ('off', 'nic', 'none', 'no'):
        return True
    return False


def apply_preferred_subtitle_stream(player):
    """
    preferred_subtitle_mode=1:
    - preferovaný zvuk CZ nebo SK → titulky vypnout;
    - jiný preferovaný zvuk (např. EN) → titulky zapnout vždy: nejdřív stejný jazyk,
      jinak první dostupná stopa (kromě „vypnuto“).
    """
    try:
        sub_mode = int(addon.getSetting('preferred_subtitle_mode') or 0)
    except (TypeError, ValueError):
        sub_mode = 0
    if sub_mode != 1:
        return
    pref_audio = str(addon.getSetting('preferred_audio_lang') or '0')
    if pref_audio in ('1', '2'):
        _deactivate_video_subtitles(player)
        return
    targets = _pref_lang_targets(pref_audio)
    if not targets:
        return
    iso_ok, name_needles = targets

    def _sub_matches(st):
        if st is None:
            return False
        if isinstance(st, dict):
            lang = (st.get('language') or '').strip().lower()
            name = (st.get('name') or '').lower()
        else:
            lang = str(st).strip().lower()
            name = ''
        if lang and lang.split('-')[0] in iso_ok:
            return True
        blob = _norm('%s %s' % (lang, name))
        for nd in name_needles:
            if _norm(nd) in blob:
                return True
        return False

    def _pick_sub_index_python():
        if not hasattr(player, 'getAvailableSubtitleStreams'):
            return None
        try:
            streams = player.getAvailableSubtitleStreams()
        except Exception:
            return None
        if not streams:
            return None
        for i, st in enumerate(streams):
            if _sub_matches(st):
                return i
        return None

    def _pick_sub_index_rpc():
        try:
            import json as _json
            raw = xbmc.executeJSONRPC(
                _json.dumps({'jsonrpc': '2.0', 'id': 11, 'method': 'Player.GetActivePlayers', 'params': {}})
            )
            act = _json.loads(raw).get('result') or []
            pid = next((p.get('playerid') for p in act if p.get('type') == 'video'), None)
            if pid is None:
                return None
            raw2 = xbmc.executeJSONRPC(
                _json.dumps(
                    {
                        'jsonrpc': '2.0',
                        'id': 12,
                        'method': 'Player.GetProperties',
                        'params': {'playerid': pid, 'properties': ['subtitles']},
                    }
                )
            )
            streams = (_json.loads(raw2).get('result') or {}).get('subtitles') or []
            for st in streams:
                if _sub_matches(st):
                    try:
                        return int(st.get('index', 0))
                    except (TypeError, ValueError):
                        return st.get('index')
        except Exception as e:
            xbmc.log('NEXASTREAM apply_preferred_subtitle_stream RPC: %s' % e, xbmc.LOGDEBUG)
        return None

    def _pick_first_usable_sub_python():
        if not hasattr(player, 'getAvailableSubtitleStreams'):
            return None
        try:
            streams = player.getAvailableSubtitleStreams()
        except Exception:
            return None
        for i, st in enumerate(streams or []):
            if _is_subtitle_off_row(st):
                continue
            return i
        return None

    def _pick_first_usable_sub_rpc():
        try:
            import json as _json
            raw = xbmc.executeJSONRPC(
                _json.dumps({'jsonrpc': '2.0', 'id': 16, 'method': 'Player.GetActivePlayers', 'params': {}})
            )
            act = _json.loads(raw).get('result') or []
            pid = next((p.get('playerid') for p in act if p.get('type') == 'video'), None)
            if pid is None:
                return None
            raw2 = xbmc.executeJSONRPC(
                _json.dumps(
                    {
                        'jsonrpc': '2.0',
                        'id': 17,
                        'method': 'Player.GetProperties',
                        'params': {'playerid': pid, 'properties': ['subtitles']},
                    }
                )
            )
            streams = (_json.loads(raw2).get('result') or {}).get('subtitles') or []
            for st in streams:
                if _is_subtitle_off_row(st):
                    continue
                try:
                    return int(st.get('index', 0))
                except (TypeError, ValueError):
                    return st.get('index')
        except Exception as e:
            xbmc.log('NEXASTREAM first subtitle RPC: %s' % e, xbmc.LOGDEBUG)
        return None

    idx = _pick_sub_index_python()
    if idx is None:
        idx = _pick_sub_index_rpc()
    if idx is None:
        idx = _pick_first_usable_sub_python()
    if idx is None:
        idx = _pick_first_usable_sub_rpc()
    if idx is None:
        return
    try:
        if hasattr(player, 'setSubtitleStream'):
            player.setSubtitleStream(idx)
        if hasattr(player, 'showSubtitles'):
            player.showSubtitles(True)
        xbmc.log('NEXASTREAM: titulky nastaveny na index %s (preferovaný jazyk)' % idx, xbmc.LOGDEBUG)
        return
    except Exception as e:
        xbmc.log('NEXASTREAM setSubtitleStream: %s' % e, xbmc.LOGWARNING)
    try:
        import json as _json
        raw = xbmc.executeJSONRPC(
            _json.dumps({'jsonrpc': '2.0', 'id': 13, 'method': 'Player.GetActivePlayers', 'params': {}})
        )
        act = _json.loads(raw).get('result') or []
        pid = next((p.get('playerid') for p in act if p.get('type') == 'video'), None)
        if pid is None:
            return
        xbmc.executeJSONRPC(
            _json.dumps(
                {
                    'jsonrpc': '2.0',
                    'id': 14,
                    'method': 'Player.SetSubtitleStream',
                    'params': {'playerid': pid, 'stream': idx},
                }
            )
        )
    except Exception as e2:
        xbmc.log('NEXASTREAM SetSubtitleStream RPC fallback: %s' % e2, xbmc.LOGDEBUG)


def get_ssl_context():
    """Vrací SSL kontext se systémovým ověřením certifikátu (TLS verify ON)."""
    try:
        return ssl.create_default_context()
    except AttributeError:
        try:
            return ssl._create_default_https_context()
        except AttributeError:
            return None

def _url(**kw):
    """Generuje URL pro plugin s automatickým zachováním parametrů (např. is_kids)."""
    import urllib.parse
    safe = {}
    for k, v in kw.items():
        if v is None: v = ''
        if isinstance(v, (list, dict)): v = json.dumps(v, ensure_ascii=False)
        safe[str(k)] = str(v)
        
    try:
        import sys
        current_params = dict(parse_qsl(sys.argv[2][1:]))
        if current_params.get('is_kids') == 'true' and 'is_kids' not in safe:
            safe['is_kids'] = 'true'
    except: pass
    
    return addon_url + '?' + urlencode(safe)

def _set_info(li, info, is_folder=False):
    """Nastaví metadata pro ListItem v Kodi (Video Info Tag)."""
    
    # OPRAVA: Varování "Metadata TMDB nebyla nalezena" bylo odstraněno.
    # Uživatel uvidí pouze dostupná data bez rušivých varování.
    # Pokud není popis, zůstane prázdný. Pokud je validní popis z TMDB nebo technické info, zobrazí se bez varování.

    safe_info = {}
    try:
        # setInfo v Kodi očekává jen jednoduché typy; složitější struktury (dict/list dict)
        # způsobují TypeError „Failed to convert input type…“.
        for key in (
            'title', 'originaltitle', 'plot', 'tagline', 'genre', 'director',
            'year', 'playcount', 'season', 'episode', 'mediatype'
        ):
            val = info.get(key)
            if val is None:
                continue
            if key in ('year', 'playcount', 'season', 'episode'):
                try:
                    safe_info[key] = int(val)
                except Exception:
                    continue
            elif key in ('genre', 'director'):
                if isinstance(val, (list, tuple)):
                    safe_info[key] = [str(x) for x in val if x is not None]
                else:
                    safe_info[key] = [str(val)]
            else:
                safe_info[key] = str(val)
    except Exception:
        safe_info = {}

    # 1) Primární cesta: kompatibilní setInfo se sanitizovanými daty.
    try:
        if safe_info:
            li.setInfo('video', safe_info)
    except Exception as e:
        xbmc.log('NEXASTREAM _set_info setInfo failed: %s' % e, xbmc.LOGWARNING)

    # 2) Doplňkově zkusit moderní InfoTagVideo API, ale jen když konkrétní metoda existuje.
    try:
        tag = li.getVideoInfoTag()
        setters = [
            ('title', 'setTitle'),
            ('originaltitle', 'setOriginalTitle'),
            ('plot', 'setPlot'),
            ('tagline', 'setTagLine'),
            ('year', 'setYear'),
            ('playcount', 'setPlaycount'),
            ('season', 'setSeason'),
            ('episode', 'setEpisode'),
            ('mediatype', 'setMediaType'),
        ]
        for key, method_name in setters:
            val = safe_info.get(key)
            if val in (None, ''):
                continue
            setter = getattr(tag, method_name, None)
            if callable(setter):
                try:
                    setter(val)
                except Exception:
                    pass

        genres = safe_info.get('genre') or []
        if genres:
            set_genres = getattr(tag, 'setGenres', None)
            if callable(set_genres):
                try:
                    set_genres(genres)
                except Exception:
                    pass

        directors = safe_info.get('director') or []
        if directors:
            set_directors = getattr(tag, 'setDirectors', None)
            if callable(set_directors):
                try:
                    set_directors(directors)
                except Exception:
                    pass
    except Exception:
        pass

def _notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=3000):
    try:
        title = addon.getAddonInfo('name') or 'StreamCatalog'
    except Exception:
        title = 'StreamCatalog'
    xbmcgui.Dialog().notification(title, msg, icon, ms)

def _add_dir(name, url, img='DefaultFolder.png', fanart='', plot='', is_folder=True):
    li = xbmcgui.ListItem(name)
    art = {'icon': img, 'thumb': img}
    if fanart:
        art['fanart'] = fanart
        li.setProperty('fanart_image', fanart)
    li.setArt(art)
    if plot:
        try: li.getVideoInfoTag().setPlot(plot)
        except: li.setInfo('video', {'plot': plot})
    if not is_folder:
        li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, is_folder)

def _end(update_listing=False):
    xbmcplugin.endOfDirectory(addon_handle, updateListing=update_listing)

def _fail(msg=''):
    if msg: _notify(msg, xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

def search_hellspy_kodi(query):
    """Provede vyhledávání na Hellspy.to přes API jako Stremio a vrátí seznam výsledků."""
    import urllib.request
    import json
    try:
        q = urllib.parse.quote(query)
        url = f"https://api.hellspy.to/gw/search?query={q}&offset=0&limit=64"
        ctx = get_ssl_context()
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
        with urllib.request.urlopen(req, timeout=10, context=ctx) as r:
            data = json.loads(r.read().decode('utf-8'))
            
        results = []
        items = data.get('items', [])
        for item in items:
            if item.get('objectType') == 'GWSearchVideo':
                ident = str(item.get('id', ''))
                fileHash = item.get('fileHash', '')
                if not ident or not fileHash: continue
                name = item.get('title', 'Neznamy nazev')
                size = item.get('size', 0)
                
                size_str = ""
                if size > 0:
                    if size >= 1073741824: size_str = f"{round(size / 1073741824.0, 2)} GB"
                    else: size_str = f"{round(size / 1048576.0, 0)} MB"
                
                dl_url = f"hellspy_stream:{ident}:{fileHash}"
                
                # Import proveden az zde, aby nedoslo k cyklicke zavislosti pri spousteni
                from resources.lib.utils import parse_video_info
                
                results.append({
                    'ident': ident,
                    'name': name,
                    'size': size,
                    'size_str': size_str,
                    'provider': 'HELLSPY',
                    'url': dl_url,
                    'plot': parse_video_info(name, size_str),
                    'fileHash': fileHash
                })
        return results
    except Exception as e:
        xbmc.log(f"HELLSPY SEARCH ERROR: {e}", xbmc.LOGERROR)
        return []

def resolve_hellspy(url, is_vip=False):
    """Získá reálný odkaz na stream z Hellspy.to API.

    `is_vip` pouze potlacuje logovani citlivych hodnot (vlastni HTTP logika se nemeni).
    """
    import urllib.request
    import json
    try:
        if not url.startswith('hellspy_stream:'): return url
        
        parts = url.split(':')
        if len(parts) < 3: return None
        
        ident = parts[1]
        fileHash = parts[2]
        
        api_url = f"https://api.hellspy.to/gw/video/{ident}/{fileHash}"
        ctx = get_ssl_context()
        req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
        
        with urllib.request.urlopen(req, timeout=10, context=ctx) as r:
            data = json.loads(r.read().decode('utf-8'))
            
        conversions = data.get('conversions', {})
        download_url = data.get('download', '')
        
        # Preferujeme nejvyšší kvalitu
        resolutions = []
        for q, link in conversions.items():
            try: resolutions.append((int(q), link))
            except: pass
            
        if resolutions:
            resolutions.sort(reverse=True)
            return resolutions[0][1]
            
        if download_url:
            return download_url
            
        return None
    except Exception as e:
        xbmc.log(f"HELLSPY RESOLVE ERROR: {e}", xbmc.LOGERROR)
        return None

# ============================================================================
# UNIVERZÁLNÍ FORMÁTOVAČ STREAMŮ (Early Branching Pattern)
# ============================================================================

def format_stream_label(stream_data, context='movie'):
    """
    Univerzální formátovač pro všechny typy streamů.
    Zajišťuje konzistenci s admin panelem (upload.php, queue.php).
    
    Výstupní formát: [IKONA] [ZDROJ] [VELIKOST] [JAZYK] NÁZEV | KVALITA | ZVUK
    
    Args:
        stream_data: dict s klíči:
            - stream_type: 'VIP' | 'APPROVED' | 'STANDARD' | 'HELLSPY'
            - name: název souboru
            - provider: 'webshare' | 'fastshare' | 'WS' | 'FS'
            - size_str: velikost (např. "2.5 GB")
            - info_str: čistý popis (jen u VIP, např. "1080p HEVC CZ")
            - quality_label: label (jen u APPROVED, např. "[1080p | CZ | DD5.1] Název")
            - real_title: oficiální název (volitelné)
            - orig_title: originální název pro bezpečné nahrazení
            - year: rok (volitelné)
            - season, episode: pro seriály
            - plus, minus: hodnocení (volitelné)
        context: 'movie' | 'episode'
    
    Returns:
        dict: {
            'label': formátovaný label pro zobrazení,
            'plot': popis pro info panel,
            'clean_title': vyčištěný název pro interní použití
        }
    """
    stream_type = stream_data.get('stream_type', 'STANDARD')
    
    # EARLY BRANCHING - detekce typu zdroje
    if stream_type == 'VIP':
        result = _format_vip_stream(stream_data, context)
    elif stream_type == 'APPROVED':
        result = _format_approved_stream(stream_data, context)
    elif stream_type == 'AUTO_CACHED':
        result = _format_auto_cached_stream(stream_data, context)
    elif stream_type == 'HELLSPY':
        result = _format_hellspy_stream(stream_data, context)
    else:
        result = _format_standard_stream(stream_data, context)

    # Varování o překročení uživatelského stropu velikosti.
    # Bezpečnostní pojistka: u VIP NIKDY nezobrazovat, i kdyby warning omylem
    # byl ve stream_data.
    warning = stream_data.get('warning')
    if warning and stream_type != 'VIP':
        result['label'] = '%s %s' % (warning, result.get('label', ''))
        plot = result.get('plot', '') or ''
        # V plotu použijeme delší vysvětlení, v labelu jen ikonu.
        result['plot'] = ('[COLOR red][!] Soubor je větší než tvůj nastavený limit '
                          '– může se sekat.[/COLOR]\n\n%s' % plot).strip()

    return result


def _nexa_split_lang_tokens(s):
    """Rozdělí řetězec jazyků (CZ, EN / SK+EN) na jednotlivé kódy."""
    if not s:
        return []
    s = s.upper().strip()
    parts = re.split(r'[,;/|+]+', s.replace(' ', ''))
    return [p for p in parts if p and len(p) <= 8]


def _nexa_langs_from_audio_tracks(txt):
    """Z řetězce typu 'CZ 5.1 AC3 / EN 7.1 TRUEHD' vytáhne jazykové kódy."""
    if not txt:
        return []
    out = []
    for seg in re.split(r'\s*/\s*', txt):
        seg = seg.strip()
        if not seg:
            continue
        m = re.match(r'^([A-Z]{2,3})\b', seg, re.I)
        if m:
            out.append(m.group(1).upper())
    return out


def _nexa_compact_audio_langs(meta):
    """Kompaktní seznam jazyků zvuku, např. CZ/EN — sloučí langs + stopy ve zvuku."""
    if not meta:
        return ''
    langs_raw = (meta.get('langs') or '').strip()
    codes = _nexa_split_lang_tokens(langs_raw) if langs_raw else []
    tracks = _nexa_langs_from_audio_tracks(meta.get('audio_tracks') or '')
    seen = set()
    ordered = []
    for c in codes + tracks:
        u = c.upper()
        if u not in seen:
            seen.add(u)
            ordered.append(u)
    return '/'.join(ordered)


def _nexa_compact_subs_langs(meta):
    """Kompaktní seznam jazyků titulků, např. CZ/EN."""
    if not meta:
        return ''
    subs_raw = (meta.get('subs') or '').strip().upper()
    if not subs_raw:
        return ''
    parts = _nexa_split_lang_tokens(subs_raw.replace('+', ','))
    seen = set()
    ordered = []
    for p in parts:
        if p not in seen:
            seen.add(p)
            ordered.append(p)
    return '/'.join(ordered)


def _nexa_hdr_summary(meta):
    """Krátký popis HDR / barevného profilu z meta (techs, suggested_label, resolution)."""
    if not meta:
        return ''
    blob = ' '.join([
        meta.get('techs') or '',
        meta.get('suggested_label') or '',
        meta.get('resolution') or '',
    ]).upper()
    labels = []
    if re.search(r'\bDV\b|DOLBY\s*VISION|DOVI', blob):
        labels.append('Dolby Vision')
    if 'HDR10+' in blob.replace(' ', '') or 'HDR10PLUS' in blob.replace(' ', ''):
        labels.append('HDR10+')
    elif 'HDR10' in blob:
        labels.append('HDR10')
    if 'HLG' in blob and 'HDR10+' not in ''.join(labels):
        labels.append('HLG')
    if 'HDR' in blob and not any('HDR' in x for x in labels):
        labels.append('HDR')
    return ' · '.join(labels) if labels else ''


def _nexa_video_codec_from_techs(techs):
    if not techs:
        return ''
    u = techs.upper()
    if 'AV1' in u:
        return 'AV1'
    if 'HEVC' in u or 'H265' in u or 'H.265' in u:
        return 'HEVC'
    if 'AVC' in u or 'H264' in u or 'H.264' in u or 'X264' in u:
        return 'H.264'
    return ''


def _nexa_plot_audio_lang_line(meta, fallback_single=''):
    """
    Jedna řádka do plotu: buď Jazyk: X nebo Jazyky zvuku: X / Y.
    fallback_single — původní jednojazyčný label (např. CZ tit), když nelze parsovat více.
    """
    compact = _nexa_compact_audio_langs(meta)
    if not compact:
        if fallback_single:
            return 'Jazyk: %s' % fallback_single
        return None
    parts = [p.strip() for p in compact.split('/') if p.strip()]
    if len(parts) > 1:
        return 'Jazyky zvuku: ' + ' / '.join(parts)
    return 'Jazyk: ' + parts[0]


def nexa_sidebar_attach(stream_data, plot):
    """
    Tagline + vlastnosti ListItem pro postranní panel / skin (nexa.*).
    Plot už má strukturované řádky z _format_* — zde jen krátká linka a props.
    """
    st = stream_data.get('stream_type')
    if st not in ('APPROVED', 'AUTO_CACHED'):
        return {'plot': plot, 'tagline': '', 'properties': {}}
    meta = stream_data.get('auto_meta') or {}
    langs = _nexa_compact_audio_langs(meta)
    subs = _nexa_compact_subs_langs(meta)
    hdr = _nexa_hdr_summary(meta)
    vcodec = _nexa_video_codec_from_techs(meta.get('techs') or '')

    parts = []
    if langs:
        parts.append('Zvuk ' + langs)
    if subs and (not langs or subs != langs):
        parts.append('Titulky ' + subs)
    if hdr:
        parts.append(hdr)
    if vcodec:
        parts.append(vcodec)
    tagline = ' · '.join(parts) if parts else ''

    props = {}
    if langs:
        props['nexa.audio.langs'] = langs
    if subs:
        props['nexa.subs.langs'] = subs
    if hdr:
        props['nexa.hdr'] = hdr
    if vcodec:
        props['nexa.video.codec'] = vcodec
    size_str = (stream_data.get('size_str') or '').strip()
    if size_str and size_str != '---':
        props['nexa.size'] = size_str

    return {'plot': plot, 'tagline': tagline, 'properties': props}


def _format_vip_stream(data, context):
    """
    Formátování VIP (Trezor ★) streamů - čistá data z API.
    Formát: [★] [WS] [4.5 GB] [EN] [TIT: CZ] Název | 1080p | DD5.1
    """
    # Provider tag
    provider = str(data.get('provider', 'WS')).upper()
    if provider == 'WEBSHARE': provider = 'WS'
    elif provider == 'FASTSHARE': provider = 'FS'
    
    p_color = 'deepskyblue' if provider == 'FS' else 'lime'
    p_tag = f"[COLOR {p_color}][{provider}][/COLOR]"
    
    # Velikost
    size_str = data.get('size_str', '')
    size_tag = f"[COLOR gold][{size_str}][/COLOR]" if size_str and size_str != '---' else ""
    
    # Čtení samostatných sloupců z API (quality, audio, lang)
    quality = str(data.get('quality', '1080p')).strip()
    audio = str(data.get('audio', 'Stereo')).strip()
    lang = str(data.get('lang', 'CZ')).strip().upper()
    
    # Normalizace kvality (odstranění 'p' pokud je přítomno)
    if quality.upper().endswith('P'):
        quality = quality[:-1] + 'p'
    
    # Jazykový tag
    lang_tag = f"[COLOR lime][{lang}][/COLOR]" if lang else ""

    subs = str(data.get('subs', '')).strip().upper()
    lang_u = lang.upper()
    audio_is_cz_sk = 'CZ' in lang_u or 'SK' in lang_u
    tit_tag = ""
    if subs and not audio_is_cz_sk:
        tit_tag = f"[COLOR orange][TIT: {subs}][/COLOR]"
    
    # Název
    if context == 'episode':
        season = int(data.get('season', 0))
        episode = int(data.get('episode', 0))
        base_title = data.get('real_title', '')
        show_name = (data.get('show_title') or '').strip()
        epn = (data.get('episode_name') or '').strip()
        if season > 0 and episode > 0:
            if show_name and epn:
                title = f"{show_name} · E{episode:02d} · {epn}"
            else:
                title = f"{base_title} S{season:02d}E{episode:02d}" if base_title else f"S{season:02d}E{episode:02d}"
        else:
            title = base_title or show_name or ''
    else:
        title = data.get('real_title', '')
    
    # Sestavení hlavního labelu: [★] [WS] [4.5 GB] [EN] [TIT: CZ] Název
    parts = ["[COLOR gold][★][/COLOR]", p_tag]
    if size_tag: parts.append(size_tag)
    if lang_tag: parts.append(lang_tag)
    if tit_tag: parts.append(tit_tag)
    parts.append(f"[COLOR gold]{title}[/COLOR]")
    
    label = " ".join(parts)
    
    # Metadata za svislítko s barevným formátováním kvality: | 1080p | DD5.1
    meta_parts = []
    if quality:
        # Barevné formátování podle kvality
        q_upper = quality.upper()
        if '4K' in q_upper or '2160' in q_upper:
            meta_parts.append(f"[COLOR crimson]{quality}[/COLOR]")
        elif '1080' in q_upper:
            meta_parts.append(f"[COLOR deepskyblue]{quality}[/COLOR]")
        elif '720' in q_upper:
            meta_parts.append(f"[COLOR lime]{quality}[/COLOR]")
        else:
            meta_parts.append(quality)
    
    if audio: meta_parts.append(audio)

    if meta_parts:
        label += " | " + " | ".join(meta_parts)
    
    # Plot BEZ "Původní soubor:" (jak bylo požadováno)
    plot_parts = []
    if size_str and size_str != '---': plot_parts.append(f"Velikost: {size_str}")
    if quality: plot_parts.append(f"Kvalita: {quality}")
    if lang: plot_parts.append(f"Jazyk: {lang}")
    if audio: plot_parts.append(f"Zvuk: {audio}")
    if subs: plot_parts.append(f"Titulky: {subs}")
    
    plot = "\n".join(plot_parts)
    plot += "\n\n★ VIP Trezor stream - Ověřená kvalita"
    
    return {
        'label': label,
        'plot': plot,
        'clean_title': title
    }

def _format_approved_stream(data, context):
    """
    Formátování APPROVED ([Q]) streamů.

    Pořadí (stejné jako [A] auto-cached, pouze jiné prefix/barvy):
       [Q] [PROVIDER] [SIZE] [LANG] NÁZEV | RESOLUTION | AUDIO | TIT: SUBS

    [Q] je fuchsia (admin explicitně schválil → vyšší důvěra než [A]).
    NÁZEV je gold (stejně jako VIP) – vizuálně oddělí schválené obsah od STANDARD.

    Datové zdroje (v pořadí spolehlivosti):
      1) data['auto_meta'] – čerstvě dotažené z nexa_stream_meta (viz api.php list_streams)
      2) data['quality_label'] – legacy fallback (JSON:{...} nebo prostý "[SIZE] Název")
      3) data['tmdb_title'] / orig_title / year – pro čistý název
    """
    provider = str(data.get('provider', 'webshare')).upper()
    if provider == 'WEBSHARE': provider = 'WS'
    elif provider == 'FASTSHARE': provider = 'FS'
    p_color = 'deepskyblue' if provider == 'FS' else 'lime'
    p_tag = f"[COLOR {p_color}][{provider}][/COLOR]"

    meta = data.get('auto_meta') or {}

    # 1) Název filmu – preferuj TMDB title (vždy čistý), fallback quality_label
    tmdb_title = (data.get('tmdb_title') or '').strip()
    orig_title = data.get('orig_title', '')
    year = data.get('year', '')
    quality_label_raw = data.get('quality_label') or ''

    # Historické záznamy mohou mít v quality_label COLOR tagy (double-render bug).
    # Vystřihneme je a zbavíme se tím původní chyby.
    import re as _re
    quality_label_clean = _re.sub(r'\[/?COLOR[^\]]*\]', '', quality_label_raw).strip()

    # Novější auto-scan ukládá label jako "JSON:{"t":"...","y":"..."}" → parse
    # Seriály (auto_scan_series): JSON může obsahovat "s","ep" místo season v API.
    parsed_json_title = ''
    parsed_json_year = ''
    parsed_json_s = 0
    parsed_json_ep = 0
    if quality_label_clean.startswith('JSON:'):
        try:
            import json as _json
            obj = _json.loads(quality_label_clean[5:])
            parsed_json_title = (obj.get('t') or '').strip()
            parsed_json_year = (obj.get('y') or '').strip()
            try:
                parsed_json_s = int(obj.get('s') or 0)
            except (TypeError, ValueError):
                parsed_json_s = 0
            try:
                parsed_json_ep = int(obj.get('ep') or 0)
            except (TypeError, ValueError):
                parsed_json_ep = 0
        except Exception:
            pass

    if tmdb_title:
        final_title = f"{tmdb_title} ({year})" if year else tmdb_title
    elif parsed_json_title:
        final_title = f"{parsed_json_title} ({parsed_json_year})" if parsed_json_year else parsed_json_title
    elif orig_title:
        final_title = f"{orig_title} ({year})" if year else orig_title
    else:
        # Poslední záchrana: vezmi legacy label, odřízni [SIZE] prefix
        legacy = quality_label_clean
        if legacy.startswith('['):
            close_idx = legacy.find(']')
            if close_idx != -1:
                legacy = legacy[close_idx + 1:].strip()
        final_title = legacy or data.get('real_title') or 'Schválený stream'

    # Epizody: stejný vzor jako admin buildKodiPreview / queue.php suggested title (SxxExx — název dílu)
    if context == 'episode':
        try:
            se = int(data.get('season') or parsed_json_s or 0)
            en = int(data.get('episode') or parsed_json_ep or 0)
        except (TypeError, ValueError):
            se, en = 0, 0
        if se > 0 and en > 0:
            show = (data.get('show_title') or tmdb_title or parsed_json_title or orig_title or '').strip()
            epn = (data.get('episode_name') or '').strip()
            base = f"{show} S{se:02d}E{en:02d}"
            final_title = f"{base} — {epn}" if epn else base

    # 2) Velikost (z API / nexa_stream_meta.size_bytes → zlatý tag jako u VIP/[A])
    size_str = data.get('size_str', '')
    if size_str and str(size_str).strip() not in ('', '---') and str(size_str).replace('.', '', 1).isdigit():
        try:
            _n = int(float(size_str))
            if _n >= 100000:
                size_str = format_size(_n)
        except (TypeError, ValueError):
            pass
    if (not size_str or str(size_str).strip() in ('', '---')) and meta.get('size_bytes'):
        try:
            _b = int(meta['size_bytes'])
            if _b > 0:
                size_str = format_size(_b)
        except (TypeError, ValueError):
            pass
    size_tag = f"[COLOR gold][{size_str}][/COLOR]" if size_str and size_str != '---' else ""

    # 3) Jazyk — z meta, fallback data.lang
    langs_raw = (meta.get('langs') or '').upper()
    subs_raw = (meta.get('subs') or '').upper()
    if 'CZ' in langs_raw:
        lang_display = 'CZ'
    elif 'SK' in langs_raw:
        lang_display = 'SK'
    elif 'CZ' in subs_raw:
        lang_display = 'CZ tit'
    elif 'SK' in subs_raw:
        lang_display = 'SK tit'
    elif langs_raw:
        lang_display = langs_raw.split(',')[0].strip()
    else:
        lang_display = (data.get('lang') or '').strip()
    lang_tag = f"[COLOR lime][{lang_display}][/COLOR]" if lang_display else ""

    # 4) Rozlišení + audio + subs
    resolution = meta.get('resolution') or ''
    audio_tracks = meta.get('audio_tracks') or ''
    audio_codecs = (meta.get('audio_codecs') or '').upper()

    # Název v gold (stejně jako VIP) – odlišení od cyan [A] STANDARD
    title_tag = f"[COLOR gold]{final_title}[/COLOR]"

    parts = ["[COLOR fuchsia][Q][/COLOR]", p_tag]
    if size_tag: parts.append(size_tag)
    if lang_tag: parts.append(lang_tag)
    parts.append(title_tag)
    label = " ".join(parts)

    meta_parts = []
    if resolution:
        r_upper = resolution.upper()
        if '4K' in r_upper or '2160' in r_upper:
            meta_parts.append(f"[COLOR crimson]{resolution}[/COLOR]")
        elif '1080' in r_upper:
            meta_parts.append(f"[COLOR deepskyblue]{resolution}[/COLOR]")
        elif '720' in r_upper:
            meta_parts.append(f"[COLOR lime]{resolution}[/COLOR]")
        else:
            meta_parts.append(resolution)
    if audio_tracks:
        first_audio = audio_tracks.split('/')[0].strip()
        if first_audio:
            meta_parts.append(first_audio)
    elif audio_codecs:
        meta_parts.append(audio_codecs)
    if subs_raw:
        meta_parts.append(f"TIT: {subs_raw}")
    if meta_parts:
        label += " | " + " | ".join(meta_parts)

    # Plot: 1) stejný vzor jako řádek výběru (bez COLOR tagů) — [Q] [WS] [3.9 GB] [CZ]
    #       2) detailní řádky (velikost v hlavičce neopakujeme)
    hdr_bits = ["[Q]", f"[{provider}]"]
    if size_str and size_str != '---':
        hdr_bits.append(f"[{size_str}]")
    if lang_display:
        hdr_bits.append(f"[{lang_display}]")
    plot_header = " ".join(hdr_bits)

    plot_parts = []
    if resolution: plot_parts.append(f"Kvalita: {resolution}")
    _al = _nexa_plot_audio_lang_line(meta, lang_display)
    if _al:
        plot_parts.append(_al)
    if audio_tracks: plot_parts.append(f"Zvuk: {audio_tracks}")
    elif audio_codecs: plot_parts.append(f"Zvuk: {audio_codecs}")
    if subs_raw: plot_parts.append(f"Titulky: {subs_raw}")
    techs = (meta.get('techs') or '').strip()
    if techs: plot_parts.append(f"Tech: {techs}")
    _hdr = _nexa_hdr_summary(meta)
    if _hdr:
        techs_u = techs.upper()
        if 'HDR' not in techs_u and 'DV' not in techs_u and 'DOVI' not in techs_u:
            plot_parts.append(f"HDR / barevný profil: {_hdr}")
    plot_body = "\n".join(plot_parts)
    plot = plot_header
    if plot_body:
        plot += "\n\n" + plot_body
    plot += "\n\n[Q] Schválený stream – moderováno adminem"

    return {
        'label': label,
        'plot': plot,
        'clean_title': final_title,
    }

def _format_auto_cached_stream(data, context):
    """
    Formátování AUTO_CACHED streamů — meta vytažené z admin auto-skenu (nexa_stream_meta).
    Pořadí podle uživatele:
      [A] [PROVIDER] [SIZE] [LANG] NÁZEV | RESOLUTION | AUDIO | TIT: SUBS

    [A] je v cyan barvě (na rozdíl od VIP, který je gold).
    Název filmu je v default/white barvě (na rozdíl od VIP, který je gold).
    """
    meta = data.get('auto_meta') or {}

    provider = str(data.get('provider', 'webshare')).upper()
    if provider == 'WEBSHARE': provider = 'WS'
    elif provider == 'FASTSHARE': provider = 'FS'
    p_color = 'deepskyblue' if provider == 'FS' else 'lime'
    p_tag = f"[COLOR {p_color}][{provider}][/COLOR]"

    size_str = data.get('size_str', '')
    if size_str and str(size_str).strip() not in ('', '---') and str(size_str).replace('.', '', 1).isdigit():
        try:
            _n2 = int(float(size_str))
            if _n2 >= 100000:
                size_str = format_size(_n2)
        except (TypeError, ValueError):
            pass
    if (not size_str or str(size_str).strip() in ('', '---')) and meta.get('size_bytes'):
        try:
            _b = int(meta['size_bytes'])
            if _b > 0:
                size_str = format_size(_b)
        except (TypeError, ValueError):
            pass
    size_tag = f"[COLOR gold][{size_str}][/COLOR]" if size_str and size_str != '---' else ""

    # Jazyk: primárně z meta.langs (CZ/SK), fallback na meta.subs (CZ tit), pak data.lang
    langs_raw = (meta.get('langs') or '').upper()
    subs_raw = (meta.get('subs') or '').upper()
    audio_codecs = (meta.get('audio_codecs') or '').upper()
    audio_tracks = meta.get('audio_tracks') or ''
    resolution = meta.get('resolution') or ''
    lang_display = ''
    if 'CZ' in langs_raw:
        lang_display = 'CZ'
    elif 'SK' in langs_raw:
        lang_display = 'SK'
    elif 'CZ' in subs_raw:
        lang_display = 'CZ tit'
    elif 'SK' in subs_raw:
        lang_display = 'SK tit'
    elif langs_raw:
        # vezmi první jazyk co tam je (např. EN/DE)
        lang_display = langs_raw.split(',')[0].strip()

    lang_tag = f"[COLOR lime][{lang_display}][/COLOR]" if lang_display else ""

    # Název filmu: u AUTO_CACHED NEMÁ smysl ukazovat surový filename
    # (často obsahuje popis, herce, genre). Preferujeme v tomto pořadí:
    #   1) tmdb_title — český TMDB název (předán z select_quality)
    #   2) orig_title (+rok) — originální TMDB název
    #   3) fallback: bezpečné nahrazení nebo surový name (clean)
    name = data.get('name', '')
    tmdb_title = (data.get('tmdb_title') or '').strip()
    orig_title = data.get('orig_title', '')
    year = data.get('year', '')
    if tmdb_title:
        final_title = tmdb_title
    else:
        final_title = name
        try:
            if orig_title and is_safe_match(name, orig_title):
                final_title = f"{orig_title} ({year})" if year else orig_title
        except Exception:
            pass

    # Auto-cached název ve výchozí (bílé) barvě – aby se odlišil od VIP gold
    title_tag = final_title

    # Sestavení labelu
    parts = ["[COLOR cyan][A][/COLOR]", p_tag]
    if size_tag: parts.append(size_tag)
    if lang_tag: parts.append(lang_tag)
    parts.append(title_tag)
    label = " ".join(parts)

    # Metadata za svislítko: rozlišení | audio (kodek/kanály) | TIT: subs
    meta_parts = []
    if resolution:
        r_upper = resolution.upper()
        if '4K' in r_upper or '2160' in r_upper:
            meta_parts.append(f"[COLOR crimson]{resolution}[/COLOR]")
        elif '1080' in r_upper:
            meta_parts.append(f"[COLOR deepskyblue]{resolution}[/COLOR]")
        elif '720' in r_upper:
            meta_parts.append(f"[COLOR lime]{resolution}[/COLOR]")
        else:
            meta_parts.append(resolution)
    # Audio: preferuj detailní audio_tracks, fallback na audio_codecs
    if audio_tracks:
        # audio_tracks může mít formát "CZ 5.1 AC3 / EN 7.1 TRUEHD"
        # Pro label vezmeme jen první variantu (nejvýraznější)
        first_audio = audio_tracks.split('/')[0].strip()
        if first_audio:
            meta_parts.append(first_audio)
    elif audio_codecs:
        meta_parts.append(audio_codecs)

    if subs_raw:
        meta_parts.append(f"TIT: {subs_raw}")

    if meta_parts:
        label += " | " + " | ".join(meta_parts)

    # Plot: 1) stejný vzor jako řádek výběru — [A] [WS] [3.9 GB] [CZ]
    #       2) detaily (velikost je jen v hlavičce, ne „Velikost:“ znovu)
    hdr_bits = ["[A]", f"[{provider}]"]
    if size_str and size_str != '---':
        hdr_bits.append(f"[{size_str}]")
    if lang_display:
        hdr_bits.append(f"[{lang_display}]")
    plot_header = " ".join(hdr_bits)

    plot_parts = []
    if resolution: plot_parts.append(f"Kvalita: {resolution}")
    _al = _nexa_plot_audio_lang_line(meta, lang_display)
    if _al:
        plot_parts.append(_al)
    if audio_tracks: plot_parts.append(f"Zvuk: {audio_tracks}")
    elif audio_codecs: plot_parts.append(f"Zvuk: {audio_codecs}")
    if subs_raw: plot_parts.append(f"Titulky: {subs_raw}")
    techs = (meta.get('techs') or '').strip()
    if techs: plot_parts.append(f"Tech: {techs}")
    _hdr = _nexa_hdr_summary(meta)
    if _hdr:
        techs_u = techs.upper()
        if 'HDR' not in techs_u and 'DV' not in techs_u and 'DOVI' not in techs_u:
            plot_parts.append(f"HDR / barevný profil: {_hdr}")
    plot_body = "\n".join(plot_parts)
    plot = plot_header
    if plot_body:
        plot += "\n\n" + plot_body
    plot += "\n\n[A] Auto-skenovaný stream — meta z admin cache"

    return {
        'label': label,
        'plot': plot,
        'clean_title': final_title,
    }


def _format_hellspy_stream(data, context):
    """
    Formátování Hellspy (Free) streamů.
    Formát: [HL] [SIZE] [JAZYK] Název | Meta (Free zdroj)
    """
    name = data.get('name', '')
    size_str = data.get('size_str', '')
    orig_title = data.get('orig_title', '')
    year = data.get('year', '')
    
    # Parsování informací z názvu
    v_info = parse_video_info(name, size_str, return_dict=True)
    l_tag = v_info.get('lang_tag', '')
    meta = v_info.get('meta', '')
    
    # Bezpečné nahrazení názvu
    final_title = name
    if orig_title and is_safe_match(name, orig_title):
        final_title = f"{orig_title} ({year})" if year else orig_title
    
    # Sestavení: [HL] [SIZE] [JAZYK] Název
    parts = ["[COLOR gray][HL][/COLOR]"]
    if size_str: parts.append(f"[COLOR gold][{size_str}][/COLOR]")
    if l_tag: parts.append(l_tag)
    parts.append(final_title)
    
    label = " ".join(parts)
    if meta: label += f" | {meta}"
    label += " (Free zdroj)"
    
    # Plot
    plot = parse_video_info(name, size_str, data.get('plus', 0), data.get('minus', 0))
    
    return {
        'label': label,
        'plot': plot,
        'clean_title': clean_title(name, remove_quality=True)
    }

def _format_standard_stream(data, context):
    """
    Formátování běžných streamů (Webshare, Fastshare).
    Vyžaduje plné parsování názvu souboru.
    Formát: [WS] [SIZE] [JAZYK] Název | Meta
    """
    name = data.get('name', '')
    size_str = data.get('size_str', '')
    provider = data.get('provider', 'webshare')
    orig_title = data.get('orig_title', '')
    year = data.get('year', '')
    plus = data.get('plus', 0)
    minus = data.get('minus', 0)
    
    # Provider tag
    p_tag = '[COLOR deepskyblue][FS][/COLOR]' if provider in ['fastshare', 'FS'] else '[COLOR lime][WS][/COLOR]'
    
    # Parsování informací z názvu
    v_info = parse_video_info(name, size_str, plus, minus, return_dict=True)
    l_tag = v_info.get('lang_tag', '')
    meta = v_info.get('meta', '')
    
    # Vyčištění názvu
    base_label = clean_title(name, remove_quality=True)
    
    # Bezpečné nahrazení názvu
    final_title = base_label
    if orig_title and is_safe_match(name, orig_title):
        final_title = f"{orig_title} ({year})" if year else orig_title
    
    # Sestavení: [WS] [SIZE] [JAZYK] Název
    parts = [p_tag]
    if size_str: parts.append(f"[COLOR gold][{size_str}][/COLOR]")
    if l_tag: parts.append(l_tag)
    parts.append(final_title)
    
    label = " ".join(parts)
    if meta: label += f" | {meta}"
    
    # Plot s plnými detaily
    plot = parse_video_info(name, size_str, plus, minus)
    
    return {
        'label': label,
        'plot': plot,
        'clean_title': base_label
    }
