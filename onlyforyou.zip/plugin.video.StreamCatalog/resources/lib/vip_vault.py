# -*- coding: utf-8 -*-
"""
In-memory VIP vault.

Purpose: skryt skutecne VIP identy pred kodi.log. Misto realneho identu se do
plugin URL ulozi opaque token tvaru 'vip:<hex>', Kodi si ho zaloguje v playlistu,
ale skutecny payload (ident, provider, url) existuje pouze v pameti aktualniho
Kodi procesu jako property na globalnim oknu (Window(10000)).

Zivotnost: po celou dobu behu Kodi. Restart Kodi behem autoplay playlistu =>
zbyle VIP tokeny selzou s notifikaci (play_file to osetruje).
"""
from __future__ import unicode_literals

import json
import uuid

import xbmc
import xbmcgui

_WINDOW_ID = 10000
_PROP_PREFIX = 'streamcatalog.vip_vault.'
_TOKEN_PREFIX = 'vip:'


def _window():
    return xbmcgui.Window(_WINDOW_ID)


def is_token(value):
    """True pokud hodnota vypada jako vault token ('vip:<hex>')."""
    try:
        return isinstance(value, str) and value.startswith(_TOKEN_PREFIX)
    except Exception:
        return False


def put(payload):
    """
    Ulozi payload do vaultu a vrati token 'vip:<uuid8>'.

    payload: dict s klici 'ident', 'provider', volitelne 'url'.
    """
    try:
        token = _TOKEN_PREFIX + uuid.uuid4().hex[:12]
        data = {
            'ident': str(payload.get('ident', '')),
            'provider': str(payload.get('provider', '')),
            'url': str(payload.get('url', '') or ''),
        }
        _window().setProperty(_PROP_PREFIX + token, json.dumps(data))
        return token
    except Exception as e:
        xbmc.log('NEXASTREAM vip_vault.put error: %s' % e, xbmc.LOGERROR)
        return None


def get(token):
    """Vrati payload (dict) nebo None pokud token neexistuje / vyprsel."""
    if not is_token(token):
        return None
    try:
        raw = _window().getProperty(_PROP_PREFIX + token)
        if not raw:
            return None
        return json.loads(raw)
    except Exception as e:
        xbmc.log('NEXASTREAM vip_vault.get error: %s' % e, xbmc.LOGERROR)
        return None


def pop(token):
    """Prevezme payload a smaze zaznam z vaultu. Vrati None pokud neexistuje."""
    data = get(token)
    try:
        if is_token(token):
            _window().clearProperty(_PROP_PREFIX + token)
    except Exception:
        pass
    return data
